package com.ghazala.orders

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("ghazala_orders", MODE_PRIVATE) }

    private val apiUrl = "https://script.google.com/macros/s/AKfycbw9mzBMDlxeL2F-zMgZoRa0iDAVQYTLuewTKZdWoZkKM-vjJsgcXYbxofOqRqPcaps/exec"

    private var token: String = ""
    private var user = JSONObject()
    private var pendingOrderId: String? = null

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val orderId = pendingOrderId
        pendingOrderId = null
        if (orderId != null && uris.isNotEmpty()) uploadFiles(orderId, uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(28, 28, 28, 28)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        token = prefs.getString("token", "") ?: ""
        if (token.isBlank()) showAuth() else sync()
    }

    private fun showAuth() {
        clear()
        title("طلبات غزالة")
        info("متصل بقاعدة Google Drive. سجّل دخول المدير/العامل/المصمم أو أنشئ حساب عميل جديد.")

        val identifier = input("رقم الجوال أو البريد الإلكتروني")
        val password = input("كلمة المرور", true)
        button("تسجيل الدخول") {
            if (identifier.text.toString().trim().isBlank() || password.text.toString().isBlank()) {
                toast("أدخل رقم الجوال/البريد وكلمة المرور")
            } else {
                login(identifier.text.toString().trim(), password.text.toString())
            }
        }

        info("إنشاء حساب عميل")
        val name = input("اسم العميل")
        val phone = input("رقم الجوال")
        val email = input("البريد الإلكتروني - اختياري")
        val newPass = input("كلمة المرور - 6 أحرف فأكثر", true)
        button("تسجيل عميل جديد") {
            registerClient(
                name.text.toString().trim(),
                phone.text.toString().trim(),
                email.text.toString().trim(),
                newPass.text.toString()
            )
        }

        button("اختبار الاتصال") { ping() }
    }

    private fun login(identifier: String, password: String) {
        busyPost(JSONObject().apply {
            put("action", "login")
            put("identifier", identifier)
            put("password", password)
        }) { result ->
            if (!result.optBoolean("ok")) return@busyPost toast(result.optString("error", "فشل تسجيل الدخول"))
            token = result.optString("token")
            user = result.optJSONObject("user") ?: JSONObject()
            prefs.edit().putString("token", token).apply()
            showDashboard()
        }
    }

    private fun registerClient(name: String, phone: String, email: String, password: String) {
        if (name.isBlank() || phone.isBlank() || password.length < 6) return toast("أدخل الاسم والجوال وكلمة مرور 6 أحرف فأكثر")
        busyPost(JSONObject().apply {
            put("action", "registerClient")
            put("name", name)
            put("phone", phone)
            put("email", email)
            put("password", password)
        }) { result ->
            if (!result.optBoolean("ok")) return@busyPost toast(result.optString("error", "تعذر التسجيل"))
            token = result.optString("token")
            user = result.optJSONObject("user") ?: JSONObject()
            prefs.edit().putString("token", token).apply()
            toast("تم إنشاء حساب العميل")
            showDashboard()
        }
    }

    private fun sync() {
        busyPost(JSONObject().apply {
            put("action", "sync")
            put("token", token)
        }) { result ->
            if (!result.optBoolean("ok")) {
                prefs.edit().remove("token").apply()
                token = ""
                toast("انتهت الجلسة، سجل الدخول من جديد")
                return@busyPost showAuth()
            }
            user = result.optJSONObject("user") ?: JSONObject()
            showDashboard(result)
        }
    }

    private fun showDashboard(syncResult: JSONObject? = null) {
        clear()
        val role = user.optString("role")
        title("مرحبًا ${user.optString("name")}")
        info("الحساب: ${roleLabel(role)}")

        button("تحديث / مزامنة") { sync() }
        button("تسجيل الخروج") { logout() }

        if (role == "client") button("+ إنشاء طلب جديد") { newOrderDialog() }
        if (role == "admin") button("+ إضافة عامل أو مصمم") { addStaffDialog() }

        val orders = syncResult?.optJSONArray("orders")
        if (orders == null) {
            loadOrders()
            return
        }

        title("الطلبات")
        if (orders.length() == 0) info("لا توجد طلبات حتى الآن")
        for (i in 0 until orders.length()) {
            val o = orders.optJSONObject(i) ?: continue
            root.addView(orderCard(o, role))
        }
    }

    private fun loadOrders() {
        busyPost(JSONObject().apply {
            put("action", "listOrders")
            put("token", token)
        }) { result ->
            if (!result.optBoolean("ok")) return@busyPost toast(result.optString("error"))
            showDashboard(JSONObject().apply {
                put("orders", result.optJSONArray("orders") ?: JSONArray())
            })
        }
    }

    private fun orderCard(o: JSONObject, role: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
        }
        box.addView(TextView(this).apply { text = "${o.optString("title")} — ${statusLabel(o.optString("status"))}"; textSize = 17f })
        box.addView(TextView(this).apply { text = "العميل: ${o.optString("clientName")}" })
        if (o.optString("description").isNotBlank()) box.addView(TextView(this).apply { text = o.optString("description") })
        if (o.optString("notes").isNotBlank()) box.addView(TextView(this).apply { text = "ملاحظة: ${o.optString("notes")}" })
        val files = o.optJSONArray("files") ?: JSONArray()
        box.addView(TextView(this).apply { text = "المرفقات: ${files.length()}" })

        if (role == "client" || role == "admin") {
            val b = smallButton("إضافة صور / PDF") {
                pendingOrderId = o.optString("orderId")
                picker.launch(arrayOf("image/*", "application/pdf"))
            }
            box.addView(b)
        }

        if (role == "admin") {
            box.addView(smallButton("إسناد لعامل/مصمم") { assignDialog(o.optString("orderId")) })
        }
        if (role == "admin" || role == "worker" || role == "designer") {
            box.addView(smallButton("تغيير الحالة") { statusDialog(o.optString("orderId"), o.optString("status")) })
        }

        return MaterialCardView(this).apply {
            radius = 20f
            cardElevation = 4f
            setContentPadding(8, 8, 8, 8)
            addView(box)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 10, 0, 10)
            layoutParams = lp
        }
    }

    private fun newOrderDialog() {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 10, 30, 10) }
        val title = EditText(this).apply { hint = "عنوان الطلب" }
        val desc = EditText(this).apply { hint = "وصف الطلب"; minLines = 3 }
        wrap.addView(title); wrap.addView(desc)
        AlertDialog.Builder(this).setTitle("طلب جديد").setView(wrap)
            .setPositiveButton("إنشاء") { _, _ ->
                busyPost(JSONObject().apply {
                    put("action", "createOrder"); put("token", token)
                    put("title", title.text.toString().trim()); put("description", desc.text.toString().trim())
                }) { r ->
                    if (r.optBoolean("ok")) { toast("تم إنشاء الطلب"); sync() } else toast(r.optString("error"))
                }
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun addStaffDialog() {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 10, 30, 10) }
        val name = EditText(this).apply { hint = "الاسم" }
        val phone = EditText(this).apply { hint = "رقم الجوال" }
        val email = EditText(this).apply { hint = "البريد - اختياري" }
        val pass = EditText(this).apply { hint = "كلمة المرور"; inputType = 129 }
        wrap.addView(name); wrap.addView(phone); wrap.addView(email); wrap.addView(pass)
        AlertDialog.Builder(this).setTitle("إضافة موظف").setView(wrap)
            .setSingleChoiceItems(arrayOf("عامل", "مصمم"), 0, null)
            .setPositiveButton("إضافة") { dialog, _ ->
                val which = (dialog as AlertDialog).listView.checkedItemPosition
                busyPost(JSONObject().apply {
                    put("action", "addStaff"); put("token", token); put("name", name.text.toString().trim())
                    put("phone", phone.text.toString().trim()); put("email", email.text.toString().trim())
                    put("password", pass.text.toString()); put("role", if (which == 1) "designer" else "worker")
                }) { r -> if (r.optBoolean("ok")) { toast("تمت إضافة الموظف"); sync() } else toast(r.optString("error")) }
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun assignDialog(orderId: String) {
        busyPost(JSONObject().apply { put("action", "listUsers"); put("token", token) }) { r ->
            if (!r.optBoolean("ok")) return@busyPost toast(r.optString("error"))
            val arr = r.optJSONArray("users") ?: JSONArray()
            val ids = mutableListOf<String>(); val labels = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val u = arr.optJSONObject(i) ?: continue
                val role = u.optString("role")
                if ((role == "worker" || role == "designer") && u.optBoolean("active", true)) {
                    ids.add(u.optString("userId")); labels.add("${u.optString("name")} — ${roleLabel(role)}")
                }
            }
            if (ids.isEmpty()) return@busyPost toast("أضف عاملًا أو مصممًا أولًا")
            AlertDialog.Builder(this).setTitle("إسناد الطلب").setItems(labels.toTypedArray()) { _, which ->
                busyPost(JSONObject().apply {
                    put("action", "assignOrder"); put("token", token); put("orderId", orderId); put("userId", ids[which])
                }) { x -> if (x.optBoolean("ok")) { toast("تم إسناد الطلب"); sync() } else toast(x.optString("error")) }
            }.show()
        }
    }

    private fun statusDialog(orderId: String, current: String) {
        val values = arrayOf("new", "in_progress", "missing", "ready")
        val labels = arrayOf("جديد", "قيد التنفيذ", "ناقص", "جاهز")
        val checked = values.indexOf(current).coerceAtLeast(0)
        var selected = checked
        val note = EditText(this).apply { hint = "ملاحظة - اختياري"; setPadding(30, 10, 30, 10) }
        AlertDialog.Builder(this).setTitle("حالة الطلب").setSingleChoiceItems(labels, checked) { _, w -> selected = w }
            .setView(note).setPositiveButton("حفظ") { _, _ ->
                busyPost(JSONObject().apply {
                    put("action", "updateOrderStatus"); put("token", token); put("orderId", orderId)
                    put("status", values[selected]); put("notes", note.text.toString().trim())
                }) { r -> if (r.optBoolean("ok")) { toast("تم تحديث الحالة"); sync() } else toast(r.optString("error")) }
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun uploadFiles(orderId: String, uris: List<Uri>) {
        toast("بدء رفع ${uris.size} ملف")
        Thread {
            var okCount = 0
            for (uri in uris) {
                try {
                    val name = fileName(uri)
                    val mime = contentResolver.getType(uri) ?: "application/octet-stream"
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: continue
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    val r = post(JSONObject().apply {
                        put("action", "uploadFile"); put("token", token); put("orderId", orderId)
                        put("fileName", name); put("mimeType", mime); put("base64Data", b64)
                    })
                    if (r.optBoolean("ok")) okCount++
                } catch (_: Exception) { }
            }
            runOnUiThread { toast("تم رفع $okCount من ${uris.size}"); sync() }
        }.start()
    }

    private fun fileName(uri: Uri): String {
        var name = "file"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
        }
        return name
    }

    private fun logout() {
        val old = token
        token = ""; user = JSONObject(); prefs.edit().remove("token").apply(); showAuth()
        Thread { try { post(JSONObject().apply { put("action", "logout"); put("token", old) }) } catch (_: Exception) {} }.start()
    }

    private fun ping() {
        Thread {
            try {
                val c = URL("$apiUrl?action=ping").openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 15000
                val text = c.inputStream.bufferedReader().use { it.readText() }
                runOnUiThread { toast(if (JSONObject(text).optBoolean("ok")) "الاتصال يعمل" else "لم ينجح الاتصال") }
            } catch (e: Exception) { runOnUiThread { toast("خطأ اتصال: ${e.message}") } }
        }.start()
    }

    private fun busyPost(payload: JSONObject, onResult: (JSONObject) -> Unit) {
        Thread {
            val result = try { post(payload) } catch (e: Exception) { JSONObject().put("ok", false).put("error", e.message ?: "خطأ اتصال") }
            runOnUiThread { onResult(result) }
        }.start()
    }

    private fun post(payload: JSONObject): JSONObject {
        val conn = URL(apiUrl).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 30000
        conn.readTimeout = 120000
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
        conn.disconnect()
        return JSONObject(text)
    }

    private fun roleLabel(v: String) = when (v) { "admin" -> "مدير"; "worker" -> "عامل"; "designer" -> "مصمم"; else -> "عميل" }
    private fun statusLabel(v: String) = when (v) { "in_progress" -> "قيد التنفيذ"; "missing" -> "ناقص"; "ready" -> "جاهز"; else -> "جديد" }

    private fun clear() = root.removeAllViews()
    private fun title(s: String) = root.addView(TextView(this).apply { text = s; textSize = 23f; gravity = Gravity.CENTER; setPadding(8, 20, 8, 20) })
    private fun info(s: String) = root.addView(TextView(this).apply { text = s; textSize = 15f; setPadding(8, 10, 8, 14) })
    private fun input(hint: String, password: Boolean = false): EditText = EditText(this).apply {
        this.hint = hint
        if (password) inputType = 129
        root.addView(this, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }
    private fun button(text: String, onClick: () -> Unit) = root.addView(smallButton(text, onClick), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    private fun smallButton(text: String, onClick: () -> Unit) = MaterialButton(this).apply { this.text = text; setOnClickListener { onClick() } }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
