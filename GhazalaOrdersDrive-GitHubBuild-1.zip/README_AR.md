# تطبيق طلبات غزالة - Google Drive

هذه النسخة لا تستخدم Firebase.

## الاتصال
التطبيق مربوط مباشرة بـ Google Apps Script Web App:
https://script.google.com/macros/s/AKfycbw9mzBMDlxeL2F-zMgZoRa0iDAVQYTLuewTKZdWoZkKM-vjJsgcXYbxofOqRqPcaps/exec

## الوظائف
- دخول المدير والعامل والمصمم والعميل.
- تسجيل عميل جديد.
- المدير يضيف عاملًا أو مصممًا.
- العميل ينشئ الطلب ويرفع صورًا وPDF.
- المدير يسند الطلب لعامل أو مصمم.
- حالات الطلب: جديد، قيد التنفيذ، ناقص، جاهز.
- المزامنة عبر Google Apps Script + Google Sheets + Google Drive.

## ملاحظة
عدد المرفقات غير محدود برمجيًا، لكن الاستخدام الفعلي يخضع لمساحة Google Drive وحصص Google Apps Script. الملفات تُرفع واحدًا تلو الآخر.
