# بناء APK

## Android Studio
1. افتح مجلد المشروع في Android Studio.
2. انتظر اكتمال Gradle Sync.
3. اختر Build > Build APK(s).
4. ستجد الملف في: app/build/outputs/apk/debug/app-debug.apk

## GitHub Actions
إذا رفعت محتويات هذا المجلد إلى مستودع GitHub، فملف `.github/workflows/build-apk.yml` يبني APK تلقائيًا ويضعه كـ Artifact باسم `ghazala-line-drive-debug`.
