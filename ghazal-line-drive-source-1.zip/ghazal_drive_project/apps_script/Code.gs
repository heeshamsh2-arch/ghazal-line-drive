/**
 * Ghazal Line — Google Drive backend
 * Deploy as Web App: Execute as: Me (the manager) / Who has access: Anyone
 * The database file remains private in the manager's Drive.
 * Customers never receive Drive edit permission; they only call the API to submit orders/files.
 */

const APP_FOLDER = 'GhazalLine_Data';
const DB_FILE = 'ghazal_line_database.json';
const ATTACHMENTS_FOLDER = 'attachments';
const DB_VERSION = 2;

// Change these immediately after first login using the app's change-password screen.
const INITIAL_MANAGER_NAME = 'مدير النظام';

function initialManagerCredentials_() {
  const props = PropertiesService.getScriptProperties();
  let email = props.getProperty('GHZ_MANAGER_EMAIL');
  let password = props.getProperty('GHZ_MANAGER_PASSWORD');
  if (!email) {
    email = cleanEmail_(Session.getEffectiveUser().getEmail()) || 'manager@ghazalline.app';
    props.setProperty('GHZ_MANAGER_EMAIL', email);
  }
  if (!password) {
    password = Utilities.getUuid().replace(/-/g,'').substring(0,14) + 'Aa1!';
    props.setProperty('GHZ_MANAGER_PASSWORD', password);
  }
  return {email: email, password: password};
}

function showInitialManagerCredentials() {
  const c = initialManagerCredentials_();
  Logger.log('Ghazal Line manager email: ' + c.email);
  Logger.log('Ghazal Line initial password: ' + c.password);
  return c;
}

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || 'ping';
  if (action === 'ping') return jsonOut_({ok:true, data:{service:'GhazalLine Drive', version:DB_VERSION}});
  return jsonOut_({ok:false, errorAr:'استخدم التطبيق للوصول إلى الخدمة.'});
}

function doPost(e) {
  try {
    const req = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const action = String(req.action || '');
    const data = req.data || {};
    const token = req.token ? String(req.token) : '';
    return jsonOut_(dispatch_(action, data, token));
  } catch (err) {
    return jsonOut_({ok:false, errorAr:'خطأ في خدمة Google Drive: ' + safeError_(err)});
  }
}

function dispatch_(action, data, token) {
  if (action === 'ping') {
    ensureDb_();
    return ok_({service:'GhazalLine Drive', version:DB_VERSION});
  }
  if (action === 'registerCustomer') return withWrite_(db => registerCustomer_(db, data));
  if (action === 'registerWithInvite') return withWrite_(db => registerWithInvite_(db, data));
  if (action === 'login') return withWrite_(db => login_(db, data));

  const session = requireSession_(token);
  const uid = session.uid;

  switch (action) {
    case 'logout': return withWrite_(db => logout_(db, token, uid));
    case 'profile': return withRead_(db => profile_(db, uid, data));
    case 'changePassword': return withWrite_(db => changePassword_(db, uid, data));
    case 'updateProfile': return withWrite_(db => updateProfile_(db, uid, data));
    case 'listOrders': return withRead_(db => listOrders_(db, uid));
    case 'getOrder': return withRead_(db => getOrder_(db, uid, data));
    case 'listStaff': return withRead_(db => listStaff_(db, uid, data));
    case 'listCustomers': return withRead_(db => listCustomers_(db, uid));
    case 'createOrder': return withWrite_(db => createOrder_(db, uid, data));
    case 'uploadAttachment': return withWrite_(db => uploadAttachment_(db, uid, data));
    case 'addCustomerNote': return withWrite_(db => addCustomerNote_(db, uid, data));
    case 'managerCreateUser': return withWrite_(db => managerCreateUser_(db, uid, data));
    case 'managerGenerateInvite': return withWrite_(db => managerGenerateInvite_(db, uid, data));
    case 'managerSetUserActive': return withWrite_(db => managerSetUserActive_(db, uid, data));
    case 'managerAssignOrder': return withWrite_(db => managerAssignOrder_(db, uid, data));
    case 'managerUnassignOrder': return withWrite_(db => managerUnassignOrder_(db, uid, data));
    case 'managerChangeStatus': return withWrite_(db => managerChangeStatus_(db, uid, data));
    case 'managerUpdateOrder': return withWrite_(db => managerUpdateOrder_(db, uid, data));
    case 'managerDeleteOrder': return withWrite_(db => managerDeleteOrder_(db, uid, data));
    case 'managerDeleteOrderFiles': return withWrite_(db => managerDeleteOrderFiles_(db, uid, data));
    default: return fail_('عملية غير معروفة.');
  }
}

function ok_(data) { return {ok:true, data:data || {}}; }
function fail_(msg) { return {ok:false, errorAr:String(msg || 'تعذّر تنفيذ العملية.')}; }
function jsonOut_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
function safeError_(e) { return String((e && e.message) || e || 'خطأ غير معروف').substring(0, 500); }
function now_() { return new Date().toISOString(); }
function id_(prefix) { return prefix + Utilities.getUuid().replace(/-/g,'').substring(0,20); }
function cleanEmail_(v) { return String(v || '').trim().toLowerCase(); }
function cleanText_(v, max) { return String(v == null ? '' : v).trim().substring(0, max || 5000); }

function getRootFolder_() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty('GHZ_ROOT_FOLDER_ID');
  if (id) {
    try { return DriveApp.getFolderById(id); } catch (_) {}
  }
  const found = DriveApp.getFoldersByName(APP_FOLDER);
  const folder = found.hasNext() ? found.next() : DriveApp.createFolder(APP_FOLDER);
  props.setProperty('GHZ_ROOT_FOLDER_ID', folder.getId());
  return folder;
}

function getDbFile_() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty('GHZ_DB_FILE_ID');
  if (id) {
    try { return DriveApp.getFileById(id); } catch (_) {}
  }
  const root = getRootFolder_();
  const it = root.getFilesByName(DB_FILE);
  const file = it.hasNext() ? it.next() : root.createFile(DB_FILE, JSON.stringify(newDb_(), null, 2), MimeType.PLAIN_TEXT);
  props.setProperty('GHZ_DB_FILE_ID', file.getId());
  return file;
}

function newDb_() {
  const uid = id_('u_');
  const salt = id_('s_');
  const credentials = initialManagerCredentials_();
  const manager = {
    id:uid, name:INITIAL_MANAGER_NAME, phone:'', email:credentials.email,
    role:'manager', isActive:true, notes:'الحساب الإداري الأول', createdAt:now_(),
    passwordSalt:salt, passwordHash:hashPassword_(credentials.password, salt)
  };
  const users = {}; users[uid] = manager;
  return {version:DB_VERSION, createdAt:now_(), updatedAt:now_(), users:users, orders:{}, invites:{}, sessions:{}};
}

function ensureDb_() { getDbFile_(); }
function loadDb_() {
  const file = getDbFile_();
  let db;
  try { db = JSON.parse(file.getBlob().getDataAsString('UTF-8')); } catch (_) { db = newDb_(); }
  db.users = db.users || {}; db.orders = db.orders || {}; db.invites = db.invites || {}; db.sessions = db.sessions || {};
  return db;
}
function saveDb_(db) {
  db.version = DB_VERSION; db.updatedAt = now_();
  getDbFile_().setContent(JSON.stringify(db, null, 2));
}
function withRead_(fn) { return fn(loadDb_()); }
function withWrite_(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    const db = loadDb_();
    const out = fn(db);
    if (out && out.ok) saveDb_(db);
    return out;
  } finally { lock.releaseLock(); }
}

function hashPassword_(password, salt) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(salt) + ':' + String(password), Utilities.Charset.UTF_8);
  return bytes.map(b => ((b + 256) % 256).toString(16).padStart(2,'0')).join('');
}
function verifyPassword_(user, password) { return user && user.passwordHash === hashPassword_(password, user.passwordSalt); }
function publicUser_(u) {
  return {id:u.id, name:u.name, phone:u.phone || '', email:u.email || '', role:u.role || 'customer', isActive:u.isActive !== false, notes:u.notes || null, createdAt:u.createdAt || now_()};
}
function findUserByEmail_(db, email) {
  const target = cleanEmail_(email);
  return Object.values(db.users).find(u => cleanEmail_(u.email) === target) || null;
}
function user_(db, uid) { return db.users[uid] || null; }
function requireActiveUser_(db, uid) {
  const u = user_(db, uid);
  if (!u || u.isActive === false) throw new Error('الحساب غير موجود أو موقوف.');
  return u;
}
function requireManager_(db, uid) {
  const u = requireActiveUser_(db, uid);
  if (u.role !== 'manager') throw new Error('هذه العملية متاحة للمدير فقط.');
  return u;
}

function requireSession_(token) {
  if (!token) throw new Error('يلزم تسجيل الدخول.');
  const db = loadDb_();
  const s = db.sessions[token];
  if (!s || !s.uid || Number(s.expiresAt || 0) < Date.now()) throw new Error('انتهت جلسة الدخول. سجّل الدخول من جديد.');
  const u = db.users[s.uid];
  if (!u || u.isActive === false) throw new Error('الحساب موقوف.');
  return {uid:s.uid};
}

function login_(db, d) {
  const email = cleanEmail_(d.email); const password = String(d.password || '');
  const u = findUserByEmail_(db, email);
  if (!u || !verifyPassword_(u, password)) return fail_('البريد الإلكتروني أو كلمة المرور غير صحيحة.');
  if (u.isActive === false) return fail_('تم إيقاف هذا الحساب. راجع المدير.');
  Object.keys(db.sessions).forEach(k => { if (Number(db.sessions[k].expiresAt || 0) < Date.now()) delete db.sessions[k]; });
  const token = id_('t_') + id_('x_');
  db.sessions[token] = {uid:u.id, createdAt:Date.now(), expiresAt:Date.now() + 7*24*60*60*1000};
  return ok_({token:token, uid:u.id, user:publicUser_(u)});
}
function logout_(db, token, uid) { delete db.sessions[token]; return ok_({}); }

function validateNewUser_(db, d) {
  const email = cleanEmail_(d.email); const name = cleanText_(d.name,120); const phone = cleanText_(d.phone,50); const password = String(d.password || '');
  if (!name) throw new Error('الاسم مطلوب.');
  if (!email || email.indexOf('@') < 1) throw new Error('البريد الإلكتروني غير صحيح.');
  if (password.length < 6) throw new Error('كلمة المرور يجب أن تكون 6 أحرف على الأقل.');
  if (findUserByEmail_(db,email)) throw new Error('البريد الإلكتروني مستخدم مسبقًا.');
  return {email,name,phone,password};
}
function addUser_(db, d, role) {
  const v = validateNewUser_(db,d); const uid=id_('u_'); const salt=id_('s_');
  db.users[uid] = {id:uid,name:v.name,phone:v.phone,email:v.email,role:role,isActive:true,notes:'',createdAt:now_(),passwordSalt:salt,passwordHash:hashPassword_(v.password,salt)};
  return db.users[uid];
}
function registerCustomer_(db,d) {
  try { const u=addUser_(db,d,'customer'); return ok_({uid:u.id}); } catch(e){ return fail_(safeError_(e)); }
}
function registerWithInvite_(db,d) {
  try {
    const code=cleanText_(d.code,40).toUpperCase(); const inv=db.invites[code];
    if(!inv || inv.used || Number(inv.expiresAt||0)<Date.now()) return fail_('رمز الدعوة غير صحيح أو منتهي.');
    if(inv.role!=='worker' && inv.role!=='designer') return fail_('نوع الدعوة غير مدعوم.');
    const u=addUser_(db,d,inv.role); inv.used=true; inv.usedBy=u.id; inv.usedAt=now_();
    return ok_({uid:u.id});
  } catch(e){ return fail_(safeError_(e)); }
}
function profile_(db, uid, d) {
  const caller=requireActiveUser_(db,uid); const target=String(d.uid||uid);
  if(target!==uid && caller.role!=='manager') return fail_('غير مسموح.');
  const u=db.users[target]; return u ? ok_({user:publicUser_(u)}) : fail_('المستخدم غير موجود.');
}
function changePassword_(db,uid,d) {
  const u=requireActiveUser_(db,uid);
  if(!verifyPassword_(u,String(d.currentPassword||''))) return fail_('كلمة المرور الحالية غير صحيحة.');
  const np=String(d.newPassword||''); if(np.length<6) return fail_('كلمة المرور الجديدة قصيرة.');
  const salt=id_('s_'); u.passwordSalt=salt; u.passwordHash=hashPassword_(np,salt); return ok_({});
}
function updateProfile_(db,uid,d) {
  const caller=requireActiveUser_(db,uid); const target=String(d.uid||uid); const t=db.users[target];
  if(!t) return fail_('المستخدم غير موجود.');
  if(target!==uid && caller.role!=='manager') return fail_('غير مسموح.');
  const c=d.changes||{};
  if(c.name!=null) t.name=cleanText_(c.name,120);
  if(c.phone!=null) t.phone=cleanText_(c.phone,50);
  if(c.notes!=null && caller.role==='manager') t.notes=cleanText_(c.notes,1000);
  return ok_({user:publicUser_(t)});
}

function orderVisible_(db,u,o) {
  if(u.role==='manager') return true;
  if(u.role==='customer') return o.customerId===u.id;
  if(u.role==='worker' || u.role==='designer') return o.assigneeId===u.id;
  return false;
}
function publicOrder_(o) { return JSON.parse(JSON.stringify(o)); }
function listOrders_(db,uid) {
  const u=requireActiveUser_(db,uid);
  const items=Object.values(db.orders).filter(o=>orderVisible_(db,u,o)).sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)));
  return ok_({orders:items.map(publicOrder_)});
}
function getOrder_(db,uid,d) {
  const u=requireActiveUser_(db,uid); const o=db.orders[String(d.orderId||'')];
  if(!o || !orderVisible_(db,u,o)) return fail_('الطلب غير موجود أو غير مسموح بعرضه.');
  return ok_({order:publicOrder_(o)});
}
function listStaff_(db,uid,d) {
  requireManager_(db,uid); const role=String(d.role||'');
  let items=Object.values(db.users).filter(u=>u.role==='worker'||u.role==='designer');
  if(role) items=items.filter(u=>u.role===role);
  return ok_({users:items.map(publicUser_)});
}
function listCustomers_(db,uid) { requireManager_(db,uid); return ok_({users:Object.values(db.users).filter(u=>u.role==='customer').map(publicUser_)}); }

function createOrder_(db,uid,d) {
  const u=requireActiveUser_(db,uid); if(u.role!=='customer' && u.role!=='manager') return fail_('إنشاء الطلب متاح للعميل أو المدير فقط.');
  const oid=id_('ord_'); const t=now_();
  const event={id:'h0',status:'newRequest',note:'تم إنشاء الطلب',actorName:u.name,actorRole:u.role,at:t};
  db.orders[oid]={
    id:oid,customerId:u.id,customerName:u.name,customerPhone:u.phone||'',
    title:cleanText_(d.title,250)||'طلب',description:cleanText_(d.description,8000),serviceType:cleanText_(d.serviceType,120)||'أخرى',quantity:Math.max(1,Number(d.quantity||1)),
    attachments:[],status:'newRequest',assigneeId:null,assigneeName:null,assigneeRole:null,
    dueDate:d.dueDate||null,price:null,managerNote:'',history:[event],createdAt:t,updatedAt:t
  };
  return ok_({orderId:oid,order:publicOrder_(db.orders[oid])});
}

function attachmentFolder_(orderId) {
  const root=getRootFolder_(); let att;
  const a=root.getFoldersByName(ATTACHMENTS_FOLDER); att=a.hasNext()?a.next():root.createFolder(ATTACHMENTS_FOLDER);
  const it=att.getFoldersByName(orderId); return it.hasNext()?it.next():att.createFolder(orderId);
}
function sanitizeName_(name) { return String(name||'file').replace(/[\\/:*?"<>|]/g,'_').substring(0,180); }
function uploadAttachment_(db,uid,d) {
  const u=requireActiveUser_(db,uid); const oid=String(d.orderId||''); const o=db.orders[oid];
  if(!o) return fail_('الطلب غير موجود.');
  const canUpload = u.role==='manager' || (u.role==='customer' && o.customerId===u.id);
  if(!canUpload) return fail_('رفع الملفات متاح للعميل صاحب الطلب أو المدير فقط.');
  const b64=String(d.base64||''); if(!b64) return fail_('الملف فارغ.');
  const bytes=Utilities.base64Decode(b64); if(bytes.length>9*1024*1024) return fail_('حجم الملف أكبر من 9 MB.');
  const mime=cleanText_(d.mimeType,100)||'application/octet-stream';
  const name=sanitizeName_(d.fileName); const finalName=Date.now()+'_'+name;
  const file=attachmentFolder_(oid).createFile(Utilities.newBlob(bytes,mime,finalName));
  // قاعدة البيانات تبقى خاصة. المرفقات فقط تُعرض برابط غير مفهرس ليتمكن التطبيق من عرضها.
  try { file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch(_) {}
  const aid=id_('a_'); const att={id:aid,url:'https://drive.google.com/uc?export=view&id='+file.getId(),fileName:name,mimeType:mime,sizeBytes:bytes.length,uploadedByName:u.name,uploadedAt:now_(),driveFileId:file.getId()};
  o.attachments.push(att); o.updatedAt=now_();
  o.history.push({id:'h'+o.history.length,status:o.status,note:u.role==='customer'?'أضاف العميل ملفاً':'أضاف المدير ملفاً',actorName:u.name,actorRole:u.role,at:now_()});
  return ok_({attachment:att});
}
function addCustomerNote_(db,uid,d) {
  const u=requireActiveUser_(db,uid), o=db.orders[String(d.orderId||'')]; if(!o) return fail_('الطلب غير موجود.');
  if(u.role!=='manager' && !(u.role==='customer'&&o.customerId===u.id)) return fail_('غير مسموح.');
  const note=cleanText_(d.note,2000); if(note) o.history.push({id:'h'+o.history.length,status:o.status,note:note,actorName:u.name,actorRole:u.role,at:now_()});
  o.updatedAt=now_(); return ok_({});
}

function managerCreateUser_(db,uid,d){ try{requireManager_(db,uid); const role=String(d.role||''); if(!['customer','worker','designer'].includes(role))return fail_('الدور غير صحيح.'); const u=addUser_(db,d,role); return ok_({user:publicUser_(u)});}catch(e){return fail_(safeError_(e));} }
function managerGenerateInvite_(db,uid,d){ requireManager_(db,uid); const role=String(d.role||''); if(!['worker','designer'].includes(role))return fail_('الدعوة للعامل أو المصمم فقط.'); const code=('GHZ-'+Math.random().toString(36).substring(2,6)+'-'+Math.random().toString(36).substring(2,6)).toUpperCase(); db.invites[code]={code,role,createdAt:now_(),expiresAt:Date.now()+14*24*60*60*1000,used:false}; return ok_({code}); }
function managerSetUserActive_(db,uid,d){ requireManager_(db,uid); const t=db.users[String(d.uid||'')]; if(!t)return fail_('المستخدم غير موجود.'); if(t.role==='manager'&&t.id===uid&&!d.isActive)return fail_('لا يمكن للمدير إيقاف حسابه الحالي.'); t.isActive=d.isActive===true; return ok_({}); }
function requireOrderManager_(db,uid,oid){ const m=requireManager_(db,uid); const o=db.orders[String(oid||'')]; if(!o)throw new Error('الطلب غير موجود.'); return {m,o}; }
function managerAssignOrder_(db,uid,d){ try{const x=requireOrderManager_(db,uid,d.orderId), a=db.users[String(d.assigneeId||'')]; if(!a||!['worker','designer'].includes(a.role))return fail_('الموظف غير موجود.'); x.o.assigneeId=a.id;x.o.assigneeName=a.name;x.o.assigneeRole=a.role;x.o.status='assigned'; if(d.dueDate)x.o.dueDate=d.dueDate; x.o.updatedAt=now_();x.o.history.push({id:'h'+x.o.history.length,status:'assigned',note:cleanText_(d.note,2000)||('تم إسناد الطلب إلى '+a.name),actorName:x.m.name,actorRole:'manager',at:now_()});return ok_({});}catch(e){return fail_(safeError_(e));} }
function managerUnassignOrder_(db,uid,d){ try{const x=requireOrderManager_(db,uid,d.orderId);x.o.assigneeId=null;x.o.assigneeName=null;x.o.assigneeRole=null;x.o.status='newRequest';x.o.updatedAt=now_();x.o.history.push({id:'h'+x.o.history.length,status:'newRequest',note:'تم إلغاء الإسناد',actorName:x.m.name,actorRole:'manager',at:now_()});return ok_({});}catch(e){return fail_(safeError_(e));} }
function managerChangeStatus_(db,uid,d){ try{const x=requireOrderManager_(db,uid,d.orderId);const allowed=['newRequest','underReview','missingInfo','assigned','inProgress','ready','delivered','cancelled'];const st=String(d.status||'');if(!allowed.includes(st))return fail_('الحالة غير صحيحة.');x.o.status=st;x.o.updatedAt=now_();x.o.history.push({id:'h'+x.o.history.length,status:st,note:cleanText_(d.note,2000)||('تغيّرت الحالة إلى '+st),actorName:x.m.name,actorRole:'manager',at:now_()});return ok_({});}catch(e){return fail_(safeError_(e));} }
function managerUpdateOrder_(db,uid,d){ try{const x=requireOrderManager_(db,uid,d.orderId);if(d.price!=null)x.o.price=Number(d.price);if(d.managerNote!=null)x.o.managerNote=cleanText_(d.managerNote,5000);if(d.hasDueDateChange===true)x.o.dueDate=d.dueDate||null;x.o.updatedAt=now_();return ok_({});}catch(e){return fail_(safeError_(e));} }
function managerDeleteOrder_(db,uid,d){ try{const x=requireOrderManager_(db,uid,d.orderId); delete db.orders[x.o.id]; deleteOrderFolderFiles_(x.o.id); return ok_({});}catch(e){return fail_(safeError_(e));} }
function managerDeleteOrderFiles_(db,uid,d){ try{requireManager_(db,uid);deleteOrderFolderFiles_(String(d.orderId||''));return ok_({});}catch(e){return fail_(safeError_(e));} }
function deleteOrderFolderFiles_(oid){ const root=getRootFolder_();const a=root.getFoldersByName(ATTACHMENTS_FOLDER);if(!a.hasNext())return;const att=a.next();const it=att.getFoldersByName(oid);while(it.hasNext()){const f=it.next();const fs=f.getFiles();while(fs.hasNext())fs.next().setTrashed(true);f.setTrashed(true);} }
