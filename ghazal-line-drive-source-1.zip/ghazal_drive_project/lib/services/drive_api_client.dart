import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:shared_preferences/shared_preferences.dart';

/// إعداد الاتصال بخدمة Google Apps Script التي تعمل بحساب مدير التطبيق.
/// قاعدة البيانات والملفات الفعلية تُحفظ داخل Google Drive للمدير.
class DriveConnectionConfig {
  static const _endpointKey = 'ghazal_drive_endpoint';

  final String endpoint;
  const DriveConnectionConfig(this.endpoint);

  static Future<DriveConnectionConfig?> load() async {
    final prefs = await SharedPreferences.getInstance();
    final value = (prefs.getString(_endpointKey) ?? '').trim();
    return value.isEmpty ? null : DriveConnectionConfig(value);
  }

  static Future<void> save(String endpoint) async {
    final clean = endpoint.trim();
    if (!clean.startsWith('https://script.google.com/') || !clean.contains('/exec')) {
      throw ArgumentError('الرابط يجب أن يكون رابط Web App من Google Apps Script وينتهي بـ /exec');
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_endpointKey, clean);
  }

  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_endpointKey);
  }
}

class DriveApiException implements Exception {
  final String messageAr;
  final int? statusCode;
  DriveApiException(this.messageAr, [this.statusCode]);

  @override
  String toString() => messageAr;
}

/// عميل HTTP خفيف لا يحتاج أي حزمة جديدة.
class DriveApiClient {
  DriveApiClient(this.endpoint);

  final String endpoint;
  String? sessionToken;
  String? currentUid;

  bool get isSignedIn => sessionToken != null && currentUid != null;

  Future<Map<String, dynamic>> call(
    String action, {
    Map<String, dynamic> data = const <String, dynamic>{},
    bool requiresAuth = true,
    Duration timeout = const Duration(seconds: 45),
  }) async {
    final body = <String, dynamic>{
      'action': action,
      'data': data,
      if (requiresAuth && sessionToken != null) 'token': sessionToken,
      'client': 'ghazal-line-android',
      'version': 2,
    };

    final response = await _postJson(Uri.parse(endpoint), body, timeout: timeout);
    final ok = response['ok'] == true;
    if (!ok) {
      throw DriveApiException(
        (response['errorAr'] as String?) ?? 'تعذّر الاتصال بقاعدة Google Drive.',
      );
    }
    final raw = response['data'];
    if (raw is Map<String, dynamic>) return raw;
    if (raw is Map) return raw.map((k, v) => MapEntry(k.toString(), v));
    return <String, dynamic>{'value': raw};
  }

  Future<Map<String, dynamic>> _postJson(
    Uri uri,
    Map<String, dynamic> body, {
    required Duration timeout,
    int redirects = 0,
  }) async {
    if (redirects > 5) throw DriveApiException('حدثت تحويلات كثيرة أثناء الاتصال بـ Google.');
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
    try {
      final request = await client.postUrl(uri).timeout(timeout);
      request.followRedirects = false;
      request.headers.contentType = ContentType.json;
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      request.write(jsonEncode(body));
      final response = await request.close().timeout(timeout);

      if (response.isRedirect) {
        final location = response.headers.value(HttpHeaders.locationHeader);
        await response.drain<void>();
        if (location == null) throw DriveApiException('تعذّر متابعة تحويل Google.');
        final next = uri.resolve(location);
        // Google Apps Script يعيد غالبًا 302/303 إلى script.googleusercontent.com.
        // في هذه الحالة يجب جلب النتيجة النهائية بـ GET، لا إعادة POST إلى رابط التحويل.
        if (response.statusCode == HttpStatus.movedTemporarily ||
            response.statusCode == HttpStatus.seeOther ||
            response.statusCode == HttpStatus.movedPermanently) {
          return _getRedirectJson(next, timeout: timeout, redirects: redirects + 1);
        }
        return _postJson(next, body, timeout: timeout, redirects: redirects + 1);
      }

      final text = await utf8.decoder.bind(response).join().timeout(timeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw DriveApiException('خطأ اتصال (${response.statusCode}).', response.statusCode);
      }
      try {
        final decoded = jsonDecode(text);
        if (decoded is Map<String, dynamic>) return decoded;
        if (decoded is Map) return decoded.map((k, v) => MapEntry(k.toString(), v));
        throw const FormatException();
      } catch (_) {
        throw DriveApiException('استجابة Google غير صالحة. تأكد من رابط /exec ومن نشر السكربت.');
      }
    } on TimeoutException {
      throw DriveApiException('انتهت مهلة الاتصال بـ Google Drive.');
    } on SocketException {
      throw DriveApiException('لا يوجد اتصال بالإنترنت أو تعذّر الوصول إلى Google.');
    } finally {
      client.close(force: true);
    }
  }


  Future<Map<String, dynamic>> _getRedirectJson(
    Uri uri, {
    required Duration timeout,
    required int redirects,
  }) async {
    if (redirects > 5) throw DriveApiException('حدثت تحويلات كثيرة أثناء الاتصال بـ Google.');
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
    try {
      final request = await client.getUrl(uri).timeout(timeout);
      request.followRedirects = false;
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      final response = await request.close().timeout(timeout);

      if (response.isRedirect) {
        final location = response.headers.value(HttpHeaders.locationHeader);
        await response.drain<void>();
        if (location == null) throw DriveApiException('تعذّر متابعة تحويل Google.');
        return _getRedirectJson(uri.resolve(location), timeout: timeout, redirects: redirects + 1);
      }

      final text = await utf8.decoder.bind(response).join().timeout(timeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw DriveApiException('خطأ اتصال (${response.statusCode}).', response.statusCode);
      }
      try {
        final decoded = jsonDecode(text);
        if (decoded is Map<String, dynamic>) return decoded;
        if (decoded is Map) return decoded.map((k, v) => MapEntry(k.toString(), v));
        throw const FormatException();
      } catch (_) {
        throw DriveApiException('استجابة Google غير صالحة. تأكد من رابط /exec ومن نشر السكربت.');
      }
    } on TimeoutException {
      throw DriveApiException('انتهت مهلة الاتصال بـ Google Drive.');
    } on SocketException {
      throw DriveApiException('لا يوجد اتصال بالإنترنت أو تعذّر الوصول إلى Google.');
    } finally {
      client.close(force: true);
    }
  }

  void setSession({required String token, required String uid}) {
    sessionToken = token;
    currentUid = uid;
  }

  void clearSession() {
    sessionToken = null;
    currentUid = null;
  }
}
