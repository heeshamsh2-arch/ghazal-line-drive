import 'dart:async';
import 'dart:convert';
import 'dart:io';

import '../core/result.dart';
import '../models/app_user.dart';
import '../models/order.dart';
import 'backends.dart';
import 'drive_api_client.dart';

class DriveAuthBackend implements AuthBackend {
  DriveAuthBackend(this.api);
  final DriveApiClient api;
  final StreamController<void> _authChanges = StreamController<void>.broadcast();

  @override
  Stream<void> get authStateChanges => _authChanges.stream;

  @override
  String? get currentUid => api.currentUid;

  @override
  Future<AppUser?> fetchProfile(String uid) async {
    final r = await api.call('profile', data: {'uid': uid});
    final m = _map(r['user']);
    return m == null ? null : AppUser.fromMap(m, (m['id'] ?? uid).toString());
  }

  @override
  Future<OpResult> signIn({required String email, required String password}) async {
    try {
      final r = await api.call(
        'login',
        requiresAuth: false,
        data: {'email': email.trim().toLowerCase(), 'password': password},
      );
      final token = (r['token'] ?? '').toString();
      final uid = (r['uid'] ?? '').toString();
      if (token.isEmpty || uid.isEmpty) return const OpResult.failure('تعذّر إنشاء جلسة الدخول.');
      api.setSession(token: token, uid: uid);
      _authChanges.add(null);
      return const OpResult.success();
    } on DriveApiException catch (e) {
      return OpResult.failure(e.messageAr);
    } catch (e) {
      return OpResult.failure('تعذّر تسجيل الدخول. $e');
    }
  }

  @override
  Future<OpResult> registerCustomer({
    required String name,
    required String phone,
    required String email,
    required String password,
  }) async {
    try {
      await api.call('registerCustomer', requiresAuth: false, data: {
        'name': name.trim(), 'phone': phone.trim(), 'email': email.trim().toLowerCase(), 'password': password,
      });
      return const OpResult.success();
    } on DriveApiException catch (e) {
      return OpResult.failure(e.messageAr);
    }
  }

  @override
  Future<OpResult> registerWithInviteCode({
    required String name,
    required String phone,
    required String email,
    required String password,
    required String code,
  }) async {
    try {
      await api.call('registerWithInvite', requiresAuth: false, data: {
        'name': name.trim(), 'phone': phone.trim(), 'email': email.trim().toLowerCase(),
        'password': password, 'code': code.trim().toUpperCase(),
      });
      return const OpResult.success();
    } on DriveApiException catch (e) {
      return OpResult.failure(e.messageAr);
    }
  }

  @override
  Future<OpResult> createUserAsManager({
    required String name,
    required String phone,
    required String email,
    required String password,
    required UserRole role,
  }) async {
    try {
      await api.call('managerCreateUser', data: {
        'name': name.trim(), 'phone': phone.trim(), 'email': email.trim().toLowerCase(),
        'password': password, 'role': role.id,
      });
      return const OpResult.success();
    } on DriveApiException catch (e) {
      return OpResult.failure(e.messageAr);
    }
  }

  @override
  Future<String> generateInviteCode(UserRole role) async {
    final r = await api.call('managerGenerateInvite', data: {'role': role.id});
    return (r['code'] ?? '').toString();
  }

  @override
  Future<void> updateProfile(String uid, Map<String, dynamic> data) async {
    await api.call('updateProfile', data: {'uid': uid, 'changes': _jsonSafe(data)});
  }

  @override
  Future<void> setUserActive(String uid, bool isActive) async {
    await api.call('managerSetUserActive', data: {'uid': uid, 'isActive': isActive});
  }

  @override
  Future<OpResult> changePassword({required String currentPassword, required String newPassword}) async {
    try {
      await api.call('changePassword', data: {'currentPassword': currentPassword, 'newPassword': newPassword});
      return const OpResult.success();
    } on DriveApiException catch (e) {
      return OpResult.failure(e.messageAr);
    }
  }

  @override
  Future<void> signOut() async {
    try { await api.call('logout'); } catch (_) {}
    api.clearSession();
    _authChanges.add(null);
  }
}

class DriveOrderBackend implements OrderBackend, StorageBackend {
  DriveOrderBackend(this.api);
  final DriveApiClient api;

  Stream<T> _poll<T>(Future<T> Function() loader) async* {
    while (true) {
      try { yield await loader(); } catch (_) {}
      await Future<void>.delayed(const Duration(seconds: 5));
    }
  }

  @override
  Stream<List<Order>> watchOrdersFor(AppUser user) => _poll(() async {
    final r = await api.call('listOrders');
    return _listMaps(r['orders']).map((m) => Order.fromMap(m, (m['id'] ?? '').toString())).toList();
  });

  @override
  Stream<Order?> watchOrder(String orderId) => _poll(() async {
    final r = await api.call('getOrder', data: {'orderId': orderId});
    final m = _map(r['order']);
    return m == null ? null : Order.fromMap(m, (m['id'] ?? orderId).toString());
  });

  @override
  Stream<List<AppUser>> watchStaff({UserRole? role}) => _poll(() async {
    final r = await api.call('listStaff', data: {if (role != null) 'role': role.id});
    return _listMaps(r['users']).map((m) => AppUser.fromMap(m, (m['id'] ?? '').toString())).toList();
  });

  @override
  Stream<List<AppUser>> watchCustomers() => _poll(() async {
    final r = await api.call('listCustomers');
    return _listMaps(r['users']).map((m) => AppUser.fromMap(m, (m['id'] ?? '').toString())).toList();
  });

  @override
  Future<OpResult> createOrder({
    required AppUser customer,
    required String title,
    required String description,
    required String serviceType,
    required int quantity,
    required DateTime? dueDate,
    required List<SelectedFile> files,
  }) async {
    try {
      final r = await api.call('createOrder', data: {
        'title': title.trim(), 'description': description.trim(), 'serviceType': serviceType,
        'quantity': quantity, 'dueDate': dueDate?.toIso8601String(),
      });
      final orderId = (r['orderId'] ?? '').toString();
      if (files.isNotEmpty && orderId.isNotEmpty) {
        final up = await uploadFiles(orderId: orderId, files: files, uploaderName: customer.name);
        if (up.errorsAr.isNotEmpty) return OpResult.failure('تم حفظ الطلب، لكن بعض الملفات لم تُرفع:\n${up.errorsAr.join('\n')}');
      }
      return const OpResult.success();
    } on DriveApiException catch (e) {
      return OpResult.failure(e.messageAr);
    } catch (e) {
      return OpResult.failure('تعذّر إنشاء الطلب. $e');
    }
  }

  @override
  Future<OpResult> assignOrder({
    required String orderId,
    required AppUser assignee,
    required AppUser manager,
    String? note,
    DateTime? dueDate,
  }) => _managerAction('managerAssignOrder', {
    'orderId': orderId, 'assigneeId': assignee.id, 'note': note, 'dueDate': dueDate?.toIso8601String(),
  });

  @override
  Future<OpResult> unassignOrder({required String orderId, required AppUser manager}) =>
      _managerAction('managerUnassignOrder', {'orderId': orderId});

  @override
  Future<OpResult> changeStatus({
    required String orderId,
    required OrderStatus newStatus,
    required AppUser actor,
    String? note,
  }) async {
    // الخادم يمنع العامل/المصمم من التعديل. المدير فقط يغيّر الحالة.
    return _managerAction('managerChangeStatus', {
      'orderId': orderId, 'status': newStatus.id, 'note': note,
    });
  }

  @override
  Future<OpResult> addAttachments({
    required String orderId,
    required List<SelectedFile> files,
    required AppUser uploader,
    String? note,
  }) async {
    try {
      final up = await uploadFiles(orderId: orderId, files: files, uploaderName: uploader.name);
      if (up.attachments.isEmpty && up.errorsAr.isNotEmpty) return OpResult.failure(up.errorsAr.join('\n'));
      if (note != null && note.trim().isNotEmpty) {
        await api.call('addCustomerNote', data: {'orderId': orderId, 'note': note.trim()});
      }
      return up.errorsAr.isEmpty ? const OpResult.success() : OpResult.failure(up.errorsAr.join('\n'));
    } on DriveApiException catch (e) {
      return OpResult.failure(e.messageAr);
    }
  }

  @override
  Future<OpResult> updateManagerFields({
    required String orderId,
    double? price,
    String? managerNote,
    DateTime? dueDate,
    bool clearDueDate = false,
  }) => _managerAction('managerUpdateOrder', {
    'orderId': orderId, if (price != null) 'price': price,
    if (managerNote != null) 'managerNote': managerNote,
    'dueDate': clearDueDate ? null : dueDate?.toIso8601String(),
    'hasDueDateChange': clearDueDate || dueDate != null,
  });

  @override
  Future<OpResult> deleteOrder(String orderId) => _managerAction('managerDeleteOrder', {'orderId': orderId});

  Future<OpResult> _managerAction(String action, Map<String, dynamic> data) async {
    try { await api.call(action, data: data); return const OpResult.success(); }
    on DriveApiException catch (e) { return OpResult.failure(e.messageAr); }
    catch (e) { return OpResult.failure('تعذّر تنفيذ العملية. $e'); }
  }

  @override
  Future<UploadResult> uploadFiles({
    required String orderId,
    required List<SelectedFile> files,
    required String uploaderName,
  }) async {
    final uploaded = <Attachment>[];
    final errors = <String>[];
    for (final f in files) {
      if (f.path == null || f.path!.isEmpty) { errors.add('تعذّر الوصول إلى «${f.name}».'); continue; }
      if (!isAllowedMime(f.mimeType)) { errors.add('النوع غير مدعوم في «${f.name}».'); continue; }
      // حد عملي لخدمة Apps Script. يحمي الذاكرة ويمنع فشل الطلب بالكامل.
      if (f.sizeBytes > 9 * 1024 * 1024) { errors.add('«${f.name}» أكبر من 9 MB. صغّر الملف ثم أعد المحاولة.'); continue; }
      try {
        final bytes = await File(f.path!).readAsBytes();
        final r = await api.call('uploadAttachment', data: {
          'orderId': orderId, 'fileName': f.name, 'mimeType': f.mimeType,
          'sizeBytes': bytes.length, 'uploaderName': uploaderName,
          'base64': base64Encode(bytes),
        }, timeout: const Duration(seconds: 90));
        final m = _map(r['attachment']);
        if (m != null) uploaded.add(Attachment.fromMap(m, (m['id'] ?? '').toString()));
      } on DriveApiException catch (e) { errors.add('${f.name}: ${e.messageAr}'); }
      catch (_) { errors.add('فشل رفع «${f.name}».'); }
    }
    return UploadResult(uploaded, errors);
  }

  @override
  Future<void> deleteOrderFolder(String orderId) async {
    await api.call('managerDeleteOrderFiles', data: {'orderId': orderId});
  }
}

Map<String, dynamic>? _map(Object? value) {
  if (value is Map<String, dynamic>) return value;
  if (value is Map) return value.map((k, v) => MapEntry(k.toString(), v));
  return null;
}

List<Map<String, dynamic>> _listMaps(Object? value) {
  if (value is! List) return <Map<String, dynamic>>[];
  return value.map(_map).whereType<Map<String, dynamic>>().toList();
}

Object? _jsonSafe(Object? value) {
  if (value == null || value is String || value is num || value is bool) return value;
  if (value is DateTime) return value.toIso8601String();
  if (value is List) return value.map(_jsonSafe).toList();
  if (value is Map) return value.map((k, v) => MapEntry(k.toString(), _jsonSafe(v)));
  // Firestore Timestamp أو أي نوع تاريخ له toDate
  try {
    final dynamic d = value;
    final DateTime dt = d.toDate() as DateTime;
    return dt.toIso8601String();
  } catch (_) {
    return value.toString();
  }
}
