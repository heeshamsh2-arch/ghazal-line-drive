import '../core/result.dart';
import '../models/app_user.dart';
import '../models/order.dart';

/// واجهة مجرّدة لخدمة المصادقة — تسمح بالتبديل بين Firebase ووضع التجربة
abstract class AuthBackend {
  /// تدفّق يغيّر قيمته عند تغيّر حالة تسجيل الدخول
  Stream<void> get authStateChanges;

  /// معرّف المستخدم الحالي (null إذا لم يسجّل الدخول)
  String? get currentUid;

  Future<AppUser?> fetchProfile(String uid);

  Future<OpResult> signIn({
    required String email,
    required String password,
  });

  Future<OpResult> registerCustomer({
    required String name,
    required String phone,
    required String email,
    required String password,
  });

  Future<OpResult> registerWithInviteCode({
    required String name,
    required String phone,
    required String email,
    required String password,
    required String code,
  });

  Future<OpResult> createUserAsManager({
    required String name,
    required String phone,
    required String email,
    required String password,
    required UserRole role,
  });

  Future<String> generateInviteCode(UserRole role);

  Future<void> updateProfile(String uid, Map<String, dynamic> data);

  Future<void> setUserActive(String uid, bool isActive);

  Future<OpResult> changePassword({
    required String currentPassword,
    required String newPassword,
  });

  Future<void> signOut();
}

/// واجهة مجرّدة لخدمة الطلبات
abstract class OrderBackend {
  Stream<List<Order>> watchOrdersFor(AppUser user);

  Stream<Order?> watchOrder(String orderId);

  Stream<List<AppUser>> watchStaff({UserRole? role});

  Stream<List<AppUser>> watchCustomers();

  Future<OpResult> createOrder({
    required AppUser customer,
    required String title,
    required String description,
    required String serviceType,
    required int quantity,
    required DateTime? dueDate,
    required List<SelectedFile> files,
  });

  Future<OpResult> assignOrder({
    required String orderId,
    required AppUser assignee,
    required AppUser manager,
    String? note,
    DateTime? dueDate,
  });

  Future<OpResult> unassignOrder({
    required String orderId,
    required AppUser manager,
  });

  Future<OpResult> changeStatus({
    required String orderId,
    required OrderStatus newStatus,
    required AppUser actor,
    String? note,
  });

  Future<OpResult> addAttachments({
    required String orderId,
    required List<SelectedFile> files,
    required AppUser uploader,
    String? note,
  });

  Future<OpResult> updateManagerFields({
    required String orderId,
    double? price,
    String? managerNote,
    DateTime? dueDate,
    bool clearDueDate = false,
  });

  Future<OpResult> deleteOrder(String orderId);
}

/// واجهة مجرّدة لخدمة الملفات
abstract class StorageBackend {
  Future<UploadResult> uploadFiles({
    required String orderId,
    required List<SelectedFile> files,
    required String uploaderName,
  });

  Future<void> deleteOrderFolder(String orderId);
}

/// نتيجة رفع الملفات
class UploadResult {
  final List<Attachment> attachments;
  final List<String> errorsAr;
  const UploadResult(this.attachments, this.errorsAr);
}

/// ملف تم اختياره من الاستوديو أو المعرض
class SelectedFile {
  final String name;
  final String? path;
  final int sizeBytes;
  final String mimeType;

  const SelectedFile({
    required this.name,
    required this.path,
    required this.sizeBytes,
    required this.mimeType,
  });
}

/// استنتاج نوع MIME من امتداد الملف
String guessMimeType(String fileName) {
  final ext = fileName.contains('.')
      ? fileName.substring(fileName.lastIndexOf('.')).toLowerCase()
      : '';
  switch (ext) {
    case '.jpg':
    case '.jpeg':
      return 'image/jpeg';
    case '.png':
      return 'image/png';
    case '.webp':
      return 'image/webp';
    case '.gif':
      return 'image/gif';
    case '.heic':
      return 'image/heic';
    case '.pdf':
      return 'application/pdf';
    default:
      return 'application/octet-stream';
  }
}

/// هل نوع الملف مسموح به (صور و PDF فقط)
bool isAllowedMime(String mime) =>
    mime.startsWith('image/') || mime == 'application/pdf';

/// عدّ الطلبات لكل حالة
Map<OrderStatus, int> countByStatus(List<Order> orders) {
  final map = <OrderStatus, int>{};
  for (final s in OrderStatus.values) {
    map[s] = 0;
  }
  for (final o in orders) {
    map[o.status] = (map[o.status] ?? 0) + 1;
  }
  return map;
}

/// عدد الطلبات المفتوحة (لم تُسلَّم بعد)
int openCount(List<Order> orders) =>
    orders.where((o) => o.status.isOpen).length;
