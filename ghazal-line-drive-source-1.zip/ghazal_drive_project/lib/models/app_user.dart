/// أدوار المستخدمين في النظام
enum UserRole {
  customer, // عميل
  worker, // عامل
  designer, // مصمم
  manager, // مدير
}

extension UserRoleX on UserRole {
  /// المعرّف المخزَّن في قاعدة البيانات
  String get id => name;

  /// الاسم العربي المعروض
  String get labelAr {
    switch (this) {
      case UserRole.customer:
        return 'عميل';
      case UserRole.worker:
        return 'عامل';
      case UserRole.designer:
        return 'مصمم';
      case UserRole.manager:
        return 'مدير';
    }
  }

  /// الاسم بالإنجليزية
  String get labelEn {
    switch (this) {
      case UserRole.customer:
        return 'Customer';
      case UserRole.worker:
        return 'Worker';
      case UserRole.designer:
        return 'Designer';
      case UserRole.manager:
        return 'Manager';
    }
  }

  bool get isManager => this == UserRole.manager;

  /// هل ينفّذ طلبات (عامل/مصمم)
  bool get isStaff => this == UserRole.worker || this == UserRole.designer;

  static UserRole fromId(String? id) {
    return UserRole.values.firstWhere(
      (r) => r.name == id,
      orElse: () => UserRole.customer,
    );
  }
}

/// نموذج المستخدم كما يُخزَّن في Firestore
class AppUser {
  final String id;
  final String name;
  final String phone;
  final String email;
  final UserRole role;
  final bool isActive;
  final String? notes;
  final DateTime createdAt;

  const AppUser({
    required this.id,
    required this.name,
    required this.phone,
    required this.email,
    required this.role,
    this.isActive = true,
    this.notes,
    required this.createdAt,
  });

  /// الأحرف الأولى من الاسم (لصورة الحساب)
  String get initials {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return '؟';
    final parts = trimmed.split(RegExp(r'\s+'));
    if (parts.length >= 2 && parts[0].isNotEmpty && parts[1].isNotEmpty) {
      return '${parts[0][0]}${parts[1][0]}';
    }
    return trimmed[0];
  }

  factory AppUser.fromMap(Map<String, dynamic> map, String id) {
    final rawName = (map['name'] as String?)?.trim() ?? '';
    return AppUser(
      id: id,
      name: rawName.isEmpty ? 'مستخدم' : rawName,
      phone: (map['phone'] as String?) ?? '',
      email: (map['email'] as String?) ?? '',
      role: UserRoleX.fromId(map['role'] as String?),
      isActive: map['isActive'] as bool? ?? true,
      notes: map['notes'] as String?,
      createdAt: parseFirestoreDate(map['createdAt']) ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'name': name,
      'phone': phone,
      'email': email,
      'role': role.id,
      'isActive': isActive,
      'notes': notes,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': DateTime.now().toIso8601String(),
    };
  }

  AppUser copyWith({
    String? name,
    String? phone,
    String? email,
    UserRole? role,
    bool? isActive,
    String? notes,
  }) {
    return AppUser(
      id: id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      role: role ?? this.role,
      isActive: isActive ?? this.isActive,
      notes: notes ?? this.notes,
      createdAt: createdAt,
    );
  }
}

/// تحويل آمن لأنواع التاريخ القادمة من Firestore
DateTime? parseFirestoreDate(Object? value) {
  if (value is DateTime) return value;
  if (value is String) return DateTime.tryParse(value);
  if (value is int) {
    return DateTime.fromMillisecondsSinceEpoch(value);
  }
  return null;
}
