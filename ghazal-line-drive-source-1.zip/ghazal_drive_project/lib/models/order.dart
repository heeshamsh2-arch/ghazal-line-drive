import 'app_user.dart';

/// حالات الطلب
enum OrderStatus {
  newRequest, // طلب جديد بانتظار مراجعة المدير
  underReview, // قيد المراجعة
  missingInfo, // طلب ناقص (يحتاج معلومة من العميل)
  assigned, // مُسند لموظف/مصمم
  inProgress, // قيد التنفيذ
  ready, // جاهز للتسليم
  delivered, // تم التسليم
  cancelled, // ملغي
}

extension OrderStatusX on OrderStatus {
  String get id => name;

  String get labelAr {
    switch (this) {
      case OrderStatus.newRequest:
        return 'طلب جديد';
      case OrderStatus.underReview:
        return 'قيد المراجعة';
      case OrderStatus.missingInfo:
        return 'طلب ناقص';
      case OrderStatus.assigned:
        return 'مُسند لموظف';
      case OrderStatus.inProgress:
        return 'قيد التنفيذ';
      case OrderStatus.ready:
        return 'جاهز للتسليم';
      case OrderStatus.delivered:
        return 'تم التسليم';
      case OrderStatus.cancelled:
        return 'ملغي';
    }
  }

  /// وصف موجز يظهر تحت العنوان
  String get hintAr {
    switch (this) {
      case OrderStatus.newRequest:
        return 'بانتظار مراجعة المدير';
      case OrderStatus.underReview:
        return 'المدير يراجع تفاصيل الطلب';
      case OrderStatus.missingInfo:
        return 'بانتظار رد العميل بمعلومات ناقصة';
      case OrderStatus.assigned:
        return 'تم إسناد الطلب لموظف';
      case OrderStatus.inProgress:
        return 'العمل جارٍ التنفيذ';
      case OrderStatus.ready:
        return 'الطلب جاهز للاستلام';
      case OrderStatus.delivered:
        return 'تم تسليم الطلب للعميل';
      case OrderStatus.cancelled:
        return 'تم إلغاء الطلب';
    }
  }

  int get colorValue {
    switch (this) {
      case OrderStatus.newRequest:
        return 0xFF0284C7; // أزرق
      case OrderStatus.underReview:
        return 0xFF7C3AED; // بنفسجي
      case OrderStatus.missingInfo:
        return 0xFFDC2626; // أحمر
      case OrderStatus.assigned:
        return 0xFF0891B2; // تركوازي
      case OrderStatus.inProgress:
        return 0xFFD97706; // برتقالي
      case OrderStatus.ready:
        return 0xFF059669; // أخضر
      case OrderStatus.delivered:
        return 0xFF15803D; // أخضر غامق
      case OrderStatus.cancelled:
        return 0xFF6B7280; // رمادي
    }
  }

  /// هل الطلب ما زال مفتوحاً (لم يُسلَّم ولم يُلغَ)
  bool get isOpen => this != OrderStatus.delivered && this != OrderStatus.cancelled;

  /// هل الطلب في مرحلة تنفيذ فعلية
  bool get isBeingWorked =>
      this == OrderStatus.assigned ||
      this == OrderStatus.inProgress ||
      this == OrderStatus.ready;

  /// الحالات التي يستطيع العامل/المصمم الانتقال إليها
  static List<OrderStatus> get staffNext => const <OrderStatus>[
        OrderStatus.inProgress,
        OrderStatus.ready,
        OrderStatus.missingInfo,
      ];

  /// الحالات التي يستطيع المدير الانتقال إليها
  static List<OrderStatus> get managerNext => OrderStatus.values
      .where((s) => s != OrderStatus.newRequest)
      .toList(growable: false);

  static OrderStatus fromId(String? id) {
    return OrderStatus.values.firstWhere(
      (s) => s.name == id,
      orElse: () => OrderStatus.newRequest,
    );
  }
}

/// مرفق (صورة أو ملف PDF)
class Attachment {
  final String id;
  final String url;
  final String fileName;
  final String mimeType;
  final int sizeBytes;
  final String uploadedByName;
  final DateTime uploadedAt;

  const Attachment({
    required this.id,
    required this.url,
    required this.fileName,
    required this.mimeType,
    required this.sizeBytes,
    required this.uploadedByName,
    required this.uploadedAt,
  });

  bool get isImage => mimeType.startsWith('image/');
  bool get isPdf => mimeType == 'application/pdf';

  String get kindLabel {
    if (isImage) return 'صورة';
    if (isPdf) return 'PDF';
    return 'ملف';
  }

  factory Attachment.fromMap(Map<String, dynamic> map, String id) {
    return Attachment(
      id: id,
      url: (map['url'] as String?) ?? '',
      fileName: (map['fileName'] as String?) ?? 'ملف',
      mimeType: (map['mimeType'] as String?) ?? 'application/octet-stream',
      sizeBytes: (map['sizeBytes'] as num?)?.toInt() ?? 0,
      uploadedByName: (map['uploadedByName'] as String?) ?? '—',
      uploadedAt: parseFirestoreDate(map['uploadedAt']) ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => <String, dynamic>{
        'url': url,
        'fileName': fileName,
        'mimeType': mimeType,
        'sizeBytes': sizeBytes,
        'uploadedByName': uploadedByName,
        'uploadedAt': uploadedAt.toIso8601String(),
      };
}

/// حدث في سجل تتبّع حالة الطلب
class StatusEvent {
  final String id;
  final OrderStatus status;
  final String note;
  final String actorName;
  final UserRole actorRole;
  final DateTime at;

  const StatusEvent({
    required this.id,
    required this.status,
    required this.note,
    required this.actorName,
    required this.actorRole,
    required this.at,
  });

  factory StatusEvent.fromMap(Map<String, dynamic> map, String id) {
    return StatusEvent(
      id: id,
      status: OrderStatusX.fromId(map['status'] as String?),
      note: (map['note'] as String?) ?? '',
      actorName: (map['actorName'] as String?) ?? '—',
      actorRole: UserRoleX.fromId(map['actorRole'] as String?),
      at: parseFirestoreDate(map['at']) ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => <String, dynamic>{
        'status': status.id,
        'note': note,
        'actorName': actorName,
        'actorRole': actorRole.id,
        'at': at.toIso8601String(),
      };
}

/// نموذج الطلب
class Order {
  final String id;

  // بيانات العميل
  final String customerId;
  final String customerName;
  final String customerPhone;

  // محتوى الطلب
  final String title;
  final String description;
  final String serviceType;
  final int quantity;
  final List<Attachment> attachments;

  // الحالة والتوزيع
  final OrderStatus status;
  final String? assigneeId;
  final String? assigneeName;
  final String? assigneeRole;

  // تفاصيل إضافية
  final DateTime? dueDate;
  final double? price;
  final String managerNote;
  final List<StatusEvent> history;

  final DateTime createdAt;
  final DateTime updatedAt;

  const Order({
    required this.id,
    required this.customerId,
    required this.customerName,
    required this.customerPhone,
    required this.title,
    required this.description,
    required this.serviceType,
    required this.quantity,
    required this.attachments,
    required this.status,
    this.assigneeId,
    this.assigneeName,
    this.assigneeRole,
    this.dueDate,
    this.price,
    this.managerNote = '',
    required this.history,
    required this.createdAt,
    required this.updatedAt,
  });

  bool get isAssigned =>
      assigneeId != null && assigneeId!.isNotEmpty && assigneeId!.isNotEmpty;

  bool get isLate {
    if (dueDate == null) return false;
    if (!status.isOpen) return false;
    return DateTime.now().isAfter(dueDate!);
  }

  int get imageCount => attachments.where((a) => a.isImage).length;
  int get pdfCount => attachments.where((a) => a.isPdf).length;

  /// هل الطلب في انتظار رد العميل؟
  bool get waitingCustomer => status == OrderStatus.missingInfo;

  Order copyWith({
    String? title,
    String? description,
    String? serviceType,
    int? quantity,
    List<Attachment>? attachments,
    OrderStatus? status,
    String? assigneeId,
    String? assigneeName,
    String? assigneeRole,
    DateTime? dueDate,
    double? price,
    String? managerNote,
    List<StatusEvent>? history,
    DateTime? updatedAt,
    bool clearAssignee = false,
  }) {
    return Order(
      id: id,
      customerId: customerId,
      customerName: customerName,
      customerPhone: customerPhone,
      title: title ?? this.title,
      description: description ?? this.description,
      serviceType: serviceType ?? this.serviceType,
      quantity: quantity ?? this.quantity,
      attachments: attachments ?? this.attachments,
      status: status ?? this.status,
      assigneeId: clearAssignee ? null : (assigneeId ?? this.assigneeId),
      assigneeName: clearAssignee ? null : (assigneeName ?? this.assigneeName),
      assigneeRole: clearAssignee ? null : (assigneeRole ?? this.assigneeRole),
      dueDate: dueDate ?? this.dueDate,
      price: price ?? this.price,
      managerNote: managerNote ?? this.managerNote,
      history: history ?? this.history,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  factory Order.fromMap(Map<String, dynamic> map, String id) {
    final rawAttachments = (map['attachments'] as List<dynamic>?) ?? <dynamic>[];
    final rawHistory = (map['history'] as List<dynamic>?) ?? <dynamic>[];

    return Order(
      id: id,
      customerId: (map['customerId'] as String?) ?? '',
      customerName: (map['customerName'] as String?) ?? 'عميل',
      customerPhone: (map['customerPhone'] as String?) ?? '',
      title: (map['title'] as String?) ?? 'طلب',
      description: (map['description'] as String?) ?? '',
      serviceType: (map['serviceType'] as String?) ?? 'أخرى',
      quantity: (map['quantity'] as num?)?.toInt() ?? 1,
      attachments: rawAttachments
          .whereType<Map<String, dynamic>>()
          .toList()
          .asMap()
          .entries
          .map((e) => Attachment.fromMap(e.value, 'a${e.key}'))
          .toList(),
      status: OrderStatusX.fromId(map['status'] as String?),
      assigneeId: map['assigneeId'] as String?,
      assigneeName: map['assigneeName'] as String?,
      assigneeRole: map['assigneeRole'] as String?,
      dueDate: parseFirestoreDate(map['dueDate']),
      price: (map['price'] as num?)?.toDouble(),
      managerNote: (map['managerNote'] as String?) ?? '',
      history: rawHistory
          .whereType<Map<String, dynamic>>()
          .toList()
          .asMap()
          .entries
          .map((e) => StatusEvent.fromMap(e.value, 'h${e.key}'))
          .toList(),
      createdAt: parseFirestoreDate(map['createdAt']) ?? DateTime.now(),
      updatedAt: parseFirestoreDate(map['updatedAt']) ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => <String, dynamic>{
        'customerId': customerId,
        'customerName': customerName,
        'customerPhone': customerPhone,
        'title': title,
        'description': description,
        'serviceType': serviceType,
        'quantity': quantity,
        'attachments': attachments
            .map((a) => <String, dynamic>{'id': a.id, ...a.toMap()})
            .toList(),
        'status': status.id,
        'assigneeId': assigneeId,
        'assigneeName': assigneeName,
        'assigneeRole': assigneeRole,
        'dueDate': dueDate?.toIso8601String(),
        'price': price,
        'managerNote': managerNote,
        'history': history
            .map((h) => <String, dynamic>{'id': h.id, ...h.toMap()})
            .toList(),
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };
}
