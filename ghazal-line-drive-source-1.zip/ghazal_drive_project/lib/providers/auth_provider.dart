import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/result.dart';
import '../models/app_user.dart';
import '../services/backends.dart';

/// مفاتيح التخزين المحلي
const String _kSavedEmail = 'saved_email';
const String _kSavedPassword = 'saved_password';
const String _kRememberMe = 'remember_me';

/// إدارة حالة المستخدم الحالي (تسجيل دخول/خروج + الملف الشخصي + تذكر تسجيل الدخول)
class AuthProvider extends ChangeNotifier {
  AuthProvider(this._auth) {
    _sub = _auth.authStateChanges.listen((_) => _onAuthChanged());
    // فحص الحالة الأولى: قد لا يُطلق المصدر أي قيمة عند الإقلاع
    unawaited(_initAuth());
  }

  final AuthBackend _auth;
  StreamSubscription<void>? _sub;

  AppUser? _user;
  bool _loading = true;
  String? _errorAr;

  AppUser? get user => _user;
  bool get isLoading => _loading;
  String? get errorAr => _errorAr;
  bool get isLoggedIn => _user != null;
  UserRole get role => _user?.role ?? UserRole.customer;
  bool get isManager => _user?.role.isManager ?? false;
  bool get isStaff => _user?.role.isStaff ?? false;
  bool get isCustomer => _user?.role == UserRole.customer;

  /// تهيئة المصادقة: محاولة استعادة الجلسة المحفوظة
  Future<void> _initAuth() async {
    final prefs = await SharedPreferences.getInstance();
    final remember = prefs.getBool(_kRememberMe) ?? false;

    if (remember) {
      final email = prefs.getString(_kSavedEmail);
      final password = prefs.getString(_kSavedPassword);
      if (email != null && password != null && email.isNotEmpty && password.isNotEmpty) {
        // محاولة تسجيل دخول صامت
        final result = await _auth.signIn(email: email, password: password);
        if (result.success) {
          // _onAuthChanged ستُستدعى تلقائياً عبر stream
          return;
        }
        // إذا فشل، نمسح البيانات المحفوظة
        await _clearSavedCredentials(prefs);
      }
    }
    // لا يوجد جلسة محفوظة أو فشلت — ننهي التحميل
    _loading = false;
    notifyListeners();
  }

  Future<void> _onAuthChanged() async {
    final uid = _auth.currentUid;
    if (uid == null) {
      _user = null;
      _loading = false;
      _errorAr = null;
      notifyListeners();
      return;
    }

    try {
      _user = await _auth.fetchProfile(uid);
      if (_user != null && !_user!.isActive) {
        await _auth.signOut();
        _errorAr = 'تم إيقاف هذا الحساب. راجع مدير النظام.';
        _user = null;
      }
    } catch (e) {
      _errorAr = 'تعذّر تحميل بيانات الحساب. $e';
      _user = null;
    }
    _loading = false;
    notifyListeners();
  }

  Future<OpResult> signIn(String email, String password, {bool rememberMe = false}) async {
    _errorAr = null;
    final result = await _auth.signIn(email: email, password: password);
    if (result.success && rememberMe) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_kSavedEmail, email);
      await prefs.setString(_kSavedPassword, password);
      await prefs.setBool(_kRememberMe, true);
    }
    if (!result.success) _errorAr = result.errorAr;
    return result;
  }

  Future<OpResult> registerCustomer({
    required String name,
    required String phone,
    required String email,
    required String password,
  }) async {
    return _auth.registerCustomer(
      name: name,
      phone: phone,
      email: email,
      password: password,
    );
  }

  Future<OpResult> registerWithCode({
    required String name,
    required String phone,
    required String email,
    required String password,
    required String code,
  }) async {
    return _auth.registerWithInviteCode(
      name: name,
      phone: phone,
      email: email,
      password: password,
      code: code,
    );
  }

  Future<void> signOut() async {
    await _auth.signOut();
    // مسح البيانات المحفوظة عند تسجيل الخروج
    final prefs = await SharedPreferences.getInstance();
    await _clearSavedCredentials(prefs);
  }

  Future<void> _clearSavedCredentials(SharedPreferences prefs) async {
    await prefs.remove(_kSavedEmail);
    await prefs.remove(_kSavedPassword);
    await prefs.setBool(_kRememberMe, false);
  }

  Future<void> refreshProfile() async {
    final uid = _auth.currentUid;
    if (uid == null) return;
    _user = await _auth.fetchProfile(uid);
    notifyListeners();
  }

  void clearError() {
    if (_errorAr == null) return;
    _errorAr = null;
    notifyListeners();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}