import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'core/constants.dart';
import 'core/theme.dart';
import 'providers/auth_provider.dart';
import 'services/backends.dart';
import 'services/drive_api_client.dart';
import 'services/drive_backends.dart';
import 'ui/screens/auth/drive_setup_screen.dart';
import 'ui/screens/auth/login_screen.dart';
import 'ui/screens/shell/main_shell.dart';
import 'ui/widgets/common.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterError.onError = (details) {
    FlutterError.presentError(details);
    debugPrint('خطأ في الواجهة: ${details.exception}');
  };
  final config = await DriveConnectionConfig.load();
  runApp(GhazalLineApp(initialConfig: config));
}

class GhazalLineApp extends StatefulWidget {
  const GhazalLineApp({super.key, required this.initialConfig});
  final DriveConnectionConfig? initialConfig;

  @override
  State<GhazalLineApp> createState() => _GhazalLineAppState();
}

class _GhazalLineAppState extends State<GhazalLineApp> {
  DriveConnectionConfig? _config;
  late int _generation;

  @override
  void initState() { super.initState(); _config = widget.initialConfig; _generation = 0; }

  Future<void> _reloadConfig() async {
    final c = await DriveConnectionConfig.load();
    if (!mounted) return;
    setState(() { _config = c; _generation++; });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox.shrink()),
      home: _config == null
          ? DriveSetupScreen(onSaved: _reloadConfig)
          : _ConnectedApp(key: ValueKey(_generation), config: _config!),
    );
  }
}

class _ConnectedApp extends StatelessWidget {
  const _ConnectedApp({super.key, required this.config});
  final DriveConnectionConfig config;

  @override
  Widget build(BuildContext context) {
    final api = DriveApiClient(config.endpoint);
    final auth = DriveAuthBackend(api);
    final orders = DriveOrderBackend(api);
    return MultiProvider(
      providers: [
        Provider<AuthBackend>.value(value: auth),
        Provider<OrderBackend>.value(value: orders),
        Provider<StorageBackend>.value(value: orders),
        ChangeNotifierProvider<AuthProvider>(create: (_) => AuthProvider(auth)),
      ],
      child: const _AuthGate(),
    );
  }
}

class _AuthGate extends StatelessWidget {
  const _AuthGate();
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    if (auth.isLoading) return const _SplashScreen();
    if (auth.isLoggedIn) return const MainShell();
    return const LoginScreen();
  }
}

class _SplashScreen extends StatelessWidget {
  const _SplashScreen();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const AppLogo(size: AppConstants.logoSplash),
        const SizedBox(height: 20),
        const Text(AppConstants.appName, style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Text('Google Drive — قاعدة المدير', style: TextStyle(color: Colors.white.withValues(alpha: .85), fontSize: 13.5)),
        const SizedBox(height: 32),
        const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Colors.white70)),
      ])),
    );
  }
}
