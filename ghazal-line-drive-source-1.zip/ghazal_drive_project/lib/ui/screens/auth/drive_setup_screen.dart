import 'package:flutter/material.dart';

import '../../../core/theme.dart';
import '../../../services/drive_api_client.dart';
import '../../widgets/common.dart';

class DriveSetupScreen extends StatefulWidget {
  const DriveSetupScreen({super.key, required this.onSaved});
  final VoidCallback onSaved;

  @override
  State<DriveSetupScreen> createState() => _DriveSetupScreenState();
}

class _DriveSetupScreenState extends State<DriveSetupScreen> {
  final _ctrl = TextEditingController();
  bool _busy = false;

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  Future<void> _save() async {
    final value = _ctrl.text.trim();
    if (value.isEmpty) { showSnack(context, 'أدخل رابط الربط الذي أنشأه المدير.', isError: true); return; }
    setState(() => _busy = true);
    try {
      await DriveConnectionConfig.save(value);
      final api = DriveApiClient(value);
      await api.call('ping', requiresAuth: false);
      if (!mounted) return;
      showSnack(context, 'تم ربط التطبيق بقاعدة Google Drive.');
      widget.onSaved();
    } catch (e) {
      if (mounted) showSnack(context, e.toString(), isError: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const Icon(Icons.cloud_done_outlined, size: 64, color: AppColors.primary),
                    const SizedBox(height: 16),
                    const Text('ربط قاعدة Google Drive', textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 10),
                    const Text(
                      'أدخل رابط الربط الذي أنشأه مدير التطبيق من Google Apps Script. قاعدة البيانات نفسها تبقى داخل Google Drive الخاص بالمدير، ولا يحصل العميل على صلاحية تعديلها.',
                      textAlign: TextAlign.center,
                      style: TextStyle(height: 1.6, color: AppColors.textMuted),
                    ),
                    const SizedBox(height: 22),
                    TextField(
                      controller: _ctrl,
                      textDirection: TextDirection.ltr,
                      keyboardType: TextInputType.url,
                      decoration: const InputDecoration(
                        labelText: 'رابط Google Drive / Apps Script',
                        hintText: 'https://script.google.com/macros/s/.../exec',
                        prefixIcon: Icon(Icons.link),
                      ),
                    ),
                    const SizedBox(height: 18),
                    ElevatedButton.icon(
                      onPressed: _busy ? null : _save,
                      icon: _busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.link),
                      label: const Text('اتصال وحفظ'),
                    ),
                    const SizedBox(height: 14),
                    const Text('المدير فقط يستطيع التعديل والحذف والإسناد. العميل يستطيع إنشاء طلب ورفع ملفاته فقط.',
                      textAlign: TextAlign.center, style: TextStyle(fontSize: 12.5, color: AppColors.textMuted)),
                  ]),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
