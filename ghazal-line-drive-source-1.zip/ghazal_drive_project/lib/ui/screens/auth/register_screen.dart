import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../core/theme.dart';
import '../../../providers/auth_provider.dart';
import '../../widgets/common.dart';
import '../../../core/constants.dart';

/// شاشة إنشاء حساب: إمّا عميل جديد أو موظف/مصمم بكود دعوة
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();

  bool _isStaff = false;
  bool _obscure = true;
  bool _obscureConfirm = true;
  bool _busy = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _confirmCtrl.dispose();
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    setState(() => _busy = true);

    final auth = context.read<AuthProvider>();
    final result = _isStaff
        ? await auth.registerWithCode(
            name: _nameCtrl.text,
            phone: _phoneCtrl.text,
            email: _emailCtrl.text,
            password: _passCtrl.text,
            code: _codeCtrl.text,
          )
        : await auth.registerCustomer(
            name: _nameCtrl.text,
            phone: _phoneCtrl.text,
            email: _emailCtrl.text,
            password: _passCtrl.text,
          );

    if (!mounted) return;
    setState(() => _busy = false);

    if (result.success) {
      showSnack(context, 'تم إنشاء الحساب بنجاح');
      Navigator.of(context).pop();
    } else {
      showSnack(context, result.errorAr ?? 'تعذّر إنشاء الحساب', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إنشاء حساب جديد')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // اختيار نوع الحساب
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    children: [
                      _typeButton(
                        label: 'عميل',
                        icon: Icons.person_outline,
                        selected: !_isStaff,
                        onTap: () => setState(() => _isStaff = false),
                      ),
                      _typeButton(
                        label: 'موظف / مصمم',
                        icon: Icons.badge_outlined,
                        selected: _isStaff,
                        onTap: () => setState(() => _isStaff = true),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                if (_isStaff)
                  const AlertBanner(
                    message:
                        'حسابات الموظفين تُنشأ بكود دعوة من مدير النظام. '
                        'اطلب الكود منه ثم أكمل البيانات.',
                    color: AppColors.info,
                    icon: Icons.key_outlined,
                  )
                else
                  const AlertBanner(
                    message: 'سجّل كعميل لتتمكن من رفع الطلبات ومتابعة حالتها.',
                    color: AppColors.success,
                    icon: Icons.verified_outlined,
                  ),
                const SizedBox(height: 18),

                // الاسم
                TextFormField(
                  controller: _nameCtrl,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(
                    labelText: 'الاسم الكامل',
                    prefixIcon: Icon(Icons.person_outline, size: AppConstants.iconInput),
                  ),
                  validator: (v) {
                    final value = v?.trim() ?? '';
                    if (value.isEmpty) return 'أدخل الاسم';
                    if (value.length < 3) return 'الاسم قصير جداً';
                    return null;
                  },
                ),
                const SizedBox(height: 14),

                // الجوال
                TextFormField(
                  controller: _phoneCtrl,
                  keyboardType: TextInputType.phone,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(
                    labelText: 'رقم الجوال',
                    hintText: '05xxxxxxxx',
                    prefixIcon: Icon(Icons.phone_iphone, size: AppConstants.iconInput),
                  ),
                  validator: (v) {
                    final value = v?.trim() ?? '';
                    if (value.isEmpty) return 'أدخل رقم الجوال';
                    if (value.length < 9) return 'رقم الجوال غير صحيح';
                    return null;
                  },
                ),
                const SizedBox(height: 14),

                // البريد
                TextFormField(
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  textDirection: TextDirection.ltr,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(
                    labelText: 'البريد الإلكتروني',
                    hintText: 'name@example.com',
                    prefixIcon: Icon(Icons.alternate_email, size: AppConstants.iconInput),
                  ),
                  validator: (v) {
                    final value = v?.trim() ?? '';
                    if (value.isEmpty) return 'أدخل البريد الإلكتروني';
                    if (!value.contains('@') || !value.contains('.')) {
                      return 'صيغة البريد غير صحيحة';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 14),

                // كود الدعوة (للموظفين فقط)
                if (_isStaff) ...[
                  TextFormField(
                    controller: _codeCtrl,
                    textCapitalization: TextCapitalization.characters,
                    textDirection: TextDirection.ltr,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9]')),
                      LengthLimitingTextInputFormatter(8),
                    ],
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(
                      labelText: 'كود الدعوة',
                      hintText: 'XXXXXXXX',
                      prefixIcon: Icon(Icons.key, size: AppConstants.iconInput),
                    ),
                    validator: (v) {
                      if (_isStaff && (v == null || v.trim().length < 6)) {
                        return 'أدخل كود الدعوة';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 14),
                ],

                // كلمة المرور
                TextFormField(
                  controller: _passCtrl,
                  obscureText: _obscure,
                  textDirection: TextDirection.ltr,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    labelText: 'كلمة المرور',
                    prefixIcon: const Icon(Icons.lock_outline, size: AppConstants.iconInput),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscure
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        size: AppConstants.iconInput,
                      ),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                  validator: (v) {
                    if (v == null || v.isEmpty) return 'أدخل كلمة المرور';
                    return null;
                  },
                ),
                const SizedBox(height: 14),

                // تأكيد كلمة المرور
                TextFormField(
                  controller: _confirmCtrl,
                  obscureText: _obscureConfirm,
                  textDirection: TextDirection.ltr,
                  onFieldSubmitted: (_) => _submit(),
                  decoration: InputDecoration(
                    labelText: 'تأكيد كلمة المرور',
                    prefixIcon: const Icon(Icons.lock_reset, size: AppConstants.iconInput),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscureConfirm
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        size: AppConstants.iconInput,
                      ),
                      onPressed: () =>
                          setState(() => _obscureConfirm = !_obscureConfirm),
                    ),
                  ),
                  validator: (v) {
                    if (v == null || v.isEmpty) return 'أكّد كلمة المرور';
                    if (v != _passCtrl.text) return 'كلمتا المرور غير متطابقتين';
                    return null;
                  },
                ),
                const SizedBox(height: 26),

                ElevatedButton(
                  onPressed: _busy ? null : _submit,
                  child: _busy
                      ? const SizedBox(
                          height: 22,
                          width: 22,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.4,
                            color: Colors.white,
                          ),
                        )
                      : Text(_isStaff ? 'إنشاء حساب موظف' : 'إنشاء الحساب'),
                ),
                const SizedBox(height: 10),
                const Text(
                  'بإنشائك حساباً فأنت توافق على سياسة الاستخدام',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11.5, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _typeButton({
    required String label,
    required IconData icon,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(11),
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.08),
                      blurRadius: 8,
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: AppConstants.iconLeading,
                color: selected ? AppColors.primary : AppColors.textMuted,
              ),
              const SizedBox(width: 7),
              Text(
                label,
                style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                  color: selected ? AppColors.primary : AppColors.textMuted,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

