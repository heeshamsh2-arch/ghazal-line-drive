import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants.dart';
import '../../../core/theme.dart';
import '../../../models/app_user.dart';
import '../../../providers/auth_provider.dart';
import '../../widgets/common.dart';
import '../customer/new_order_screen.dart';
import '../manager/manage_users_screen.dart';
import '../orders/orders_list_screen.dart';
import '../profile/profile_screen.dart';

/// الهيكل الرئيسي: شريط تبويب سفلي يتكيّف مع دور المستخدم
class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;
    if (user == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final tabs = _tabsFor(user.role);
    final safeIndex = _index.clamp(0, tabs.length - 1);

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(tabs[safeIndex].title),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                user.role.labelAr,
                style: const TextStyle(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                  color: AppColors.primary,
                ),
              ),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: UserAvatar(initials: user.initials, size: 34),
          ),
        ],
      ),
      body: IndexedStack(
        index: safeIndex,
        children: [
          for (final tab in tabs) Builder(builder: tab.builder),
        ],
      ),
      floatingActionButton: _fabFor(user.role, safeIndex),
      bottomNavigationBar: NavigationBar(
        selectedIndex: safeIndex,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          for (final tab in tabs)
            NavigationDestination(
              icon: Icon(tab.icon),
              selectedIcon: Icon(tab.selectedIcon ?? tab.icon),
              label: tab.title,
            ),
        ],
      ),
    );
  }

  /// زر عائم: العميل يستطيع رفع طلب جديد
  Widget? _fabFor(UserRole role, int index) {
    if (role != UserRole.customer) return null;
    if (index != 0) return null;

    return FloatingActionButton.extended(
      onPressed: () => Navigator.of(context).push<bool>(
        MaterialPageRoute(builder: (_) => const NewOrderScreen()),
      ),
      backgroundColor: AppColors.primary,
      foregroundColor: Colors.white,
      icon: const Icon(Icons.add),
      label: const Text(
        'طلب جديد',
        style: TextStyle(fontWeight: FontWeight.w700),
      ),
    );
  }

  List<_TabItem> _tabsFor(UserRole role) {
    if (role.isManager) {
      return const <_TabItem>[
        _TabItem(
          title: 'الطلبات',
          icon: Icons.receipt_long_outlined,
          selectedIcon: Icons.receipt_long,
          builder: _buildOrders,
        ),
        _TabItem(
          title: 'الحسابات',
          icon: Icons.people_outline,
          selectedIcon: Icons.people,
          builder: _buildUsers,
        ),
        _TabItem(
          title: 'حسابي',
          icon: Icons.person_outline,
          selectedIcon: Icons.person,
          builder: _buildProfile,
        ),
      ];
    }

    if (role.isStaff) {
      return const <_TabItem>[
        _TabItem(
          title: 'مهامي',
          icon: Icons.assignment_outlined,
          selectedIcon: Icons.assignment,
          builder: _buildOrders,
        ),
        _TabItem(
          title: 'حسابي',
          icon: Icons.person_outline,
          selectedIcon: Icons.person,
          builder: _buildProfile,
        ),
      ];
    }

    // العميل
    return const <_TabItem>[
      _TabItem(
        title: 'طلباتي',
        icon: Icons.receipt_long_outlined,
        selectedIcon: Icons.receipt_long,
        builder: _buildOrders,
      ),
      _TabItem(
        title: 'حسابي',
        icon: Icons.person_outline,
        selectedIcon: Icons.person,
        builder: _buildProfile,
      ),
    ];
  }

  // ── بناة التبويبات ──────────────────────────────────────
  static Widget _buildOrders(BuildContext context) =>
      const OrdersListScreen();

  static Widget _buildUsers(BuildContext context) => const ManageUsersScreen();

  static Widget _buildProfile(BuildContext context) => const ProfileScreen();
}

class _TabItem {
  const _TabItem({
    required this.title,
    required this.icon,
    required this.builder,
    this.selectedIcon,
  });

  final String title;
  final IconData icon;
  final IconData? selectedIcon;
  final WidgetBuilder builder;
}
