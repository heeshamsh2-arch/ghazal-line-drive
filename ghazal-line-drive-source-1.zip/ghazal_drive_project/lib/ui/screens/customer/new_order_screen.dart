import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../../core/constants.dart';
import '../../../core/date_format.dart';
import '../../../core/theme.dart';
import '../../../models/app_user.dart';
import '../../../models/order.dart';
import '../../../providers/auth_provider.dart';
import '../../../services/backends.dart';
import '../../widgets/common.dart';

/// شاشة رفع طلب جديد (العميل)
class NewOrderScreen extends StatefulWidget {
  const NewOrderScreen({super.key});

  @override
  State<NewOrderScreen> createState() => _NewOrderScreenState();
}

class _NewOrderScreenState extends State<NewOrderScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();

  String _serviceType = AppConstants.serviceTypes.first;
  int _quantity = 1;
  DateTime? _dueDate;
  final List<SelectedFile> _files = <SelectedFile>[];
  bool _busy = false;

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  // ── اختيار ملفات من الجهاز ────────────────────────────────
  Future<void> _pickFiles() async {
    try {
      final picked = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'gif'],
      );
      if (picked.isEmpty) return;

      for (final pf in picked) {
        if (pf.path == null) continue;
        _files.add(SelectedFile(
          name: pf.name,
          path: pf.path,
          sizeBytes: await pf.length() ?? 0,
          mimeType: guessMimeType(pf.name),
        ));
      }
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر فتح الملفات. $e', isError: true);
    }
  }

  // ── التقاط صورة بالكاميرا ────────────────────────────────
  Future<void> _takePhoto() async {
    try {
      final picker = ImagePicker();
      final shot = await picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 85,
        maxWidth: 2000,
      );
      if (shot == null) return;

      _files.add(SelectedFile(
        name: shot.name,
        path: shot.path,
        sizeBytes: await shot.length(),
        mimeType: shot.mimeType ?? 'image/jpeg',
      ));
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر فتح الكاميرا. $e', isError: true);
    }
  }

  void _removeFile(int index) {
    setState(() => _files.removeAt(index));
  }

  Future<void> _pickDueDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _dueDate ?? now.add(const Duration(days: 3)),
      firstDate: now,
      lastDate: now.add(const Duration(days: 365)),
      helpText: 'اختر موعد التسليم المطلوب',
    );
    if (picked != null) setState(() => _dueDate = picked);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_files.isEmpty) {
      showSnack(context, 'أرفق صورة واحدة على الأقل أو ملف PDF', isError: true);
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() => _busy = true);

    final auth = context.read<AuthProvider>();
    final service = context.read<OrderBackend>();
    final customer = auth.user!;

    final result = await service.createOrder(
      customer: customer,
      title: _titleCtrl.text,
      description: _descCtrl.text,
      serviceType: _serviceType,
      quantity: _quantity,
      dueDate: _dueDate,
      files: _files,
    );

    if (!mounted) return;
    setState(() => _busy = false);

    if (result.success) {
      showSnack(context, 'تم رفع الطلب بنجاح — بانتظار مراجعة المدير');
      Navigator.of(context).pop(true);
    } else {
      showSnack(context, result.errorAr ?? 'تعذّر رفع الطلب', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('طلب جديد'),
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            children: [
              // العنوان
              TextFormField(
                controller: _titleCtrl,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'عنوان الطلب *',
                  hintText: 'مثال: طباعة 500 بروشور مطعم',
                ),
                validator: (v) {
                  final value = v?.trim() ?? '';
                  if (value.isEmpty) return 'أدخل عنوان الطلب';
                  return null;
                },
              ),
              const SizedBox(height: 14),

              // نوع الخدمة
              DropdownButtonFormField<String>(
                initialValue: _serviceType,
                decoration: const InputDecoration(
                  labelText: 'نوع الخدمة *',
                  prefixIcon: Icon(Icons.category_outlined, size: AppConstants.iconInput),
                ),
                items: AppConstants.serviceTypes
                    .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                    .toList(),
                onChanged: (v) => setState(() => _serviceType = v ?? _serviceType),
              ),
              const SizedBox(height: 14),

              // الكمية
              Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.cardBorder),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.numbers, size: AppConstants.iconInput, color: AppColors.textMuted),
                          const SizedBox(width: 10),
                          const Text(
                            'الكمية',
                            style: TextStyle(
                              fontSize: 14,
                              color: AppColors.textMuted,
                            ),
                          ),
                          const Spacer(),
                          IconButton(
                            onPressed: _quantity > 1
                                ? () => setState(() => _quantity--)
                                : null,
                            icon: const Icon(Icons.remove_circle_outline, size: 22),
                            visualDensity: VisualDensity.compact,
                          ),
                          Text(
                            '$_quantity',
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          IconButton(
                            onPressed: () => setState(() => _quantity++),
                            icon: const Icon(Icons.add_circle_outline, size: 22),
                            visualDensity: VisualDensity.compact,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),

              // موعد التسليم
              InkWell(
                onTap: _pickDueDate,
                borderRadius: BorderRadius.circular(12),
                child: InputDecorator(
                  decoration: InputDecoration(
                    labelText: 'موعد التسليم المطلوب (اختياري)',
                    prefixIcon: const Icon(Icons.event_outlined, size: AppConstants.iconInput),
                    suffixIcon: _dueDate == null
                        ? const Icon(Icons.chevron_left, size: AppConstants.iconInput)
                        : IconButton(
                            icon: const Icon(Icons.close, size: 18),
                            onPressed: () => setState(() => _dueDate = null),
                          ),
                  ),
                  child: Text(
                    _dueDate == null
                        ? 'غير محدّد'
                        : formatDateAr(_dueDate!),
                    style: TextStyle(
                      fontSize: 14,
                      color: _dueDate == null
                          ? AppColors.textMuted
                          : AppColors.textMain,
                      fontWeight: _dueDate == null
                          ? FontWeight.w400
                          : FontWeight.w600,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 14),

              // التفاصيل
              TextFormField(
                controller: _descCtrl,
                maxLines: 5,
                decoration: const InputDecoration(
                  labelText: 'تفاصيل الطلب *',
                  hintText: 'اكتب المقاسات، الألوان، نوع الورق، والكمية الدقيقة...',
                  alignLabelWithHint: true,
                ),
                validator: (v) {
                  final value = v?.trim() ?? '';
                  if (value.isEmpty) return 'اكتب تفاصيل الطلب';
                  return null;
                },
              ),
              const SizedBox(height: 6),

              // ── المرفقات ──
              const Row(
                children: [
                  Text(
                    'المرفقات *',
                    style: TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textMain,
                    ),
                  ),
                  SizedBox(width: 6),
                  Text(
                    '(صور أو PDF)',
                    style: TextStyle(fontSize: 12.5, color: AppColors.textMuted),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _busy ? null : _pickFiles,
                      icon: const Icon(Icons.attach_file, size: 19),
                      label: const Text('اختيار ملفات'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _busy ? null : _takePhoto,
                      icon: const Icon(Icons.photo_camera_outlined, size: 19),
                      label: const Text('تصوير'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              if (_files.isEmpty)
                const AlertBanner(
                  message:
                      'لم تُضف أي ملفات. أرفق تصميم الطلب أو صورة توضيحية.',
                  color: AppColors.warning,
                  icon: Icons.attach_file,
                )
              else
                ..._files.asMap().entries.map(
                      (entry) => _fileTile(entry.key, entry.value),
                    ),

              const SizedBox(height: 18),

              // زر الإرسال
              ElevatedButton.icon(
                onPressed: _busy ? null : _submit,
                icon: _busy
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.2,
                          color: Colors.white,
                        ),
                      )
                    : const Icon(Icons.send_rounded, size: AppConstants.iconInput),
                label: Text(_busy ? 'جارٍ الرفع...' : 'رفع الطلب'),
              ),
              const SizedBox(height: 8),
              const Text(
                'بعد الرفع سيصل الطلب للمدير الذي يوزّعه على العامل أو المصمم المناسب',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11.5, color: AppColors.textMuted, height: 1.5),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _fileTile(int index, SelectedFile file) {
    final isImage = file.mimeType.startsWith('image/');
    final color = isImage ? AppColors.info : AppColors.danger;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              isImage ? Icons.image_outlined : Icons.picture_as_pdf_outlined,
              size: AppConstants.iconInput,
              color: color,
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  file.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '${isImage ? 'صورة' : 'PDF'} • ${formatBytes(file.sizeBytes)}',
                  style: const TextStyle(
                    fontSize: 11.5,
                    color: AppColors.textMuted,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => _removeFile(index),
            icon: const Icon(Icons.delete_outline, size: AppConstants.iconInput, color: AppColors.danger),
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }
}
