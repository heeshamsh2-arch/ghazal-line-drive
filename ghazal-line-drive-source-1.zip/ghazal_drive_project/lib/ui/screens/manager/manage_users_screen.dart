import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme.dart';
import '../../../models/app_user.dart';
import '../../../providers/auth_provider.dart';
import '../../../services/backends.dart';
import '../../widgets/common.dart';
import '../../../core/constants.dart';

/// شاشة إدارة الحسابات — للمدير فقط
/// إنشاء حسابات العمّال والمصممين، توليد أكواد دعوة، إيقاف/تفعيل الحسابات
class ManageUsersScreen extends StatefulWidget {
  const ManageUsersScreen({super.key});

  @override
  State<ManageUsersScreen> createState() => _ManageUsersScreenState();
}

class _ManageUsersScreenState extends State<ManageUsersScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();

  UserRole _role = UserRole.worker;
  bool _busy = false;
  String? _generatedCode;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _createAccount() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _busy = true);

    final result = await context.read<AuthBackend>().createUserAsManager(
          name: _nameCtrl.text,
          phone: _phoneCtrl.text,
          email: _emailCtrl.text,
          password: _passCtrl.text,
          role: _role,
        );

    if (!mounted) return;
    setState(() => _busy = false);

    if (result.success) {
      showSnack(context, 'تم إنشاء حساب ${_role.labelAr} بنجاح');
      _formKey.currentState!.reset();
      _nameCtrl.clear();
      _phoneCtrl.clear();
      _emailCtrl.clear();
      _passCtrl.clear();
      setState(() {});
    } else {
      showSnack(context, result.errorAr ?? 'تعذّر الإنشاء', isError: true);
    }
  }

  Future<void> _generateCode() async {
    setState(() => _busy = true);
    try {
      final code = await context.read<AuthBackend>().generateInviteCode(_role);
      if (!mounted) return;
      setState(() {
        _generatedCode = code;
        _busy = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      showSnack(context, 'تعذّر توليد الكود. $e', isError: true);
    }
  }

  Future<void> _toggleActive(AppUser user) async {
    await context.read<AuthBackend>().setUserActive(user.id, !user.isActive);
    if (!mounted) return;
    showSnack(
      context,
      user.isActive ? 'تم إيقاف حساب ${user.name}' : 'تم تفعيل حساب ${user.name}',
    );
  }

  @override
  Widget build(BuildContext context) {
    final service = context.read<AuthBackend>();
    final orders = context.read<OrderBackend>();

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('إدارة الحسابات'),
          bottom: const TabBar(
            labelColor: AppColors.primary,
            unselectedLabelColor: AppColors.textMuted,
            indicatorColor: AppColors.primary,
            labelStyle: TextStyle(fontWeight: FontWeight.w700),
            tabs: [
              Tab(text: 'العمّال والمصممون'),
              Tab(text: 'العملاء'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _staffTab(orders),
            _customersTab(orders),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  //  تبويب الموظفين
  // ══════════════════════════════════════════════════════
  Widget _staffTab(OrderBackend service) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
      children: [
        // ── إنشاء حساب ──
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.person_add_alt, size: AppConstants.iconLeading, color: AppColors.primary),
                      SizedBox(width: 8),
                      Text(
                        'إنشاء حساب موظف',
                        style: TextStyle(fontSize: AppConstants.iconInline, fontWeight: FontWeight.w800),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'أنشئ حساب العامل أو المصمم مباشرة، أو استخدم كود الدعوة',
                    style: TextStyle(fontSize: 12.5, color: AppColors.textMuted),
                  ),
                  const SizedBox(height: 16),

                  // اختيار الدور
                  Row(
                    children: [
                      Expanded(
                        child: _roleSelector(
                          role: UserRole.worker,
                          selected: _role == UserRole.worker,
                          onTap: () => setState(() => _role = UserRole.worker),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _roleSelector(
                          role: UserRole.designer,
                          selected: _role == UserRole.designer,
                          onTap: () => setState(() => _role = UserRole.designer),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  TextFormField(
                    controller: _nameCtrl,
                    decoration: const InputDecoration(
                      labelText: 'الاسم الكامل *',
                      prefixIcon: Icon(Icons.person_outline, size: AppConstants.iconInput),
                    ),
                    validator: (v) => (v?.trim().isEmpty ?? true) ? 'أدخل الاسم' : null,
                  ),
                  const SizedBox(height: 12),

                  TextFormField(
                    controller: _phoneCtrl,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: 'رقم الجوال *',
                      prefixIcon: Icon(Icons.phone_iphone, size: AppConstants.iconInput),
                    ),
                    validator: (v) => (v?.trim().isEmpty ?? true) ? 'أدخل الجوال' : null,
                  ),
                  const SizedBox(height: 12),

                  TextFormField(
                    controller: _emailCtrl,
                    keyboardType: TextInputType.emailAddress,
                    textDirection: TextDirection.ltr,
                    decoration: const InputDecoration(
                      labelText: 'البريد الإلكتروني *',
                      prefixIcon: Icon(Icons.alternate_email, size: AppConstants.iconInput),
                    ),
                    validator: (v) {
                      final value = v?.trim() ?? '';
                      if (value.isEmpty) return 'أدخل البريد';
                      if (!value.contains('@')) return 'بريد غير صحيح';
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),

                  TextFormField(
                    controller: _passCtrl,
                    obscureText: true,
                    textDirection: TextDirection.ltr,
                    decoration: const InputDecoration(
                      labelText: 'كلمة مرور مؤقتة *',
                      hintText: '6 أحرف على الأقل',
                      prefixIcon: Icon(Icons.lock_outline, size: AppConstants.iconInput),
                    ),
                    validator: (v) =>
                        (v == null || v.length < 6) ? '6 أحرف على الأقل' : null,
                  ),
                  const SizedBox(height: 16),

                  ElevatedButton.icon(
                    onPressed: _busy ? null : _createAccount,
                    icon: _busy
                        ? const SizedBox(
                            height: 18,
                            width: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.add, size: AppConstants.iconInput),
                    label: Text('إنشاء حساب ${_role.labelAr}'),
                  ),
                  const SizedBox(height: 10),

                  OutlinedButton.icon(
                    onPressed: _busy ? null : _generateCode,
                    icon: const Icon(Icons.key_outlined, size: 19),
                    label: const Text('توليد كود دعوة'),
                  ),

                  if (_generatedCode != null) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppColors.success.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppColors.success.withValues(alpha: 0.35),
                        ),
                      ),
                      child: Column(
                        children: [
                          const Text(
                            'كود الدعوة (لمرة واحدة)',
                            style: TextStyle(
                              fontSize: 12.5,
                              color: AppColors.success,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 8),
                          SelectableText(
                            _generatedCode!,
                            style: const TextStyle(
                              fontSize: AppConstants.iconAction,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 5,
                              color: AppColors.success,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'دور الكود: ${_role.labelAr} — أرسله للموظف ليستخدمه في التسجيل',
                            style: const TextStyle(
                              fontSize: 11.5,
                              color: AppColors.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 18),

        // ── قائمة الموظفين ──
        const Text(
          'الموظفون المسجّلون',
          style: TextStyle(fontSize: AppConstants.iconInline, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 10),

        StreamBuilder<List<AppUser>>(
          stream: service.watchStaff(),
          builder: (context, snap) {
            if (!snap.hasData) {
              return const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: CircularProgressIndicator()),
              );
            }
            final list = snap.data ?? <AppUser>[];
            if (list.isEmpty) {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Text(
                  'لا يوجد عمّال مسجّلون بعد',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.textMuted),
                ),
              );
            }
            return Column(
              children: list
                  .map((u) => _userTile(u, () => _toggleActive(u)))
                  .toList(),
            );
          },
        ),
        const SizedBox(height: 18),

        // ── المصممون ──
        const Text(
          'المصممون المسجّلون',
          style: TextStyle(fontSize: AppConstants.iconInline, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 10),

        StreamBuilder<List<AppUser>>(
          stream: service.watchStaff(role: UserRole.designer),
          builder: (context, snap) {
            if (!snap.hasData) {
              return const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: CircularProgressIndicator()),
              );
            }
            final list = snap.data ?? <AppUser>[];
            if (list.isEmpty) {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Text(
                  'لا يوجد مصممون مسجّلون بعد',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.textMuted),
                ),
              );
            }
            return Column(
              children: list
                  .map(
                    (u) => _userTile(
                      u,
                      () => _toggleActive(u),
                      avatarColor: const Color(0xFF7C3AED),
                    ),
                  )
                  .toList(),
            );
          },
        ),
      ],
    );
  }

  // ══════════════════════════════════════════════════════
  //  تبويب العملاء
  // ══════════════════════════════════════════════════════
  Widget _customersTab(OrderBackend service) {
    return StreamBuilder<List<AppUser>>(
      stream: service.watchCustomers(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final list = snap.data ?? <AppUser>[];

        if (list.isEmpty) {
          return const EmptyState(
            icon: Icons.people_outline,
            title: 'لا يوجد عملاء مسجّلون',
            message: 'يسجّل العميل بنفسه من شاشة التسجيل في التطبيق.',
          );
        }

        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
          itemCount: list.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (_, i) {
            final u = list[i];
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(13),
                child: Row(
                  children: [
                    UserAvatar(
                      initials: u.initials,
                      color: u.isActive ? AppColors.success : AppColors.textMuted,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            u.name,
                            style: const TextStyle(
                              fontSize: 14.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            u.phone.isEmpty ? u.email : u.phone,
                            style: const TextStyle(
                              fontSize: 12.5,
                              color: AppColors.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: u.isActive,
                      activeColor: AppColors.success,
                      onChanged: (_) => _toggleActive(u),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ══════════════════════════════════════════════════════
  //  عناصر مساعدة
  // ══════════════════════════════════════════════════════
  Widget _roleSelector({
    required UserRole role,
    required bool selected,
    required VoidCallback onTap,
  }) {
    final color = role == UserRole.worker ? AppColors.primary : const Color(0xFF7C3AED);
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(
          color: selected ? color.withValues(alpha: 0.1) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? color : AppColors.cardBorder,
            width: selected ? 1.6 : 1,
          ),
        ),
        child: Column(
          children: [
            Icon(
              role == UserRole.worker
                  ? Icons.engineering_outlined
                  : Icons.palette_outlined,
              size: AppConstants.iconAction,
              color: selected ? color : AppColors.textMuted,
            ),
            const SizedBox(height: 6),
            Text(
              role.labelAr,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: selected ? color : AppColors.textMuted,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _userTile(
    AppUser u,
    VoidCallback onToggle, {
    Color? avatarColor,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Row(
            children: [
              UserAvatar(
                initials: u.initials,
                color: u.isActive
                    ? (avatarColor ?? AppColors.primary)
                    : AppColors.textMuted,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            u.name,
                            style: const TextStyle(
                              fontSize: 14.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        ServiceRoleTag(role: u.role),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      u.phone.isEmpty ? u.email : u.phone,
                      style: const TextStyle(
                        fontSize: 12.5,
                        color: AppColors.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
              Switch(
                value: u.isActive,
                activeColor: AppColors.success,
                onChanged: (_) => onToggle(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// شارة الدور الصغيرة
class ServiceRoleTag extends StatelessWidget {
  const ServiceRoleTag({super.key, required this.role});

  final UserRole role;

  @override
  Widget build(BuildContext context) {
    final color = role == UserRole.designer
        ? const Color(0xFF7C3AED)
        : (role == UserRole.manager ? AppColors.accent : AppColors.primary);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        role.labelAr,
        style: TextStyle(
          fontSize: 10.5,
          fontWeight: FontWeight.w700,
          color: color,
        ),
      ),
    );
  }
}

