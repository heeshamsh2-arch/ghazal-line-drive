import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme.dart';
import '../../../providers/auth_provider.dart';
import '../../../services/backends.dart';
import '../../widgets/common.dart';
import '../../../core/constants.dart';

/// نافذة تغيير كلمة المرور
Future<void> showChangePasswordSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
    ),
    builder: (sheetCtx) => Directionality(
      textDirection: TextDirection.rtl,
      child: const _ChangePasswordBody(),
    ),
  );
}

class _ChangePasswordBody extends StatefulWidget {
  const _ChangePasswordBody();

  @override
  State<_ChangePasswordBody> createState() => _ChangePasswordBodyState();
}

class _ChangePasswordBodyState extends State<_ChangePasswordBody> {
  final _currentCtrl = TextEditingController();
  final _newCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();

  bool _obs1 = true;
  bool _obs2 = true;
  bool _busy = false;

  @override
  void dispose() {
    _currentCtrl.dispose();
    _newCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_newCtrl.text != _confirmCtrl.text) {
      showSnack(context, 'كلمتا المرور غير متطابقتين', isError: true);
      return;
    }
    if (_newCtrl.text.length < 6) {
      showSnack(context, 'كلمة المرور الجديدة 6 أحرف على الأقل', isError: true);
      return;
    }

    setState(() => _busy = true);
    final result = await context.read<AuthBackend>().changePassword(
          currentPassword: _currentCtrl.text,
          newPassword: _newCtrl.text,
        );
    if (!mounted) return;
    setState(() => _busy = false);

    if (result.success) {
      Navigator.of(context).pop();
      showSnack(context, 'تم تغيير كلمة المرور بنجاح');
    } else {
      showSnack(context, result.errorAr ?? 'تعذّر التغيير', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'تغيير كلمة المرور',
              style: TextStyle(fontSize: AppConstants.iconInline, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 18),

            TextField(
              controller: _currentCtrl,
              obscureText: _obs1,
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(
                labelText: 'كلمة المرور الحالية',
                prefixIcon: const Icon(Icons.lock_outline, size: AppConstants.iconInput),
                suffixIcon: IconButton(
                  icon: Icon(_obs1 ? Icons.visibility_outlined : Icons.visibility_off_outlined, size: 19),
                  onPressed: () => setState(() => _obs1 = !_obs1),
                ),
              ),
            ),
            const SizedBox(height: 12),

            TextField(
              controller: _newCtrl,
              obscureText: _obs2,
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(
                labelText: 'كلمة المرور الجديدة',
                prefixIcon: const Icon(Icons.lock_reset, size: AppConstants.iconInput),
                suffixIcon: IconButton(
                  icon: Icon(_obs2 ? Icons.visibility_outlined : Icons.visibility_off_outlined, size: 19),
                  onPressed: () => setState(() => _obs2 = !_obs2),
                ),
              ),
            ),
            const SizedBox(height: 12),

            TextField(
              controller: _confirmCtrl,
              obscureText: true,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(
                labelText: 'تأكيد كلمة المرور الجديدة',
                prefixIcon: Icon(Icons.check_circle_outline, size: AppConstants.iconInput),
              ),
            ),
            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: _busy ? null : _submit,
              child: _busy
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.4,
                        color: Colors.white,
                      ),
                    )
                  : const Text('حفظ كلمة المرور'),
            ),
          ],
        ),
      ),
    );
  }
}

