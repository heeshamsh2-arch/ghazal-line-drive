import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants.dart';
import '../../../core/date_format.dart';
import '../../../core/theme.dart';
import '../../../models/app_user.dart';
import '../../../models/order.dart';
import '../../../providers/auth_provider.dart';
import '../../../services/backends.dart';
import '../../widgets/common.dart';
import 'change_password_sheet.dart';

/// الملف الشخصي + معلومات الحساب + تسجيل الخروج
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.user;
    if (user == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
      children: [
        // ── بطاقة الهوية ──
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                UserAvatar(initials: user.initials, size: 58),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user.name,
                        style: const TextStyle(
                          fontSize: AppConstants.iconInline,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 9,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.primaryLight,
                              borderRadius: BorderRadius.circular(7),
                            ),
                            child: Text(
                              user.role.labelAr,
                              style: const TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w700,
                                color: AppColors.primary,
                              ),
                            ),
                          ),
                          if (!user.isActive) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 9,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.danger.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(7),
                              ),
                              child: const Text(
                                'موقوف',
                                style: TextStyle(
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.danger,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),

        // ── معلومات الحساب ──
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                InfoRow(label: 'البريد', value: user.email, icon: Icons.alternate_email),
                const Divider(height: 18),
                InfoRow(
                  label: 'الجوال',
                  value: user.phone.isEmpty ? '—' : user.phone,
                  icon: Icons.phone_iphone,
                ),
                const Divider(height: 18),
                InfoRow(
                  label: 'تاريخ الانضمام',
                  value: formatDateAr(user.createdAt),
                  icon: Icons.calendar_today_outlined,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),

        // ── إحصائياتي ──
        _MyStats(context, user: user),
        const SizedBox(height: 14),

        // ── الإجراءات ──
        Card(
          child: Column(
            children: [
              _tile(
                icon: Icons.lock_outline,
                title: 'تغيير كلمة المرور',
                onTap: () => showChangePasswordSheet(context),
              ),
              const Divider(height: 1, indent: 56),
              _tile(
                icon: Icons.info_outline,
                title: 'عن التطبيق',
                subtitle: '${AppConstants.appName} — ${AppConstants.appTagline}',
                onTap: () => _showAbout(context),
              ),
              const Divider(height: 1, indent: 56),
              _tile(
                icon: Icons.logout,
                title: 'تسجيل الخروج',
                color: AppColors.danger,
                onTap: () => _confirmLogout(context, auth),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _tile({
    required IconData icon,
    required String title,
    String? subtitle,
    Color? color,
    required VoidCallback onTap,
  }) {
    final c = color ?? AppColors.textMain;
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, size: AppConstants.iconLeading, color: color ?? AppColors.primary),
      title: Text(
        title,
        style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600, color: c),
      ),
      subtitle: subtitle == null
          ? null
          : Text(
              subtitle,
              style: const TextStyle(fontSize: 11.5, color: AppColors.textMuted),
            ),
      trailing: Icon(Icons.chevron_left, size: AppConstants.iconLeading, color: AppColors.textMuted),
    );
  }

  // ── إحصائيات المستخدم حسب دوره ──────────────────────────
  Widget _MyStats(BuildContext context, {required AppUser user}) {
    final service = context.read<OrderBackend>();
    return StreamBuilder<List<Order>>(
      stream: service.watchOrdersFor(user),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const SizedBox.shrink();
        }
        final orders = snap.data ?? <Order>[];
        final open = orders.where((o) => o.status.isOpen).length;
        final ready = orders
            .where((o) => o.status == OrderStatus.ready)
            .length;
        final delivered = orders
            .where((o) => o.status == OrderStatus.delivered)
            .length;

        return Row(
          children: [
            Expanded(
              child: StatCard(
                label: user.role.isStaff ? 'مهام مفتوحة' : 'طلباتي',
                value: '${user.role.isStaff ? open : orders.length}',
                color: AppColors.primary,
                icon: Icons.inbox_outlined,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: StatCard(
                label: 'قيد التنفيذ',
                value: '${orders.where((o) => o.status == OrderStatus.inProgress).length}',
                color: const Color(0xFFD97706),
                icon: Icons.autorenew,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: StatCard(
                label: 'جاهزة',
                value: '$ready',
                color: const Color(0xFF059669),
                icon: Icons.check_circle_outline,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: StatCard(
                label: 'مُسلّمة',
                value: '$delivered',
                color: const Color(0xFF15803D),
                icon: Icons.task_alt,
              ),
            ),
          ],
        );
      },
    );
  }

  void _showAbout(BuildContext context) {
    showAboutDialog(
      context: context,
      applicationName: AppConstants.appName,
      applicationVersion: '1.0.0',
      applicationLegalese: '${AppConstants.appTagline}\nمبني بـ Flutter + Firebase',
      children: const [
        SizedBox(height: 12),
        Text(
          'يدير التطبيق دورة الطلب كاملة: رفع العميل للطلب '
          '(صور وملفات PDF) ← مراجعة المدير ← الإسناد للعامل أو المصمم '
          '← التنفيذ ← الجاهزية ← التسليم.',
          style: TextStyle(fontSize: 13, height: 1.7),
        ),
      ],
    );
  }

  Future<void> _confirmLogout(BuildContext context, AuthProvider auth) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogCtx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('تسجيل الخروج'),
          content: const Text('هل تريد الخروج من التطبيق؟'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogCtx).pop(false),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(dialogCtx).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.danger,
                minimumSize: const Size(100, 42),
              ),
              child: const Text('خروج'),
            ),
          ],
        ),
      ),
    );
    if (ok == true) await auth.signOut();
  }
}
