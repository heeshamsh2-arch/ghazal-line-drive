import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/date_format.dart';
import '../../../core/theme.dart';
import '../../../models/app_user.dart';
import '../../../models/order.dart';
import '../../../providers/auth_provider.dart';
import '../../../services/backends.dart';
import '../../widgets/common.dart';
import '../../widgets/order_widgets.dart';
import '../../../core/constants.dart';

/// تفاصيل طلب واحد + كل الإجراءات حسب الدور
class OrderDetailScreen extends StatelessWidget {
  const OrderDetailScreen({super.key, required this.orderId});

  final String orderId;

  @override
  Widget build(BuildContext context) {
    final service = context.read<OrderBackend>();
    final user = context.watch<AuthProvider>().user;

    if (user == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('تفاصيل الطلب'),
        actions: [
          if (user.role.isManager)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              tooltip: 'حذف الطلب',
              onPressed: () => _confirmDelete(context, service),
            ),
        ],
      ),
      body: StreamBuilder<Order?>(
        stream: service.watchOrder(orderId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final order = snapshot.data;
          if (order == null) {
            return const EmptyState(
              icon: Icons.error_outline,
              title: 'الطلب غير موجود',
              message: 'ربما تم حذفه من قبل المدير.',
            );
          }

          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
            children: [
              _header(order),
              const SizedBox(height: 14),

              // تنبيه الطلب الناقص
              if (order.waitingCustomer) ...[
                const AlertBanner(
                  message:
                      'الطلب ناقص — بانتظار العميل بمعلومات إضافية. '
                      'يرجى رفع الملفات أو التواصل مع المكتب.',
                  color: AppColors.danger,
                  icon: Icons.help_outline,
                ),
                const SizedBox(height: 14),
              ],

              if (order.status == OrderStatus.ready) ...[
                const AlertBanner(
                  message: 'الطلب جاهز للاستلام من المكتب.',
                  color: AppColors.success,
                  icon: Icons.check_circle_outline,
                ),
                const SizedBox(height: 14),
              ],

              // بيانات الطلب
              _section(
                title: 'تفاصيل الطلب',
                icon: Icons.info_outline,
                children: [
                  InfoRow(label: 'نوع الخدمة', value: order.serviceType),
                  InfoRow(label: 'الكمية', value: '${order.quantity}'),
                  if (order.dueDate != null)
                    InfoRow(
                      label: 'موعد التسليم',
                      value: formatDateAr(order.dueDate!),
                      valueColor: order.isLate ? AppColors.danger : null,
                    ),
                  if (order.price != null)
                    InfoRow(
                      label: 'السعر',
                      value: formatMoney(order.price!),
                      valueColor: AppColors.success,
                    ),
                ],
              ),
              const SizedBox(height: 12),

              // وصف العميل
              _section(
                title: 'الوصف',
                icon: Icons.notes_outlined,
                children: [
                  Text(
                    order.description.isEmpty ? '—' : order.description,
                    style: const TextStyle(
                      fontSize: AppConstants.iconInline,
                      height: 1.7,
                      color: AppColors.textMain,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // بيانات العميل (للموظف/المدير)
              if (user.role.isStaff) ...[
                _section(
                  title: 'بيانات العميل',
                  icon: Icons.person_outline,
                  children: [
                    InfoRow(label: 'الاسم', value: order.customerName),
                    if (order.customerPhone.isNotEmpty)
                      InfoRow(label: 'الجوال', value: order.customerPhone),
                  ],
                ),
                const SizedBox(height: 12),
              ],

              // ملاحظة المدير
              if (order.managerNote.isNotEmpty) ...[
                _section(
                  title: 'ملاحظة المكتب',
                  icon: Icons.sticky_note_2_outlined,
                  children: [
                    Text(
                      order.managerNote,
                      style: const TextStyle(fontSize: AppConstants.iconInline, height: 1.7),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
              ],

              // الموظف المسؤول
              if (order.isAssigned) ...[
                _section(
                  title: 'الموظف المسؤول',
                  icon: Icons.engineering_outlined,
                  children: [
                    Row(
                      children: [
                        UserAvatar(initials: order.assigneeName ?? '؟'),
                        const SizedBox(width: 11),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                order.assigneeName ?? '—',
                                style: const TextStyle(
                                  fontSize: 14.5,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                order.assigneeRole == 'designer'
                                    ? 'مصمم'
                                    : (order.assigneeRole == 'worker'
                                        ? 'عامل'
                                        : 'مدير'),
                                style: const TextStyle(
                                  fontSize: 12.5,
                                  color: AppColors.textMuted,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 12),
              ],

              // المرفقات
              _attachments(context, order),
              const SizedBox(height: 12),

              // السجل الزمني
              _timeline(order),
            ],
          );
        },
      ),
      // أزرار الإجراءات في الأسفل
      bottomNavigationBar: StreamBuilder<Order?>(
        stream: service.watchOrder(orderId),
        builder: (context, snap) {
          final order = snap.data;
          if (order == null) return const SizedBox.shrink();
          return _actionBar(context, order, user, service);
        },
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  //  العناصر
  // ══════════════════════════════════════════════════════

  Widget _header(Order order) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  order.title,
                  style: const TextStyle(
                    fontSize: AppConstants.iconLeading,
                    fontWeight: FontWeight.w800,
                    height: 1.4,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              StatusChip(status: order.status),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            order.status.hintAr,
            style: TextStyle(
              fontSize: AppConstants.iconInline,
              color: Color(order.status.colorValue),
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          const Divider(height: 1),
          const SizedBox(height: 10),
          Row(
            children: [
              const Icon(Icons.access_time, size: AppConstants.iconInline, color: AppColors.textMuted),
              const SizedBox(width: 6),
              Text(
                'أُنشئ ${timeAgoAr(order.createdAt)}',
                style: const TextStyle(fontSize: AppConstants.iconInline, color: AppColors.textMuted),
              ),
              const Spacer(),
              Text(
                '#${order.id.length >= 6 ? order.id.substring(0, 6).toUpperCase() : order.id.toUpperCase()}',
                style: const TextStyle(
                  fontSize: AppConstants.iconInline,
                  color: AppColors.textMuted,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }



  Widget _section({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: AppConstants.iconLeading, color: AppColors.primary),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontSize: AppConstants.iconInline,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          const Divider(height: 1),
          ...children,
        ],
      ),
    );
  }

  Widget _attachments(BuildContext context, Order order) {
    if (order.attachments.isEmpty) {
      return _section(
        title: 'المرفقات',
        icon: Icons.attach_file,
        children: const [
          Text(
            'لا توجد مرفقات',
            style: TextStyle(fontSize: 13.5, color: AppColors.textMuted),
          ),
        ],
      );
    }

    final images = order.attachments.where((a) => a.isImage).toList();
    final pdfs = order.attachments.where((a) => a.isPdf).toList();
    final others =
        order.attachments.where((a) => !a.isImage && !a.isPdf).toList();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.attach_file, size: AppConstants.iconLeading, color: AppColors.primary),
              const SizedBox(width: 8),
              Text(
                'المرفقات (${order.attachments.length})',
                style: const TextStyle(fontSize: AppConstants.iconInline, fontWeight: FontWeight.w700),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // شبكة الصور
          if (images.isNotEmpty) ...[
            SizedBox(
              height: 92,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: images.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (_, i) => GestureDetector(
                  onTap: () => _openImage(context, images[i]),
                  child: Container(
                    width: 92,
                    height: 92,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.cardBorder),
                      image: DecorationImage(
                        image: NetworkImage(images[i].url),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],

          // ملفات PDF
          ...pdfs.map((a) => _fileRow(context, a, AppColors.danger)),
          ...others.map((a) => _fileRow(context, a, AppColors.textMuted)),
        ],
      ),
    );
  }

  Widget _fileRow(BuildContext context, Attachment a, Color color) {
    return InkWell(
      onTap: () => _openUrl(context, a.url, a.fileName),
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(9),
              ),
              child: Icon(Icons.picture_as_pdf_outlined, size: AppConstants.iconLeading, color: color),
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    a.fileName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${a.kindLabel} • ${formatBytes(a.sizeBytes)} • ${a.uploadedByName}',
                    style: const TextStyle(
                      fontSize: 11.5,
                      color: AppColors.textMuted,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.open_in_new, size: AppConstants.iconInline, color: AppColors.textMuted),
          ],
        ),
      ),
    );
  }

  Widget _timeline(Order order) {
    final events = order.history.reversed.toList();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.history, size: AppConstants.iconLeading, color: AppColors.primary),
              const SizedBox(width: 8),
              const Text(
                'سجل الطلب',
                style: TextStyle(fontSize: AppConstants.iconInline, fontWeight: FontWeight.w700),
              ),
            ],
          ),
          const SizedBox(height: 14),

          ...events.asMap().entries.map(
            (entry) => _timelineItem(entry.value, entry.key == 0),
          ),
        ],
      ),
    );
  }

  Widget _timelineItem(StatusEvent e, bool isLast) {
    final color = Color(e.status.colorValue);

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // الخط الزمني
          Column(
            children: [
              Container(
                width: 26,
                height: 26,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: color, width: 1.5),
                ),
                child: Icon(
                  StatusChip.iconFor(e.status),
                  size: AppConstants.iconInline,
                  color: color,
                ),
              ),
              if (!isLast)
                Expanded(
                  child: Container(width: 1.5, color: AppColors.cardBorder),
                ),
            ],
          ),
          const SizedBox(width: 12),

          // المحتوى
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(bottom: isLast ? 0 : 18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          e.status.labelAr,
                          style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w700,
                            color: color,
                          ),
                        ),
                      ),
                      Text(
                        formatDateTimeAr(e.at),
                        style: const TextStyle(
                          fontSize: 10.5,
                          color: AppColors.textMuted,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  if (e.note.isNotEmpty)
                    Text(
                      e.note,
                      style: const TextStyle(
                        fontSize: AppConstants.iconInline,
                        color: AppColors.textMain,
                        height: 1.5,
                      ),
                    ),
                  const SizedBox(height: 3),
                  Text(
                    'بواسطة: ${e.actorName} (${e.actorRole.labelAr})',
                    style: const TextStyle(
                      fontSize: 11.5,
                      color: AppColors.textMuted,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  //  شريط الإجراءات حسب الدور
  // ══════════════════════════════════════════════════════

  Widget _actionBar(
    BuildContext context,
    Order order,
    AppUser user,
    OrderBackend service,
  ) {
    final buttons = <Widget>[];

    // ── المدير ──
    if (user.role.isManager) {
      if (!order.isAssigned || order.status.isOpen) {
        buttons.add(_primaryBtn(
          context,
          label: order.isAssigned ? 'تغيير الموظف' : 'إسناد لموظف',
          icon: Icons.assignment_ind_outlined,
          onTap: () => _openAssignSheet(context, order, service, user),
        ));
      }
      if (order.isAssigned) {
        buttons.add(_secondaryBtn(
          context,
          label: 'تغيير الحالة',
          icon: Icons.swap_horiz,
          onTap: () => _openStatusSheet(context, order, service, user),
        ));
      }
      if (!order.status.isOpen) {
        buttons.add(_secondaryBtn(
          context,
          label: 'السعر والموعد',
          icon: Icons.sell_outlined,
          onTap: () => _openPricingSheet(context, order, service),
        ));
      }
    }

    // ── العامل/المصمم ──
    if (user.role.isStaff && order.assigneeId == user.id) {
      if (order.status == OrderStatus.assigned) {
        buttons.add(_primaryBtn(
          context,
          label: 'بدء التنفيذ',
          icon: Icons.play_arrow_rounded,
          onTap: () => _changeStatus(
            context,
            order,
            service,
            user,
            OrderStatus.inProgress,
          ),
        ));
      } else if (order.status == OrderStatus.inProgress) {
        buttons.add(_primaryBtn(
          context,
          label: 'الطلب جاهز',
          icon: Icons.check_circle_outline,
          color: AppColors.success,
          onTap: () => _changeStatus(
            context,
            order,
            service,
            user,
            OrderStatus.ready,
          ),
        ));
      }
      if (order.status.isOpen && order.status != OrderStatus.missingInfo) {
        buttons.add(_secondaryBtn(
          context,
          label: 'طلب ناقص',
          icon: Icons.help_outline,
          color: AppColors.danger,
          onTap: () => _askMissingInfo(context, order, service, user),
        ));
      }
      buttons.add(_secondaryBtn(
        context,
        label: 'إضافة صور',
        icon: Icons.add_photo_alternate_outlined,
        onTap: () => _addFiles(context, service, order, user),
      ));
    }

    // ── العميل ──
    if (user.role == UserRole.customer) {
      if (order.status == OrderStatus.missingInfo) {
        buttons.add(_primaryBtn(
          context,
          label: 'إرسال المعلومات الناقصة',
          icon: Icons.cloud_upload_outlined,
          color: AppColors.success,
          onTap: () => _addFiles(context, service, order, user),
        ));
      } else if (order.status == OrderStatus.ready) {
        buttons.add(_primaryBtn(
          context,
          label: 'تأكيد الاستلام',
          icon: Icons.task_alt,
          color: AppColors.success,
          onTap: () => _changeStatus(
            context,
            order,
            service,
            user,
            OrderStatus.delivered,
          ),
        ));
      }
      if (order.status.isOpen && order.status != OrderStatus.ready) {
        buttons.add(_secondaryBtn(
          context,
          label: 'إضافة ملف',
          icon: Icons.attach_file,
          onTap: () => _addFiles(context, service, order, user),
        ));
      }
    }

    if (buttons.isEmpty) return const SizedBox.shrink();

    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        decoration: const BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 12,
              offset: Offset(0, -3),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // الزر الأساسي بعرض كامل
            buttons.first,
            // بقية الأزرار في صفّين بعرضين
            if (buttons.length > 1) ...[
              const SizedBox(height: 9),
              for (var i = 0; i < buttons.length - 1; i += 2)
                Padding(
                  padding: const EdgeInsets.only(top: 9),
                  child: Row(
                    children: [
                      Expanded(child: buttons[i + 1]),
                      if (i + 2 < buttons.length) ...[
                        const SizedBox(width: 9),
                        Expanded(child: buttons[i + 2]),
                      ],
                    ],
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _primaryBtn(
    BuildContext context, {
    required String label,
    required IconData icon,
    required VoidCallback onTap,
    Color? color,
  }) {
    final c = color ?? AppColors.primary;
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(backgroundColor: c),
        icon: Icon(icon, size: 19),
        label: Text(label),
      ),
    );
  }

  Widget _secondaryBtn(
    BuildContext context, {
    required String label,
    required IconData icon,
    required VoidCallback onTap,
    Color? color,
  }) {
    final c = color ?? AppColors.primary;
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          foregroundColor: c,
          side: BorderSide(color: c, width: 1.4),
        ),
        icon: Icon(icon, size: 18),
        label: Text(label, style: const TextStyle(fontSize: 13.5)),
      ),
    );
  }

  // ══════════════════════════════════════════════════════
  //  الإجراءات
  // ══════════════════════════════════════════════════════

  /// إسناد الطلب لموظف
  Future<void> _openAssignSheet(
    BuildContext context,
    Order order,
    OrderBackend service,
    AppUser manager,
  ) async {
    final workerCtrl = TextEditingController();

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (sheetCtx) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(sheetCtx).viewInsets.bottom,
            ),
            child: DefaultTabController(
              length: 2,
              child: SizedBox(
                height: 480,
                child: Column(
                  children: [
                    const SizedBox(height: 10),
                    Container(
                      width: 42,
                      height: 4,
                      decoration: BoxDecoration(
                        color: AppColors.cardBorder,
                        borderRadius: BorderRadius.circular(3),
                      ),
                    ),
                    const SizedBox(height: 14),
                    const Text(
                      'إسناد الطلب',
                      style: TextStyle(fontSize: AppConstants.iconInline, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'اختر العامل أو المصمم المسؤول عن هذا الطلب',
                      style: TextStyle(fontSize: 12.5, color: AppColors.textMuted),
                    ),
                    const SizedBox(height: 12),

                    TextField(
                      controller: workerCtrl,
                      decoration: const InputDecoration(
                        hintText: 'سبب الإسناد (اختياري)',
                        prefixIcon: Icon(Icons.note_add_outlined, size: 19),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 10),

                    // تبويب: عاملين / مصممين
                    const TabBar(
                      labelColor: AppColors.primary,
                      unselectedLabelColor: AppColors.textMuted,
                      indicatorColor: AppColors.primary,
                      labelStyle: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: AppConstants.iconInline,
                      ),
                      tabs: [
                        Tab(text: 'العاملون'),
                        Tab(text: 'المصممون'),
                      ],
                    ),
                    Expanded(
                      child: TabBarView(
                        children: [
                          _staffList(
                            context: sheetCtx,
                            role: UserRole.worker,
                            service: service,
                            order: order,
                            manager: manager,
                            noteCtrl: workerCtrl,
                          ),
                          _staffList(
                            context: sheetCtx,
                            role: UserRole.designer,
                            service: service,
                            order: order,
                            manager: manager,
                            noteCtrl: workerCtrl,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
    workerCtrl.dispose();
  }

  Widget _staffList({
    required BuildContext context,
    required UserRole role,
    required OrderBackend service,
    required Order order,
    required AppUser manager,
    required TextEditingController noteCtrl,
  }) {
    return StreamBuilder<List<AppUser>>(
      stream: service.watchStaff(role: role),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final staff = snap.data ?? <AppUser>[];

        if (staff.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.person_off_outlined, size: AppConstants.iconEmpty, color: AppColors.textMuted),
                  const SizedBox(height: 12),
                  Text(
                    role == UserRole.worker
                        ? 'لا يوجد عمّال مسجّلون'
                        : 'لا يوجد مصممون مسجّلون',
                    style: const TextStyle(
                      fontSize: AppConstants.iconInline,
                      color: AppColors.textMuted,
                    ),
                  ),
                ],
              ),
            ),
          );
        }

        return ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: staff.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (_, i) {
            final s = staff[i];
            final isCurrent = s.id == order.assigneeId;
            final inactive = !s.isActive;

            return Material(
              color: inactive ? AppColors.bg : Colors.white,
              borderRadius: BorderRadius.circular(12),
              child: InkWell(
                onTap: inactive
                    ? null
                    : () async {
                        final result = await service.assignOrder(
                          orderId: order.id,
                          assignee: s,
                          manager: manager,
                          note: noteCtrl.text,
                        );
                        if (!context.mounted) return;
                        Navigator.of(context).pop();
                        showSnack(
                          context,
                          result.success
                              ? 'تم إسناد الطلب إلى ${s.name}'
                              : (result.errorAr ?? 'تعذّر الإسناد'),
                          isError: !result.success,
                        );
                      },
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isCurrent ? AppColors.primary : AppColors.cardBorder,
                      width: isCurrent ? 1.6 : 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      UserAvatar(
                        initials: s.initials,
                        color: role == UserRole.designer
                            ? const Color(0xFF7C3AED)
                            : AppColors.primary,
                      ),
                      const SizedBox(width: 11),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              s.name,
                              style: const TextStyle(
                                fontSize: 14.5,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              inactive ? 'الحساب موقوف' : s.phone,
                              style: TextStyle(
                                fontSize: AppConstants.iconInline,
                                color: inactive
                                    ? AppColors.danger
                                    : AppColors.textMuted,
                                fontWeight:
                                    inactive ? FontWeight.w700 : FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (isCurrent)
                        const Icon(Icons.check_circle, color: AppColors.primary, size: AppConstants.iconLeading),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  /// تغيير الحالة (للأعضاء)
  Future<void> _openStatusSheet(
    BuildContext context,
    Order order,
    OrderBackend service,
    AppUser actor,
  ) async {
    final noteCtrl = TextEditingController();

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (sheetCtx) => Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(sheetCtx).viewInsets.bottom,
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 26),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'تغيير حالة الطلب',
                  style: TextStyle(fontSize: AppConstants.iconInline, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  'الحالة الحالية: ${order.status.labelAr}',
                  style: const TextStyle(fontSize: AppConstants.iconInline, color: AppColors.textMuted),
                ),
                const SizedBox(height: 16),

                TextField(
                  controller: noteCtrl,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    hintText: 'ملاحظة (تظهر للعميل في سجل الطلب)',
                  ),
                ),
                const SizedBox(height: 14),

                ...OrderStatusX.managerNext.map(
                  (s) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: InkWell(
                      onTap: () async {
                        Navigator.of(sheetCtx).pop();
                        await _changeStatus(
                          context,
                          order,
                          service,
                          actor,
                          s,
                          note: noteCtrl.text,
                        );
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.all(13),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.cardBorder),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              StatusChip.iconFor(s),
                              size: AppConstants.iconLeading,
                              color: Color(s.colorValue),
                            ),
                            const SizedBox(width: 11),
                            Text(
                              s.labelAr,
                              style: TextStyle(
                                fontSize: AppConstants.iconInline,
                                fontWeight: FontWeight.w600,
                                color: Color(s.colorValue),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    noteCtrl.dispose();
  }

  /// طلب معلومة ناقصة من العميل
  Future<void> _askMissingInfo(
    BuildContext context,
    Order order,
    OrderBackend service,
    AppUser actor,
  ) async {
    final ctrl = TextEditingController();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogCtx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('طلب معلومة ناقصة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'اكتب ما ينقص من العميل. سيظهر التنبيه له في التطبيق فوراً.',
                style: TextStyle(
                  fontSize: 13.5,
                  color: AppColors.textMuted,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: ctrl,
                maxLines: 3,
                autofocus: true,
                decoration: const InputDecoration(
                  hintText: 'مثال: نرجو إرسال التصميم بصيغة vecter…',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogCtx).pop(false),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(dialogCtx).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.danger,
                minimumSize: const Size(100, 42),
              ),
              child: const Text('إرسال'),
            ),
          ],
        ),
      ),
    );

    if (confirmed == true) {
      await _changeStatus(
        context,
        order,
        service,
        actor,
        OrderStatus.missingInfo,
        note: ctrl.text,
      );
    }
    ctrl.dispose();
  }

  /// إضافة ملفات للطلب
  Future<void> _addFiles(
    BuildContext context,
    OrderBackend service,
    Order order,
    AppUser uploader,
  ) async {
    try {
      final picked = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'gif'],
      );
      if (picked.isEmpty) return;

      final files = <SelectedFile>[];
      for (final f in picked) {
        if (f.path == null) continue;
        files.add(SelectedFile(
          name: f.name,
          path: f.path,
          sizeBytes: await f.length() ?? 0,
          mimeType: guessMimeType(f.name),
        ));
      }

      if (files.isEmpty) return;

      if (!context.mounted) return;
      _showProgress(context, 'جارٍ الرفع...');

      final res = await service.addAttachments(
        orderId: order.id,
        files: files,
        uploader: uploader,
      );

      if (!context.mounted) return;
      Navigator.of(context).pop();
      showSnack(
        context,
        res.success ? 'تمت إضافة الملفات' : (res.errorAr ?? 'تعذّر الرفع'),
        isError: !res.success,
      );
    } catch (e) {
      if (context.mounted) showSnack(context, 'خطأ: $e', isError: true);
    }
  }

  /// السعر والموعد
  Future<void> _openPricingSheet(
    BuildContext context,
    Order order,
    OrderBackend service,
  ) async {
    final priceCtrl = TextEditingController(
      text: order.price != null ? order.price!.toStringAsFixed(0) : '',
    );
    final noteCtrl = TextEditingController(text: order.managerNote);
    DateTime? dueDate = order.dueDate;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (sheetCtx) => Directionality(
        textDirection: TextDirection.rtl,
        child: StatefulBuilder(
          builder: (sheetCtx, setSheetState) => Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(sheetCtx).viewInsets.bottom,
            ),
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 26),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'السعر وموعد التسليم',
                    style: TextStyle(fontSize: AppConstants.iconInline, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 16),

                  TextField(
                    controller: priceCtrl,
                    keyboardType: TextInputType.number,
                    textDirection: TextDirection.ltr,
                    decoration: const InputDecoration(
                      labelText: 'السعر (ريال)',
                      prefixIcon: Icon(Icons.sell_outlined, size: 19),
                    ),
                  ),
                  const SizedBox(height: 12),

                  TextField(
                    controller: noteCtrl,
                    maxLines: 2,
                    decoration: const InputDecoration(
                      labelText: 'ملاحظة تظهر للعميل',
                      prefixIcon: Icon(Icons.sticky_note_2_outlined, size: 19),
                    ),
                  ),
                  const SizedBox(height: 12),

                  OutlinedButton.icon(
                    onPressed: () async {
                      final picked = await showDatePicker(
                        context: sheetCtx,
                        initialDate: dueDate ?? DateTime.now(),
                        firstDate: DateTime.now().subtract(const Duration(days: 30)),
                        lastDate: DateTime.now().add(const Duration(days: 730)),
                      );
                      if (picked != null) setSheetState(() => dueDate = picked);
                    },
                    icon: const Icon(Icons.event_outlined, size: 19),
                    label: Text(
                      dueDate == null
                          ? 'تحديد موعد التسليم'
                          : 'الموعد: ${formatDateAr(dueDate!)}',
                    ),
                  ),
                  if (dueDate != null) ...[
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: () => setSheetState(() => dueDate = null),
                      child: const Text('إزالة الموعد'),
                    ),
                  ],
                  const SizedBox(height: 16),

                  ElevatedButton(
                    onPressed: () async {
                      Navigator.of(sheetCtx).pop();
                      final res = await service.updateManagerFields(
                        orderId: order.id,
                        price: double.tryParse(priceCtrl.text.trim()),
                        managerNote: noteCtrl.text.trim(),
                        dueDate: dueDate,
                        clearDueDate: dueDate == null,
                      );
                      if (!context.mounted) return;
                      showSnack(
                        context,
                        res.success ? 'تم الحفظ' : (res.errorAr ?? 'تعذّر الحفظ'),
                        isError: !res.success,
                      );
                    },
                    child: const Text('حفظ'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    priceCtrl.dispose();
    noteCtrl.dispose();
  }

  /// تنفيذ تغيير الحالة مع رسالة
  Future<void> _changeStatus(
    BuildContext context,
    Order order,
    OrderBackend service,
    AppUser actor,
    OrderStatus newStatus, {
    String? note,
  }) async {
    final res = await service.changeStatus(
      orderId: order.id,
      newStatus: newStatus,
      actor: actor,
      note: note,
    );
    if (!context.mounted) return;
    showSnack(
      context,
      res.success
          ? 'الحالة الآن: ${newStatus.labelAr}'
          : (res.errorAr ?? 'تعذّر تغيير الحالة'),
      isError: !res.success,
    );
  }

  Future<void> _confirmDelete(
    BuildContext context,
    OrderBackend service,
  ) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogCtx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('حذف الطلب نهائياً؟'),
          content: const Text(
            'سيتم حذف الطلب وكل مرفقاته من قاعدة البيانات. لا يمكن التراجع.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogCtx).pop(false),
              child: const Text('تراجع'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(dialogCtx).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.danger,
                minimumSize: const Size(100, 42),
              ),
              child: const Text('حذف'),
            ),
          ],
        ),
      ),
    );

    if (ok == true) {
      final res = await service.deleteOrder(orderId);
      if (!context.mounted) return;
      if (res.success) {
        showSnack(context, 'تم حذف الطلب');
        Navigator.of(context).pop();
      } else {
        showSnack(context, res.errorAr ?? 'تعذّر الحذف', isError: true);
      }
    }
  }

  // ══════════════════════════════════════════════════════
  //  أدوات
  // ══════════════════════════════════════════════════════

  void _showProgress(BuildContext context, String msg) {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: Center(
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const CircularProgressIndicator(),
                const SizedBox(height: 16),
                Text(msg, style: const TextStyle(fontSize: 14)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _openImage(BuildContext context, Attachment a) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
            title: Text(a.fileName, style: const TextStyle(fontSize: 14)),
          ),
          body: Center(
            child: InteractiveViewer(
              maxScale: 5,
              child: Image.network(
                a.url,
                loadingBuilder: (_, child, progress) => progress == null
                    ? child
                    : const Center(child: CircularProgressIndicator()),
                errorBuilder: (_, __, ___) => const Center(
                  child: Text(
                    'تعذّر تحميل الصورة',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _openUrl(BuildContext context, String url, String name) async {
    final uri = Uri.parse(url);
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) {
      showSnack(context, 'تعذّر فتح الملف «$name»', isError: true);
    }
  }
}

