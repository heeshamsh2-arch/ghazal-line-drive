import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants.dart';
import '../../../core/theme.dart';
import '../../../models/app_user.dart';
import '../../../models/order.dart';
import '../../../providers/auth_provider.dart';
import '../../../services/backends.dart';
import '../../widgets/common.dart';
import '../../widgets/order_widgets.dart';
import 'order_detail_screen.dart';

/// قائمة الطلبات — تتكيّف مع دور المستخدم:
/// • العميل: طلباته فقط
/// • العامل/المصمم: الطلبات المسندة إليه
/// • المدير: كل الطلبات مع إحصائيات
class OrdersListScreen extends StatefulWidget {
  const OrdersListScreen({super.key, this.showCustomer = false});

  final bool showCustomer;

  @override
  State<OrdersListScreen> createState() => _OrdersListScreenState();
}

class _OrdersListScreenState extends State<OrdersListScreen> {
  final _searchCtrl = TextEditingController();

  OrderStatus? _statusFilter;
  String? _assigneeFilter;
  String _search = '';
  bool _searching = false;

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  String get _title {
    final role = context.read<AuthProvider>().role;
    if (role.isManager) return 'كل الطلبات';
    if (role.isStaff) return 'مهامي';
    return 'طلباتي';
  }

  Future<void> _openOrder(Order order) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: order.id)),
    );
  }

  /// منطق التصفية حسب الدور
  List<Order> _applyFilters(List<Order> all, AppUser user) {
    var list = all;

    // 1) فلترة الحالة
    if (_statusFilter != null) {
      list = list.where((o) => o.status == _statusFilter).toList();
    }

    // 2) فلترة الموظف (للمدير)
    if (user.role.isManager && _assigneeFilter != null) {
      if (_assigneeFilter == 'unassigned') {
        list = list.where((o) => !o.isAssigned).toList();
      } else {
        list = list.where((o) => o.assigneeId == _assigneeFilter).toList();
      }
    }

    // 3) البحث النصي
    if (_search.trim().isNotEmpty) {
      final q = _search.trim().toLowerCase();
      list = list.where((o) {
        return o.title.toLowerCase().contains(q) ||
            o.description.toLowerCase().contains(q) ||
            o.customerName.toLowerCase().contains(q) ||
            (o.assigneeName ?? '').toLowerCase().contains(q) ||
            o.serviceType.toLowerCase().contains(q);
      }).toList();
    }

    return list;
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final service = context.read<OrderBackend>();
    final user = auth.user;

    if (user == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return StreamBuilder<List<Order>>(
      stream: service.watchOrdersFor(user),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return EmptyState(
            icon: Icons.cloud_off,
            title: 'تعذّر تحميل الطلبات',
            message: '${snapshot.error}\nتأكّد من اتصال الإنترنت وقواعد Firebase.',
            action: ElevatedButton(
              onPressed: () => setState(() {}),
              child: const Text('إعادة المحاولة'),
            ),
          );
        }

        if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final allOrders = snapshot.data ?? <Order>[];
        final counts = countByStatus(allOrders);
        final filtered = _applyFilters(allOrders, user);
        final isManager = user.role.isManager;

        return Column(
          children: [
            // ── الإحصائيات (للمدير) ──
            if (isManager) _statsRow(counts, allOrders),

            // ── البحث ──
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
              child: TextField(
                controller: _searchCtrl,
                onChanged: (v) => setState(() => _search = v),
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  hintText: 'ابحث بالعنوان أو العميل أو الموظف...',
                  prefixIcon: const Icon(Icons.search, size: AppConstants.iconLeading),
                  isDense: true,
                  suffixIcon: _searching
                      ? IconButton(
                          icon: const Icon(Icons.close, size: 18),
                          onPressed: () {
                            _searchCtrl.clear();
                            setState(() {
                              _search = '';
                              _searching = false;
                            });
                          },
                        )
                      : null,
                ),
                onTap: () => setState(() => _searching = true),
              ),
            ),

            // ── فلترة الحالة ──
            FilterBar(
              children: [
                FilterPill(
                  label: 'الكل',
                  selected: _statusFilter == null,
                  onTap: () => setState(() => _statusFilter = null),
                ),
                ...OrderStatus.values.map(
                  (s) => FilterPill(
                    label: s.labelAr,
                    color: Color(s.colorValue),
                    count: counts[s] ?? 0,
                    selected: _statusFilter == s,
                    onTap: () => setState(
                      () => _statusFilter = _statusFilter == s ? null : s,
                    ),
                  ),
                ),
              ],
            ),

            // ── فرز حسب الموظف (للمدير) ──
            if (isManager) _assigneeFilterRow(service, allOrders, user),

            // ── عدد النتائج ──
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 8),
              child: Row(
                children: [
                  Text(
                    'النتائج: ${filtered.length} من ${allOrders.length}',
                    style: const TextStyle(
                      fontSize: 12.5,
                      color: AppColors.textMuted,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Spacer(),
                  if (filtered.isNotEmpty)
                    Text(
                      'مرتّبة حسب آخر تحديث',
                      style: const TextStyle(
                        fontSize: 11.5,
                        color: AppColors.textMuted,
                      ),
                    ),
                ],
              ),
            ),

            // ── القائمة ──
            Expanded(
              child: filtered.isEmpty
                  ? EmptyState(
                      icon: Icons.inbox_outlined,
                      title: allOrders.isEmpty ? 'لا توجد طلبات' : 'لا نتائج مطابقة',
                      message: allOrders.isEmpty
                          ? (_title == 'كل الطلبات'
                              ? 'سيظهر هنا كل طلبات العملاء فور رفعها.'
                              : (_title == 'مهامي'
                                  ? 'سيظهر هنا الطلبات المسندة إليك من المدير.'
                                  : 'ابدأ برفع طلب جديد وسجّل حالته هنا.'))
                          : 'جرّب تغيير الفلتر أو مسح كلمة البحث.',
                    )
                  : RefreshIndicator(
                      onRefresh: () async {
                        await Future<void>.delayed(const Duration(milliseconds: 500));
                        if (mounted) setState(() {});
                      },
                      child: ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        itemCount: filtered.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (_, i) => OrderCard(
                          order: filtered[i],
                          showCustomer: widget.showCustomer,
                          onTap: () => _openOrder(filtered[i]),
                        ),
                      ),
                    ),
            ),
          ],
        );
      },
    );
  }

  // ── صف الإحصائيات للمدير ─────────────────────────────────
  Widget _statsRow(Map<OrderStatus, int> counts, List<Order> all) {
    return SizedBox(
      height: 96,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
        children: [
          StatCard(
            label: 'إجمالي الطلبات',
            value: '${all.length}',
            color: AppColors.primary,
            icon: Icons.receipt_long,
          ),
          const SizedBox(width: 10),
          StatCard(
            label: 'طلبات جديدة',
            value: '${counts[OrderStatus.newRequest] ?? 0}',
            color: Color(OrderStatus.newRequest.colorValue),
            icon: StatusChip.iconFor(OrderStatus.newRequest),
            onTap: () => setState(() => _statusFilter = OrderStatus.newRequest),
          ),
          const SizedBox(width: 10),
          StatCard(
            label: 'قيد التنفيذ',
            value: '${(counts[OrderStatus.assigned] ?? 0) + (counts[OrderStatus.inProgress] ?? 0)}',
            color: const Color(0xFFD97706),
            icon: StatusChip.iconFor(OrderStatus.inProgress),
            onTap: () => setState(() => _statusFilter = OrderStatus.inProgress),
          ),
          const SizedBox(width: 10),
          StatCard(
            label: 'طلبات ناقصة',
            value: '${counts[OrderStatus.missingInfo] ?? 0}',
            color: AppColors.danger,
            icon: StatusChip.iconFor(OrderStatus.missingInfo),
            onTap: () => setState(() => _statusFilter = OrderStatus.missingInfo),
          ),
          const SizedBox(width: 10),
          StatCard(
            label: 'جاهزة للتسليم',
            value: '${counts[OrderStatus.ready] ?? 0}',
            color: const Color(0xFF059669),
            icon: StatusChip.iconFor(OrderStatus.ready),
            onTap: () => setState(() => _statusFilter = OrderStatus.ready),
          ),
          const SizedBox(width: 10),
          StatCard(
            label: 'تم التسليم',
            value: '${counts[OrderStatus.delivered] ?? 0}',
            color: const Color(0xFF15803D),
            icon: StatusChip.iconFor(OrderStatus.delivered),
            onTap: () => setState(() => _statusFilter = OrderStatus.delivered),
          ),
        ],
      ),
    );
  }

  // ── فرز حسب الموظف المسند (للمدير) ──────────────────────
  Widget _assigneeFilterRow(
    OrderBackend service,
    List<Order> allOrders,
    AppUser currentUser,
  ) {
    return StreamBuilder<List<AppUser>>(
      stream: service.watchStaff(),
      builder: (context, snap) {
        final staff = snap.data ?? <AppUser>[];

        // من هم الموظفون الذين لديهم طلبات فعلاً؟
        final busyIds = <String>{
          for (final o in allOrders)
            if (o.isAssigned) o.assigneeId!,
        };
        final activeStaff = staff.where((s) => busyIds.contains(s.id)).toList();
        final unassignedCount =
            allOrders.where((o) => !o.isAssigned).length;

        if (staff.isEmpty && unassignedCount == 0) {
          return const SizedBox.shrink();
        }

        return FilterBar(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
          children: [
            FilterPill(
              label: 'كل الموظفين',
              selected: _assigneeFilter == null,
              onTap: () => setState(() => _assigneeFilter = null),
            ),
            if (unassignedCount > 0)
              FilterPill(
                label: 'غير مُسند',
                color: AppColors.danger,
                count: unassignedCount,
                selected: _assigneeFilter == 'unassigned',
                onTap: () => setState(
                  () => _assigneeFilter =
                      _assigneeFilter == 'unassigned' ? null : 'unassigned',
                ),
              ),
            ...activeStaff.map(
              (s) => FilterPill(
                label: s.name,
                selected: _assigneeFilter == s.id,
                onTap: () => setState(
                  () => _assigneeFilter = _assigneeFilter == s.id ? null : s.id,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
