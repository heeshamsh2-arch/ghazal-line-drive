import 'package:flutter/material.dart';

import '../../core/date_format.dart';
import '../../core/theme.dart';
import '../../models/order.dart';
import 'common.dart';
import '../../core/constants.dart';

/// شارة حالة الطلب ملوّنة
class StatusChip extends StatelessWidget {
  const StatusChip({
    super.key,
    required this.status,
    this.small = false,
    this.showIcon = true,
  });

  final OrderStatus status;
  final bool small;
  final bool showIcon;

  static IconData iconFor(OrderStatus s) {
    switch (s) {
      case OrderStatus.newRequest:
        return Icons.fiber_new;
      case OrderStatus.underReview:
        return Icons.visibility_outlined;
      case OrderStatus.missingInfo:
        return Icons.help_outline;
      case OrderStatus.assigned:
        return Icons.assignment_ind_outlined;
      case OrderStatus.inProgress:
        return Icons.autorenew;
      case OrderStatus.ready:
        return Icons.check_circle_outline;
      case OrderStatus.delivered:
        return Icons.task_alt;
      case OrderStatus.cancelled:
        return Icons.cancel_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = Color(status.colorValue);
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: small ? 8 : 10,
        vertical: small ? 4 : 6,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (showIcon) ...[
            Icon(iconFor(status), size: small ? 12 : 14, color: color),
            const SizedBox(width: 5),
          ],
          Text(
            status.labelAr,
            style: TextStyle(
              color: color,
              fontSize: small ? 11.5 : 12.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

/// شارة صغيرة لنوع الخدمة
class ServiceTag extends StatelessWidget {
  const ServiceTag({super.key, required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.bg,
        borderRadius: BorderRadius.circular(7),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 11.5,
          color: AppColors.textMuted,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

/// بطاقة طلب قابلة للنقر
class OrderCard extends StatelessWidget {
  const OrderCard({
    super.key,
    required this.order,
    required this.onTap,
    this.showCustomer = false,
  });

  final Order order;
  final VoidCallback onTap;

  /// يظهر اسم العميل (للموظف والمدير)
  final bool showCustomer;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // الصف العلوي: العنوان + الشارة
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      order.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 15.5,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textMain,
                        height: 1.4,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  StatusChip(status: order.status, small: true),
                ],
              ),
              const SizedBox(height: 8),

              // نوع الخدمة + الكمية
              Row(
                children: [
                  ServiceTag(label: order.serviceType),
                  const SizedBox(width: 6),
                  ServiceTag(label: 'الكمية: ${order.quantity}'),
                  if (order.price != null && order.price! > 0) ...[
                    const SizedBox(width: 6),
                    ServiceTag(label: formatMoney(order.price!)),
                  ],
                ],
              ),

              // اسم العميل
              if (showCustomer) ...[
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Icon(Icons.person_outline,
                        size: AppConstants.iconInline, color: AppColors.textMuted),
                    const SizedBox(width: 5),
                    Expanded(
                      child: Text(
                        order.customerName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: AppConstants.iconInline,
                          color: AppColors.textMuted,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],

              const SizedBox(height: 10),
              const Divider(height: 1),
              const SizedBox(height: 10),

              // الصف السفلي: الموظف + المرفقات + الوقت
              Row(
                children: [
                  Icon(
                    order.isAssigned
                        ? Icons.engineering_outlined
                        : Icons.hourglass_empty,
                    size: AppConstants.iconInline,
                    color: order.isAssigned
                        ? AppColors.primary
                        : AppColors.textMuted,
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(
                      order.isAssigned
                          ? '${order.assigneeName}'
                          : 'لم يُسند بعد',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        color: order.isAssigned
                            ? AppColors.primary
                            : AppColors.textMuted,
                      ),
                    ),
                  ),
                  if (order.attachments.isNotEmpty) ...[
                    const SizedBox(width: 8),
                    const Icon(Icons.attach_file, size: AppConstants.iconInline, color: AppColors.textMuted),
                    Text(
                      '${order.attachments.length}',
                      style: const TextStyle(
                        fontSize: AppConstants.iconInline,
                        color: AppColors.textMuted,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                  const SizedBox(width: 10),
                  Text(
                    timeAgoAr(order.updatedAt),
                    style: const TextStyle(fontSize: 11.5, color: AppColors.textMuted),
                  ),
                ],
              ),

              // تحذير التأخير
              if (order.isLate) ...[
                const SizedBox(height: 10),
                AlertBanner(
                  message: 'تجاوز الموعد المحدّد',
                  color: AppColors.danger,
                  icon: Icons.schedule,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

/// صف فلاتر أفقي
class FilterBar extends StatelessWidget {
  const FilterBar({
    super.key,
    required this.children,
    this.padding =
        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
  });

  final List<Widget> children;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 42,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: padding,
        itemCount: children.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) => Center(child: children[i]),
      ),
    );
  }
}

/// زر فلتر قابل للاختيار
class FilterPill extends StatelessWidget {
  const FilterPill({
    super.key,
    required this.label,
    required this.selected,
    required this.onTap,
    this.color,
    this.count,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Color? color;
  final int? count;

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.primary;
    return Material(
      color: selected ? c : Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: selected ? c : AppColors.cardBorder),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (color != null) ...[
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: selected ? Colors.white : c,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
              ],
              Text(
                count != null ? '$label ($count)' : label,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                  color: selected ? Colors.white : AppColors.textMain,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

