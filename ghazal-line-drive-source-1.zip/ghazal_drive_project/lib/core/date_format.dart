/// أدوات تنسيق التواريخ بالعربية (بدون الحاجة لحزمة intl)
library;

const List<String> _arMonths = <String>[
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

const List<String> _arDays = <String>[
  'الإثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت',
  'الأحد',
];

String _two(int n) => n.toString().padLeft(2, '0');

/// مثال: 5 مارس 2026
String formatDateAr(DateTime date) {
  return '${date.day} ${_arMonths[date.month - 1]} ${date.year}';
}

/// مثال: 5 مارس 2026 - 03:20 مساءً
String formatDateTimeAr(DateTime date) {
  final h = date.hour;
  final period = h < 12 ? 'صباحاً' : 'مساءً';
  final h12 = h % 12 == 0 ? 12 : h % 12;
  return '${formatDateAr(date)} - ${_two(h12)}:${_two(date.minute)} $period';
}

/// مثال: الأربعاء 5 مارس
String formatDayAr(DateTime date) {
  return '${_arDays[date.weekday - 1]} ${date.day} ${_arMonths[date.month - 1]}';
}

/// «قبل 5 دقائق» / «قبل ساعتين» / «أمس»
String timeAgoAr(DateTime date, {DateTime? now}) {
  final ref = now ?? DateTime.now();
  final diff = ref.difference(date);

  if (diff.isNegative) return 'الآن';
  if (diff.inSeconds < 60) return 'قبل لحظات';
  if (diff.inMinutes < 60) {
    final m = diff.inMinutes;
    return m == 1 ? 'قبل دقيقة' : m == 2 ? 'قبل دقيقتين' : 'قبل $m دقيقة';
  }
  if (diff.inHours < 24) {
    final h = diff.inHours;
    if (h == 1) return 'قبل ساعة';
    if (h == 2) return 'قبل ساعتين';
    return 'قبل $h ساعات';
  }
  if (diff.inDays == 1) return 'أمس';
  if (diff.inDays == 2) return 'قبل يومين';
  if (diff.inDays < 30) return 'قبل ${diff.inDays} يوم';

  final m = diff.inDays ~/ 30;
  if (m == 1) return 'قبل شهر';
  if (m == 2) return 'قبل شهرين';
  return 'قبل $m أشهر';
}

/// حجم الملف بصيغة مقروءة
String formatBytes(int bytes) {
  if (bytes <= 0) return '0 بايت';
  const units = ['بايت', 'كيلوبايت', 'megabytes', 'جيجابايت'];
  var i = 0;
  double size = bytes.toDouble();
  while (size >= 1024 && i < units.length - 1) {
    size /= 1024;
    i++;
  }
  final txt = size >= 10 || i == 0 || size == size.roundToDouble()
      ? size.toStringAsFixed(0)
      : size.toStringAsFixed(1);
  return '$txt ${units[i]}';
}

/// تنسيق مبلغ مالي
String formatMoney(num amount) {
  final fixed = amount == amount.roundToDouble()
      ? amount.toStringAsFixed(0)
      : amount.toStringAsFixed(2);
  return '$fixed ريال';
}
