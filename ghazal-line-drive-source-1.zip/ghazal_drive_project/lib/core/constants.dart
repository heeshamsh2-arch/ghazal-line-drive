/// ثوابت التطبيق العامة
class AppConstants {
  AppConstants._();

  static const String appName = 'غرزة لاين';
  static const String appTagline = 'نظام إدارة الطلبات والمطبوعات';

  // ── حساب المدير المسجّل مسبقاً ──────────────────────────────
  // ⚠️ غيّر كلمة المرور بعد أول تسجيل دخول، ثم احذف هذا التعليق.
  static const String managerEmail = 'manager@ghazalline.app';
  static const String managerPassword = 'Ghazal@2026';
  static const String managerName = 'مدير النظام';

  // ── أسماء المجموعات في Firestore ───────────────────────────
  static const String usersCollection = 'users';
  static const String ordersCollection = 'orders';
  static const String codesCollection = 'invite_codes';
  static const String countersCollection = 'counters';

  // ── مسار التخزين ──────────────────────────────────────────
  static const String storageOrdersPath = 'orders';

  // ── أنواع الخدمات التي يقدّمها المشروع ────────────────────
  static const List<String> serviceTypes = <String>[
    'طباعة Offset',
    'طباعة رقمية (ديجيتال)',
    'تصميم جرافيك',
    'مطبوعات ترويجية',
    'كروت ولافتات',
    'تغليف وعلب',
    'أختام وختم',
    'ملابس ونقش',
    'أخرى',
  ];

  /// أقسام لوحة المدير
  static const String sectionDesign = 'design';
  static const String sectionPrint = 'print';
  static const String sectionOther = 'other';

  /// هل هذا النوع من الخدمات يتطلب مصمماً؟
  static bool needsDesigner(String serviceType) {
    return serviceType == 'تصميم جرافيك' ||
        serviceType == 'مطبوعات ترويجية' ||
        serviceType == 'كروت ولافتات' ||
        serviceType == 'أخرى';
  }

  /// ═══════════════════════════════════════════════════════
  ///  مقاسات أيقونات موحّدة لكل التطبيق
  /// ═══════════════════════════════════════════════════════

  /// أيقونة حقول الإدخال (prefix/suffix) — 22
  static const double iconInput = 22;

  /// أيقونة أزرار الإجراءات (IconButton, FAB) — 22
  static const double iconAction = 22;

  /// أيقونة مقدمة عناصر القوائم (leading) — 20
  static const double iconLeading = 20;

  /// أيقونة العناوين/الرؤوس (headers, titles) — 24
  static const double iconHeader = 24;

  /// أيقونة الحالات الفارغة/الزخرفية — 48
  static const double iconEmpty = 48;

  /// أيقونة صغيرة داخل السطر (inline) — 16
  static const double iconInline = 16;

  /// أيقونة التنبيهات (SnackBar, AlertBanner) — 24
  static const double iconAlert = 24;

  /// حجم شعار التطبيق (AppLogo) في شاشة البداية — 92
  static const double logoSplash = 92;

  /// حجم شعار التطبيق في شاشة الدخول — 84
  static const double logoLogin = 84;

  /// حجم صورة المستخدم (UserAvatar) الافتراضي — 42
  static const double avatarDefault = 42;
}