/// نتيجة عملية (نجاح/خطأ) برسالة عربية جاهزة للعرض
class OpResult {
  final bool success;
  final String? errorAr;

  const OpResult.success()
      : success = true,
        errorAr = null;

  const OpResult.failure(this.errorAr) : success = false;
}
