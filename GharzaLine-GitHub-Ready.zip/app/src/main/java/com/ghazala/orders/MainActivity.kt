package com.ghazala.orders

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private val prefs by lazy { getSharedPreferences("gharza_line", MODE_PRIVATE) }

    // نفس الاتصال الحالي — Google Apps Script + Google Drive
    private val apiUrl = "https://script.google.com/macros/s/AKfycbwWlkdyYxX6bDKsVpwC5q4-AiX9JCbBx429xXzlV9oTZ3qSW80jgjBskzpNCegP0YzF/exec"

    private var token = ""
    private var user = JSONObject()
    private var orders = JSONArray()
    private var users = JSONArray()
    private var currentTab = 0
    private var pendingUploadOrderId: String? = null
    private var newOrderAfterPick: JSONObject? = null
    private var adminStatusFilter = "all"
    private var customerStatusFilter = "all"

    private val primary = Color.parseColor("#1769AA")
    private val primaryDark = Color.parseColor("#0F4F82")
    private val primarySoft = Color.parseColor("#EAF4FD")
    private val bg = Color.parseColor("#F4F7FB")
    private val cardBorder = Color.parseColor("#DFE7EF")
    private val textMain = Color.parseColor("#172536")
    private val textMuted = Color.parseColor("#6B7B8C")
    private val success = Color.parseColor("#15803D")
    private val warning = Color.parseColor("#B45309")
    private val danger = Color.parseColor("#B91C1C")
    private val purple = Color.parseColor("#7C3AED")

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val fresh = newOrderAfterPick
        newOrderAfterPick = null
        if (fresh != null) {
            createOrderThenUpload(fresh, uris)
            return@registerForActivityResult
        }
        val id = pendingUploadOrderId
        pendingUploadOrderId = null
        if (id != null && uris.isNotEmpty()) uploadFiles(id, uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        root = FrameLayout(this).apply { setBackgroundColor(bg) }
        setContentView(root)
        token = prefs.getString("token", "") ?: ""
        if (token.isBlank()) showAuth() else sync()
    }

    // ───────────────────── الدخول والتسجيل ─────────────────────

    private fun showAuth() {
        currentTab = 0
        root.removeAllViews()
        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(42), dp(24), dp(28))
        }
        scroll.addView(page, ScrollView.LayoutParams(-1, -2)); root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        page.addView(appLogo(dp(86))); page.addView(space(15))
        page.addView(label("غرزة لاين", 29f, textMain, true, Gravity.CENTER))
        page.addView(space(6)); page.addView(label("إدارة طلبات الصور وملفات PDF", 14f, textMuted, false, Gravity.CENTER))
        page.addView(space(25))

        val body = vertical(dp(22))
        body.addView(label("تسجيل الدخول", 21f, textMain, true)); body.addView(space(5))
        body.addView(label("ادخل بيانات حسابك للمتابعة", 13.5f, textMuted)); body.addView(space(18))
        val id = styledInput("رقم الجوال أو البريد الإلكتروني")
        val pass = styledInput("كلمة المرور", true)
        body.addView(id); body.addView(space(11)); body.addView(pass); body.addView(space(17))
        body.addView(primaryButton("دخول") {
            if (id.text.toString().trim().isBlank() || pass.text.toString().isBlank()) toast("أدخل بيانات الدخول")
            else login(id.text.toString().trim(), pass.text.toString())
        })
        body.addView(space(11)); body.addView(outlineButton("تسجيل عميل جديد") { showRegister() })
        page.addView(whiteCard(body), LinearLayout.LayoutParams(-1, -2))
        page.addView(space(14)); page.addView(outlineButton("اختبار الاتصال") { ping() }, LinearLayout.LayoutParams(-1, dp(48)))
        page.addView(space(10)); page.addView(label("الاتصال والمرفقات عبر Google Drive", 12f, textMuted, false, Gravity.CENTER))
    }

    private fun showRegister() {
        root.removeAllViews()
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = vertical(dp(22)); page.setPadding(dp(22), dp(28), dp(22), dp(28))
        scroll.addView(page); root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        page.addView(outlineButton("← رجوع") { showAuth() }); page.addView(space(18))
        page.addView(label("إنشاء حساب عميل", 23f, textMain, true, Gravity.CENTER)); page.addView(space(18))
        val body = vertical(dp(20))
        val name = styledInput("اسم العميل")
        val company = styledInput("اسم الشركة / المتجر")
        val phone = styledInput("رقم الجوال")
        val email = styledInput("البريد الإلكتروني - اختياري")
        val pass = styledInput("كلمة المرور - 6 أحرف فأكثر", true)
        listOf(name, company, phone, email, pass).forEachIndexed { i, v -> body.addView(v); if (i < 4) body.addView(space(10)) }
        body.addView(space(17)); body.addView(primaryButton("إنشاء الحساب") {
            registerClient(name.text.toString().trim(), company.text.toString().trim(), phone.text.toString().trim(), email.text.toString().trim(), pass.text.toString())
        })
        page.addView(whiteCard(body), LinearLayout.LayoutParams(-1, -2))
    }

    // ───────────────────── API: نفس طريقة الاتصال ─────────────────────

    private fun login(identifier: String, password: String) {
        busyPost(JSONObject().apply { put("action", "login"); put("identifier", identifier); put("password", password) }) { r ->
            if (!r.optBoolean("ok")) return@busyPost toast(r.optString("error", "فشل تسجيل الدخول"))
            token = r.optString("token"); user = r.optJSONObject("user") ?: JSONObject()
            prefs.edit().putString("token", token).apply(); sync()
        }
    }

    private fun registerClient(name: String, company: String, phone: String, email: String, password: String) {
        if (name.isBlank() || phone.isBlank() || password.length < 6) return toast("أكمل الاسم والجوال وكلمة المرور")
        busyPost(JSONObject().apply {
            put("action", "registerClient"); put("name", name); put("company", company); put("phone", phone); put("email", email); put("password", password)
        }) { r ->
            if (!r.optBoolean("ok")) return@busyPost toast(r.optString("error", "تعذر التسجيل"))
            token = r.optString("token"); user = r.optJSONObject("user") ?: JSONObject()
            prefs.edit().putString("token", token).apply(); sync()
        }
    }

    private fun sync() {
        busyPost(JSONObject().apply { put("action", "sync"); put("token", token) }) { r ->
            if (!r.optBoolean("ok")) {
                prefs.edit().remove("token").apply(); token = ""; toast("سجّل الدخول من جديد"); showAuth(); return@busyPost
            }
            user = r.optJSONObject("user") ?: JSONObject(); orders = r.optJSONArray("orders") ?: JSONArray()
            users = r.optJSONArray("users") ?: users
            showDashboard()
        }
    }

    // ───────────────────── الهيكل والقوائم ─────────────────────

    private fun showDashboard() {
        root.removeAllViews()
        val role = user.optString("role")
        val tabs = tabsFor(role)
        if (currentTab !in tabs.indices) currentTab = 0
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        root.addView(shell, FrameLayout.LayoutParams(-1, -1))
        shell.addView(topBar(tabs[currentTab].first, role), LinearLayout.LayoutParams(-1, dp(66)))
        val body = FrameLayout(this).apply { setBackgroundColor(bg) }
        shell.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        shell.addView(bottomNav(tabs), LinearLayout.LayoutParams(-1, dp(76)))
        renderTab(body, role, tabs[currentTab].first)
    }

    private fun tabsFor(role: String): List<Pair<String, String>> = when (role) {
        "admin" -> listOf("الرئيسية" to "⌂", "الطلبات" to "▣", "العملاء" to "♙", "الفريق" to "♟", "حسابي" to "●")
        "worker", "designer" -> listOf("طلباتي" to "▣", "التنفيذ" to "✓", "حسابي" to "●")
        else -> listOf("طلباتي" to "▣", "طلب جديد" to "+", "حسابي" to "●")
    }

    private fun renderTab(body: FrameLayout, role: String, title: String) {
        when (title) {
            "الرئيسية" -> renderAdminHome(body)
            "الطلبات" -> renderAdminOrders(body)
            "العملاء" -> renderClients(body)
            "الفريق" -> renderTeam(body)
            "طلب جديد" -> renderNewOrder(body)
            "التنفيذ" -> renderWorkerExecution(body)
            "حسابي" -> renderProfile(body)
            else -> renderRoleOrders(body, role)
        }
    }

    private fun topBar(title: String, role: String): View {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), 0, dp(16), 0); setBackgroundColor(Color.WHITE); elevation = dp(2).toFloat() }
        val avatar = label(userInitials(), 13f, Color.WHITE, true, Gravity.CENTER).apply { background = circle(primary) }
        bar.addView(avatar, LinearLayout.LayoutParams(dp(40), dp(40)))
        bar.addView(spaceHorizontal(11))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label(title, 17f, textMain, true)); titles.addView(label("غرزة لاين • ${roleLabel(role)}", 11.5f, textMuted))
        bar.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        val sync = actionButton("↻ تحديث") { sync() }; bar.addView(sync)
        return bar
    }

    private fun bottomNav(tabs: List<Pair<String, String>>): View {
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(5), dp(6), dp(5)); setBackgroundColor(Color.WHITE); elevation = dp(8).toFloat() }
        tabs.forEachIndexed { index, t ->
            val selected = index == currentTab
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(5), dp(4), dp(4))
                background = if (selected) rounded(primarySoft, 16f) else null
                setOnClickListener { currentTab = index; showDashboard() }
            }
            item.addView(label(t.second, 19f, if (selected) primary else textMuted, selected, Gravity.CENTER))
            item.addView(label(t.first, 10.5f, if (selected) primary else textMuted, selected, Gravity.CENTER))
            nav.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
        }
        return nav
    }

    // ───────────────────── لوحة المدير ─────────────────────

    private fun renderAdminHome(body: FrameLayout) {
        val content = page(body)
        content.addView(label("نظرة عامة", 20f, textMain, true)); content.addView(space(10)); content.addView(statsRow())
        content.addView(space(18)); content.addView(sectionHeader("أحدث الطلبات", "${orders.length()} إجمالي")); content.addView(space(9))
        val latest = jsonObjects(orders).sortedByDescending { it.optString("createdAt") }.take(8)
        addOrders(content, latest, "admin")
    }

    private fun renderAdminOrders(body: FrameLayout) {
        val content = page(body)
        val search = styledInput("بحث برقم الطلب أو العميل أو العنوان")
        val searchBtn = actionButton("بحث") {
            val q = search.text.toString().trim().lowercase()
            renderFilteredAdminOrders(body, q)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(search, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(spaceHorizontal(8)); row.addView(searchBtn)
        content.addView(row); content.addView(space(10)); content.addView(statusFilterBar(true, body)); content.addView(space(12))
        addOrders(content, filteredAdminOrders(""), "admin")
    }

    private fun renderFilteredAdminOrders(body: FrameLayout, q: String) {
        body.removeAllViews(); val content = page(body)
        val search = styledInput("بحث").apply { setText(q) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(search, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(spaceHorizontal(8)); row.addView(actionButton("بحث") { renderFilteredAdminOrders(body, search.text.toString().trim().lowercase()) })
        content.addView(row); content.addView(space(10)); content.addView(statusFilterBar(true, body)); content.addView(space(12))
        addOrders(content, filteredAdminOrders(q), "admin")
    }

    private fun filteredAdminOrders(q: String): List<JSONObject> = jsonObjects(orders).filter { o ->
        val stOk = adminStatusFilter == "all" || statusGroup(o.optString("status")) == adminStatusFilter || o.optString("status") == adminStatusFilter
        val hay = "${o.optString("orderId")} ${o.optString("clientName")} ${o.optString("title")} ${o.optString("description")}".lowercase()
        stOk && (q.isBlank() || hay.contains(q))
    }

    private fun renderClients(body: FrameLayout) {
        val content = page(body); content.addView(sectionHeader("العملاء", "")); content.addView(space(10))
        val clients = jsonObjects(users).filter { it.optString("role") == "client" }
        if (clients.isEmpty()) content.addView(emptyState("لا يوجد عملاء", "ستظهر حسابات العملاء المسجلين هنا."))
        clients.forEach { c ->
            val count = jsonObjects(orders).count { it.optString("clientId") == c.optString("userId") }
            val card = vertical(dp(15)); card.addView(label(c.optString("company").ifBlank { c.optString("name") }, 16f, textMain, true))
            card.addView(space(4)); card.addView(label("${c.optString("name")} • ${c.optString("phone")}", 12.5f, textMuted)); card.addView(space(7)); card.addView(tag("$count طلب"))
            content.addView(whiteCard(card)); content.addView(space(9))
        }
    }

    private fun renderTeam(body: FrameLayout) {
        val content = page(body)
        val intro = vertical(dp(16)); intro.addView(label("إدارة العمال والمصممين", 17f, textMain, true)); intro.addView(space(5)); intro.addView(label("أضف أعضاء الفريق ثم أسند الطلبات إليهم.", 13f, textMuted)); intro.addView(space(12)); intro.addView(primaryButton("+ إضافة عامل أو مصمم") { addStaffDialog() })
        content.addView(whiteCard(intro)); content.addView(space(15))
        val staff = jsonObjects(users).filter { it.optString("role") in listOf("worker", "designer") }
        if (staff.isEmpty()) content.addView(emptyState("لا يوجد فريق", "أضف أول عامل أو مصمم."))
        staff.forEach { u -> content.addView(staffCard(u)); content.addView(space(9)) }
    }

    // ───────────────────── قوائم العميل والعامل ─────────────────────

    private fun renderRoleOrders(body: FrameLayout, role: String) {
        val content = page(body)
        if (role == "client") {
            content.addView(customerSummary()); content.addView(space(12)); content.addView(statusFilterBar(false, body)); content.addView(space(12))
            val filtered = jsonObjects(orders).filter { customerStatusFilter == "all" || statusGroup(it.optString("status")) == customerStatusFilter }
            addOrders(content, filtered, role)
        } else {
            content.addView(statsRow()); content.addView(space(14)); addOrders(content, jsonObjects(orders), role)
        }
    }

    private fun renderWorkerExecution(body: FrameLayout) {
        val content = page(body); content.addView(notice("افتح أي طلب لتحديث حالة كل صورة على حدة. حالة الطلب تتغير تلقائيًا حسب تقدم الصور.", success)); content.addView(space(12))
        addOrders(content, jsonObjects(orders).filter { it.optString("status") != "delivered" }, user.optString("role"))
    }

    private fun renderNewOrder(body: FrameLayout) {
        val content = page(body)
        val box = vertical(dp(17)); box.addView(label("إنشاء طلب جديد", 19f, textMain, true)); box.addView(space(6)); box.addView(label("أدخل تفاصيل الطلب ثم اختر الصور وملفات PDF. لا يضع التطبيق حدًا عدديًا للصور، مع مراعاة سعة Drive وحدود Apps Script.", 13f, textMuted)); box.addView(space(14))
        val title = styledInput("عنوان الطلب")
        val desc = styledInput("تفاصيل الطلب والكميات").apply { minLines = 4; gravity = Gravity.TOP or Gravity.START }
        box.addView(title); box.addView(space(10)); box.addView(desc); box.addView(space(10))
        val urgent = MaterialButton(this).apply { text = "الأولوية: عادي"; isCheckable = true; setTextColor(warning); setBackgroundColor(Color.WHITE); strokeColor = ColorStateList.valueOf(cardBorder); strokeWidth = dp(1); cornerRadius = dp(12); setOnCheckedChangeListener { b, checked -> b.text = if (checked) "الأولوية: مستعجل" else "الأولوية: عادي" } }
        box.addView(urgent, LinearLayout.LayoutParams(-1, dp(48))); box.addView(space(13))
        box.addView(primaryButton("اختيار الملفات ثم إرسال الطلب") {
            val t = title.text.toString().trim(); val d = desc.text.toString().trim()
            if (t.isBlank() && d.isBlank()) return@primaryButton toast("أدخل عنوانًا أو تفاصيل للطلب")
            newOrderAfterPick = JSONObject().apply { put("title", if (t.isBlank()) "طلب جديد" else t); put("description", d); put("urgent", urgent.isChecked) }
            picker.launch(arrayOf("image/*", "application/pdf"))
        })
        box.addView(space(9)); box.addView(outlineButton("إنشاء بدون مرفقات") {
            val t = title.text.toString().trim(); val d = desc.text.toString().trim(); if (t.isBlank() && d.isBlank()) return@outlineButton toast("أدخل عنوانًا أو تفاصيل")
            createOrderThenUpload(JSONObject().apply { put("title", if (t.isBlank()) "طلب جديد" else t); put("description", d); put("urgent", urgent.isChecked) }, emptyList())
        })
        content.addView(whiteCard(box))
    }

    // ───────────────────── بطاقات الطلبات والتفاصيل ─────────────────────

    private fun addOrders(parent: LinearLayout, list: List<JSONObject>, role: String) {
        if (list.isEmpty()) { parent.addView(emptyState("لا توجد طلبات", "لا توجد نتائج مطابقة حاليًا.")); return }
        list.sortedByDescending { it.optString("createdAt") }.forEach { parent.addView(orderCard(it, role)); parent.addView(space(10)) }
    }

    private fun orderCard(o: JSONObject, role: String): View {
        val box = vertical(dp(15))
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        t.addView(label(o.optString("title").ifBlank { "طلب بدون عنوان" }, 16f, textMain, true)); t.addView(space(3)); t.addView(label(o.optString("orderId"), 11.5f, textMuted))
        top.addView(t, LinearLayout.LayoutParams(0, -2, 1f)); top.addView(statusChip(o.optString("status"))); box.addView(top)
        box.addView(space(9)); box.addView(label("العميل: ${o.optString("clientName")}", 12.5f, textMuted))
        if (o.optString("assignedName").isNotBlank()) { box.addView(space(4)); box.addView(label("المسند إليه: ${o.optString("assignedName")} — ${roleLabel(o.optString("assignedRole"))}", 12.5f, textMuted)) }
        if (o.optBoolean("urgent")) { box.addView(space(7)); box.addView(tagColored("مستعجل", warning)) }
        val files = o.optJSONArray("files") ?: JSONArray(); val images = jsonObjects(files).filter { it.optString("mimeType").startsWith("image/") }
        if (images.isNotEmpty()) {
            val ready = images.count { it.optString("itemStatus", "new") == "ready" }; box.addView(space(10)); box.addView(progressView(ready, images.size))
        }
        box.addView(space(11)); val meta = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        meta.addView(tag("${files.length()} مرفق")); meta.addView(spaceHorizontal(6)); meta.addView(tag(formatDate(o.optString("createdAt"))))
        box.addView(meta); box.addView(space(12)); box.addView(primaryButton("فتح الطلب") { orderDetails(o) })
        return whiteCard(box)
    }

    private fun orderDetails(o: JSONObject) {
        val role = user.optString("role")
        val scroll = ScrollView(this); val body = vertical(dp(18)); scroll.addView(body)
        body.addView(label(o.optString("title"), 20f, textMain, true)); body.addView(space(5)); body.addView(label(o.optString("orderId"), 11.5f, textMuted)); body.addView(space(9)); body.addView(statusChip(o.optString("status")))
        if (o.optBoolean("urgent")) { body.addView(space(7)); body.addView(tagColored("مستعجل", warning)) }
        body.addView(space(13)); body.addView(infoLine("العميل", o.optString("clientName")))
        body.addView(infoLine("المسند إليه", o.optString("assignedName").ifBlank { "غير مسند" }))
        body.addView(space(8)); body.addView(label("التفاصيل", 14f, textMain, true)); body.addView(space(4)); body.addView(label(o.optString("description").ifBlank { "لا توجد تفاصيل" }, 13f, textMuted))
        if (o.optString("notes").isNotBlank()) { body.addView(space(8)); body.addView(notice(o.optString("notes"), warning)) }

        val files = o.optJSONArray("files") ?: JSONArray(); val fileList = jsonObjects(files)
        body.addView(space(16)); body.addView(label("الصور والمرفقات", 16f, textMain, true)); body.addView(space(8))
        if (fileList.isEmpty()) body.addView(label("لا توجد مرفقات.", 13f, textMuted))
        else {
            val canEditFiles = role == "admin" || role == "worker" || role == "designer"
            val images = fileList.filter { it.optString("mimeType").startsWith("image/") }
            if (canEditFiles && images.isNotEmpty()) {
                val bulk = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                bulk.addView(actionButton("الكل قيد التنفيذ") { bulkFileStatus(o.optString("orderId"), "working") }, LinearLayout.LayoutParams(0, dp(44), 1f)); bulk.addView(spaceHorizontal(7)); bulk.addView(actionButton("الكل جاهز") { bulkFileStatus(o.optString("orderId"), "ready") }, LinearLayout.LayoutParams(0, dp(44), 1f)); body.addView(bulk); body.addView(space(8))
            }
            fileList.forEachIndexed { index, f -> body.addView(fileCard(o, f, index + 1, canEditFiles)); body.addView(space(7)) }
        }

        if (role == "admin") {
            body.addView(space(14)); body.addView(label("إدارة الطلب", 16f, textMain, true)); body.addView(space(8))
            body.addView(primaryButton("إسناد إلى عامل / مصمم") { assignDialog(o.optString("orderId")); }); body.addView(space(8)); body.addView(outlineButton("تغيير حالة الطلب") { statusDialog(o.optString("orderId"), o.optString("status")) })
        }
        if (role == "client" && o.optString("status") == "approval") {
            body.addView(space(14)); body.addView(notice("هذا الطلب ينتظر موافقتك.", warning)); body.addView(space(8))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(primaryButton("موافق") { customerApproval(o.optString("orderId"), true) }, LinearLayout.LayoutParams(0, dp(50), 1f)); row.addView(spaceHorizontal(8)); row.addView(outlineButton("يحتاج تعديل", danger) { customerApproval(o.optString("orderId"), false) }, LinearLayout.LayoutParams(0, dp(50), 1f)); body.addView(row)
        }
        if (role == "client" || role == "admin") { body.addView(space(12)); body.addView(outlineButton("+ إضافة صور / PDF") { pendingUploadOrderId = o.optString("orderId"); picker.launch(arrayOf("image/*", "application/pdf")) }) }

        val events = jsonObjects(o.optJSONArray("events") ?: JSONArray()).sortedByDescending { it.optString("createdAt") }
        if (events.isNotEmpty()) {
            body.addView(space(16)); body.addView(label("سجل الطلب", 16f, textMain, true)); body.addView(space(6))
            events.forEach { e -> body.addView(label("• ${statusLabel(e.optString("status"))} — ${e.optString("userName")}\n  ${e.optString("note")}  ${formatDate(e.optString("createdAt"))}", 12.5f, textMuted)); body.addView(space(6)) }
        }
        AlertDialog.Builder(this).setView(scroll).setPositiveButton("إغلاق", null).show()
    }

    private fun fileCard(order: JSONObject, f: JSONObject, index: Int, canEdit: Boolean): View {
        val box = vertical(dp(12)); val isImage = f.optString("mimeType").startsWith("image/")
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        names.addView(label(if (isImage) "الصورة $index" else "مرفق $index", 13.5f, textMain, true)); names.addView(label(f.optString("fileName"), 11.5f, textMuted))
        top.addView(names, LinearLayout.LayoutParams(0, -2, 1f)); if (isImage) top.addView(fileStatusChip(f.optString("itemStatus", "new")))
        box.addView(top); box.addView(space(8))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        if (f.optString("driveUrl").isNotBlank()) actions.addView(actionButton("فتح الملف") { openUrl(f.optString("driveUrl")) })
        if (isImage && canEdit) { if (actions.childCount > 0) actions.addView(spaceHorizontal(6)); actions.addView(actionButton("تغيير الحالة") { fileStatusDialog(order.optString("orderId"), f) }) }
        box.addView(actions)
        return MaterialCardView(this).apply { radius = dp(12).toFloat(); setCardBackgroundColor(Color.parseColor("#FBFDFF")); strokeColor = cardBorder; strokeWidth = dp(1); cardElevation = 0f; addView(box) }
    }

    // ───────────────────── إدارة الفريق ─────────────────────

    private fun staffCard(u: JSONObject): View {
        val box = vertical(dp(14)); val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val avatar = label(u.optString("name").take(2).ifBlank { "؟" }, 13f, Color.WHITE, true, Gravity.CENTER).apply { background = circle(if (u.optString("role") == "designer") purple else primary) }
        row.addView(avatar, LinearLayout.LayoutParams(dp(44), dp(44))); row.addView(spaceHorizontal(10))
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; tx.addView(label(u.optString("name"), 15f, textMain, true)); tx.addView(label("${u.optString("company")} ${u.optString("phone")}", 12f, textMuted)); row.addView(tx, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(roleChip(u.optString("role"))); box.addView(row)
        box.addView(space(10)); val acts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        acts.addView(actionButton("تعديل") { editStaffDialog(u) }, LinearLayout.LayoutParams(0, dp(44), 1f)); acts.addView(spaceHorizontal(7)); acts.addView(actionButton("تعطيل") { deleteStaff(u) }, LinearLayout.LayoutParams(0, dp(44), 1f)); box.addView(acts)
        return whiteCard(box)
    }

    private fun addStaffDialog() {
        val wrap = vertical(dp(18)); val name = styledInput("الاسم"); val company = styledInput("القسم / الفرع"); val phone = styledInput("رقم الجوال"); val email = styledInput("البريد - اختياري"); val pass = styledInput("كلمة المرور", true)
        listOf(name, company, phone, email, pass).forEachIndexed { i, v -> wrap.addView(v); if (i < 4) wrap.addView(space(8)) }
        var selected = 0
        AlertDialog.Builder(this).setTitle("إضافة عضو فريق").setView(wrap).setSingleChoiceItems(arrayOf("عامل", "مصمم"), 0) { _, w -> selected = w }
            .setPositiveButton("إضافة") { _, _ -> busyPost(JSONObject().apply { put("action", "addStaff"); put("token", token); put("name", name.text.toString().trim()); put("company", company.text.toString().trim()); put("phone", phone.text.toString().trim()); put("email", email.text.toString().trim()); put("password", pass.text.toString()); put("role", if (selected == 1) "designer" else "worker") }) { r -> if (r.optBoolean("ok")) { toast("تمت الإضافة"); sync() } else toast(r.optString("error")) } }.setNegativeButton("إلغاء", null).show()
    }

    private fun editStaffDialog(u: JSONObject) {
        val wrap = vertical(dp(18)); val name = styledInput("الاسم").apply { setText(u.optString("name")) }; val company = styledInput("القسم / الفرع").apply { setText(u.optString("company")) }; val phone = styledInput("الجوال").apply { setText(u.optString("phone")) }; val email = styledInput("البريد").apply { setText(u.optString("email")) }; val pass = styledInput("كلمة مرور جديدة - اختياري", true)
        listOf(name, company, phone, email, pass).forEachIndexed { i, v -> wrap.addView(v); if (i < 4) wrap.addView(space(8)) }
        AlertDialog.Builder(this).setTitle("تعديل الموظف").setView(wrap).setPositiveButton("حفظ") { _, _ -> busyPost(JSONObject().apply { put("action", "updateStaff"); put("token", token); put("userId", u.optString("userId")); put("name", name.text.toString().trim()); put("company", company.text.toString().trim()); put("phone", phone.text.toString().trim()); put("email", email.text.toString().trim()); if (pass.text.toString().isNotBlank()) put("password", pass.text.toString()) }) { r -> if (r.optBoolean("ok")) { toast("تم الحفظ"); sync() } else toast(r.optString("error")) } }.setNegativeButton("إلغاء", null).show()
    }

    private fun deleteStaff(u: JSONObject) {
        AlertDialog.Builder(this).setTitle("تعطيل الحساب").setMessage("سيبقى سجل الطلبات محفوظًا، لكن لن يستطيع ${u.optString("name")} تسجيل الدخول.").setNegativeButton("إلغاء", null).setPositiveButton("تعطيل") { _, _ -> busyPost(JSONObject().apply { put("action", "deleteStaff"); put("token", token); put("userId", u.optString("userId")) }) { r -> if (r.optBoolean("ok")) { toast("تم تعطيل الحساب"); sync() } else toast(r.optString("error")) } }.show()
    }

    // ───────────────────── أوامر الطلب ─────────────────────

    private fun createOrderThenUpload(data: JSONObject, uris: List<Uri>) {
        busyPost(JSONObject().apply { put("action", "createOrder"); put("token", token); put("title", data.optString("title")); put("description", data.optString("description")); put("urgent", data.optBoolean("urgent")) }) { r ->
            if (!r.optBoolean("ok")) return@busyPost toast(r.optString("error", "تعذر إنشاء الطلب"))
            val id = r.optJSONObject("order")?.optString("orderId") ?: ""
            if (id.isBlank()) return@busyPost toast("تم إنشاء الطلب لكن تعذر قراءة رقمه")
            if (uris.isEmpty()) { toast("تم إنشاء الطلب"); currentTab = 0; sync() } else uploadFiles(id, uris)
        }
    }

    private fun assignDialog(orderId: String) {
        val staff = jsonObjects(users).filter { it.optString("role") in listOf("worker", "designer") && it.optBoolean("active", true) }
        if (staff.isEmpty()) return toast("أضف عاملًا أو مصممًا أولًا")
        val labels = staff.map { "${it.optString("name")} — ${roleLabel(it.optString("role"))}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("إسناد الطلب").setItems(labels) { _, w ->
            val note = EditText(this).apply { hint = "ملاحظة للعامل - اختياري" }
            AlertDialog.Builder(this).setTitle(labels[w]).setView(note).setPositiveButton("إرسال الطلب") { _, _ ->
                busyPost(JSONObject().apply { put("action", "assignOrder"); put("token", token); put("orderId", orderId); put("userId", staff[w].optString("userId")); put("note", note.text.toString().trim()) }) { r -> if (r.optBoolean("ok")) { toast("تم الإسناد"); sync() } else toast(r.optString("error")) }
            }.setNegativeButton("إلغاء", null).show()
        }.show()
    }

    private fun statusDialog(orderId: String, current: String) {
        val values = arrayOf("new", "review", "assigned", "working", "approval", "ready", "delivered")
        val labels = values.map { statusLabel(it) }.toTypedArray(); var selected = values.indexOf(normalizeStatus(current)).coerceAtLeast(0)
        val note = styledInput("ملاحظة - اختياري")
        AlertDialog.Builder(this).setTitle("حالة الطلب").setSingleChoiceItems(labels, selected) { _, w -> selected = w }.setView(note).setPositiveButton("حفظ") { _, _ -> busyPost(JSONObject().apply { put("action", "updateOrderStatus"); put("token", token); put("orderId", orderId); put("status", values[selected]); put("notes", note.text.toString().trim()) }) { r -> if (r.optBoolean("ok")) { toast("تم تحديث الحالة"); sync() } else toast(r.optString("error")) } }.setNegativeButton("إلغاء", null).show()
    }

    private fun fileStatusDialog(orderId: String, file: JSONObject) {
        val values = arrayOf("new", "working", "ready", "issue"); val labels = arrayOf("لم يبدأ", "قيد التنفيذ", "جاهزة", "تحتاج تعديل"); var selected = values.indexOf(file.optString("itemStatus", "new")).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(file.optString("fileName")).setSingleChoiceItems(labels, selected) { _, w -> selected = w }.setPositiveButton("حفظ") { _, _ -> busyPost(JSONObject().apply { put("action", "updateFileStatus"); put("token", token); put("orderId", orderId); put("fileId", file.optString("fileId")); put("status", values[selected]) }) { r -> if (r.optBoolean("ok")) { toast("تم تحديث الصورة"); sync() } else toast(r.optString("error")) } }.setNegativeButton("إلغاء", null).show()
    }

    private fun bulkFileStatus(orderId: String, status: String) {
        busyPost(JSONObject().apply { put("action", "bulkUpdateFileStatus"); put("token", token); put("orderId", orderId); put("status", status) }) { r -> if (r.optBoolean("ok")) { toast("تم تحديث الصور"); sync() } else toast(r.optString("error")) }
    }

    private fun customerApproval(orderId: String, approved: Boolean) {
        busyPost(JSONObject().apply { put("action", "customerApproval"); put("token", token); put("orderId", orderId); put("approved", approved) }) { r -> if (r.optBoolean("ok")) { toast(if (approved) "تمت الموافقة" else "تم طلب التعديل"); sync() } else toast(r.optString("error")) }
    }

    // ───────────────────── رفع الملفات: لم تتغير الطريقة ─────────────────────

    private fun uploadFiles(orderId: String, uris: List<Uri>) {
        toast("بدء رفع ${uris.size} ملف")
        Thread {
            var ok = 0
            for (uri in uris) {
                try {
                    val name = fileName(uri); val mime = contentResolver.getType(uri) ?: "application/octet-stream"
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: continue
                    val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                    val r = post(JSONObject().apply { put("action", "uploadFile"); put("token", token); put("orderId", orderId); put("fileName", name); put("mimeType", mime); put("base64Data", b64) })
                    if (r.optBoolean("ok")) ok++
                } catch (_: Exception) { }
            }
            runOnUiThread { toast("تم رفع $ok من ${uris.size}"); currentTab = 0; sync() }
        }.start()
    }

    private fun fileName(uri: Uri): String {
        var name = "file"; contentResolver.query(uri, null, null, null, null)?.use { c -> val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (idx >= 0 && c.moveToFirst()) name = c.getString(idx) }; return name
    }

    // ───────────────────── الحساب ─────────────────────

    private fun renderProfile(body: FrameLayout) {
        val content = page(body); val head = vertical(dp(22)); head.gravity = Gravity.CENTER
        val av = label(userInitials(), 20f, Color.WHITE, true, Gravity.CENTER).apply { background = circle(primary) }; head.addView(av, LinearLayout.LayoutParams(dp(72), dp(72))); head.addView(space(10)); head.addView(label(user.optString("name"), 20f, textMain, true, Gravity.CENTER)); head.addView(space(6)); head.addView(roleChip(user.optString("role"))); content.addView(whiteCard(head)); content.addView(space(12))
        val info = vertical(dp(15)); info.addView(infoLine("الشركة / القسم", user.optString("company").ifBlank { "—" })); info.addView(infoLine("الجوال", user.optString("phone").ifBlank { "—" })); info.addView(infoLine("البريد", user.optString("email").ifBlank { "—" })); content.addView(whiteCard(info)); content.addView(space(12)); content.addView(outlineButton("↻ مزامنة الآن") { sync() }); content.addView(space(8)); content.addView(outlineButton("تسجيل الخروج", danger) { confirmLogout() })
    }

    private fun confirmLogout() { AlertDialog.Builder(this).setTitle("تسجيل الخروج").setMessage("هل تريد الخروج من غرزة لاين؟").setNegativeButton("إلغاء", null).setPositiveButton("خروج") { _, _ -> logout() }.show() }
    private fun logout() { val old = token; token = ""; user = JSONObject(); prefs.edit().remove("token").apply(); showAuth(); Thread { try { post(JSONObject().apply { put("action", "logout"); put("token", old) }) } catch (_: Exception) {} }.start() }

    // ───────────────────── مرشحات وإحصاءات ─────────────────────

    private fun statsRow(): View {
        val list = jsonObjects(orders); fun c(group: String) = list.count { statusGroup(it.optString("status")) == group }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(statCard("الإجمالي", list.size.toString(), primary)); row.addView(spaceHorizontal(8)); row.addView(statCard("جديدة", c("new").toString(), primary)); row.addView(spaceHorizontal(8)); row.addView(statCard("قيد التنفيذ", c("working").toString(), warning)); row.addView(spaceHorizontal(8)); row.addView(statCard("تحتاج مراجعة", c("review").toString(), danger)); row.addView(spaceHorizontal(8)); row.addView(statCard("جاهزة", c("ready").toString(), success))
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun customerSummary(): View {
        val list = jsonObjects(orders); val imgs = list.flatMap { jsonObjects(it.optJSONArray("files") ?: JSONArray()) }.filter { it.optString("mimeType").startsWith("image/") }; val ready = imgs.count { it.optString("itemStatus", "new") == "ready" }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(statCard("الطلبات", list.size.toString(), primary)); row.addView(spaceHorizontal(8)); row.addView(statCard("صور جاهزة", ready.toString(), success)); row.addView(spaceHorizontal(8)); row.addView(statCard("غير جاهزة", (imgs.size - ready).coerceAtLeast(0).toString(), warning))
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun statusFilterBar(admin: Boolean, body: FrameLayout): View {
        val options = listOf("all" to "الكل", "new" to "جديد", "working" to "قيد التنفيذ", "review" to "مراجعة", "ready" to "جاهز", "delivered" to "تم التسليم")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        options.forEach { (k, n) ->
            val active = if (admin) adminStatusFilter == k else customerStatusFilter == k
            val b = MaterialButton(this).apply { text = n; textSize = 11.5f; setTextColor(if (active) Color.WHITE else primaryDark); setBackgroundColor(if (active) primary else Color.WHITE); strokeColor = ColorStateList.valueOf(if (active) primary else cardBorder); strokeWidth = dp(1); cornerRadius = dp(18); insetTop = 0; insetBottom = 0; setOnClickListener { if (admin) adminStatusFilter = k else customerStatusFilter = k; showDashboard() } }
            row.addView(b, LinearLayout.LayoutParams(-2, dp(40))); row.addView(spaceHorizontal(5))
        }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun statCard(title: String, value: String, color: Int): View { val x = vertical(dp(14)); x.addView(label(value, 23f, color, true)); x.addView(space(3)); x.addView(label(title, 12f, textMuted)); return whiteCard(x).apply { layoutParams = LinearLayout.LayoutParams(dp(128), dp(86)) } }

    // ───────────────────── شبكة واتصال ─────────────────────

    private fun ping() { Thread { try { val c = URL("$apiUrl?action=ping").openConnection() as HttpURLConnection; c.connectTimeout = 15000; c.readTimeout = 15000; val t = c.inputStream.bufferedReader().use { it.readText() }; runOnUiThread { toast(if (JSONObject(t).optBoolean("ok")) "الاتصال يعمل" else "تعذر الاتصال") } } catch (e: Exception) { runOnUiThread { toast("خطأ اتصال: ${e.message}") } } }.start() }
    private fun busyPost(payload: JSONObject, done: (JSONObject) -> Unit) { Thread { val r = try { post(payload) } catch (e: Exception) { JSONObject().put("ok", false).put("error", e.message ?: "خطأ اتصال") }; runOnUiThread { done(r) } }.start() }
    private fun post(payload: JSONObject): JSONObject { val c = URL(apiUrl).openConnection() as HttpURLConnection; c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 30000; c.readTimeout = 120000; c.setRequestProperty("Content-Type", "application/json; charset=UTF-8"); OutputStreamWriter(c.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }; val s = if (c.responseCode in 200..299) c.inputStream else c.errorStream; val t = BufferedReader(InputStreamReader(s, Charsets.UTF_8)).use { it.readText() }; c.disconnect(); return JSONObject(t) }

    // ───────────────────── عناصر التصميم ─────────────────────

    private fun page(body: FrameLayout): LinearLayout { val scroll = ScrollView(this); val content = vertical(0); content.setPadding(dp(15), dp(15), dp(15), dp(100)); scroll.addView(content); body.addView(scroll, FrameLayout.LayoutParams(-1, -1)); return content }
    private fun vertical(padding: Int): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(padding, padding, padding, padding) }
    private fun appLogo(size: Int): View = label("غ", 31f, Color.WHITE, true, Gravity.CENTER).apply { background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(primaryDark, primary)).apply { cornerRadius = size * .25f }; elevation = dp(6).toFloat(); layoutParams = LinearLayout.LayoutParams(size, size) }
    private fun whiteCard(child: View): MaterialCardView = MaterialCardView(this).apply { radius = dp(16).toFloat(); cardElevation = dp(1).toFloat(); setCardBackgroundColor(Color.WHITE); strokeColor = cardBorder; strokeWidth = dp(1); addView(child) }
    private fun primaryButton(text: String, click: () -> Unit): MaterialButton = MaterialButton(this).apply { this.text = text; textSize = 15f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); setTextColor(Color.WHITE); setBackgroundColor(primary); cornerRadius = dp(12); insetTop = 0; insetBottom = 0; minHeight = dp(50); setOnClickListener { click() } }
    private fun outlineButton(text: String, color: Int = primary, click: () -> Unit): MaterialButton = MaterialButton(this).apply { this.text = text; textSize = 14f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); setTextColor(color); setBackgroundColor(Color.WHITE); strokeColor = ColorStateList.valueOf(color); strokeWidth = dp(1); cornerRadius = dp(12); insetTop = 0; insetBottom = 0; minHeight = dp(48); setOnClickListener { click() } }
    private fun actionButton(text: String, click: () -> Unit): MaterialButton = MaterialButton(this).apply { this.text = text; textSize = 12f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); setTextColor(primaryDark); setBackgroundColor(Color.WHITE); strokeColor = ColorStateList.valueOf(cardBorder); strokeWidth = dp(1); cornerRadius = dp(11); insetTop = 0; insetBottom = 0; minHeight = dp(40); setPadding(dp(11), 0, dp(11), 0); setOnClickListener { click() } }
    private fun styledInput(hint: String, password: Boolean = false): EditText = EditText(this).apply { this.hint = hint; setTextColor(textMain); setHintTextColor(textMuted); textSize = 14f; typeface = Typeface.create("sans-serif", Typeface.NORMAL); setPadding(dp(14), dp(12), dp(14), dp(12)); background = rounded(Color.WHITE, 12f, cardBorder); minHeight = dp(52); inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT }
    private fun statusChip(status: String): View { val s = normalizeStatus(status); val c = when (s) { "working", "assigned", "approval" -> warning; "review" -> danger; "ready", "delivered" -> success; else -> primary }; return label(statusLabel(s), 11f, c, true, Gravity.CENTER).apply { background = rounded(withAlpha(c, 22), 18f); setPadding(dp(10), dp(5), dp(10), dp(5)) } }
    private fun fileStatusChip(status: String): View { val c = when (status) { "working" -> warning; "ready" -> success; "issue" -> danger; else -> textMuted }; return label(fileStatusLabel(status), 10.5f, c, true, Gravity.CENTER).apply { background = rounded(withAlpha(c, 20), 16f); setPadding(dp(8), dp(4), dp(8), dp(4)) } }
    private fun roleChip(role: String): View { val c = when (role) { "admin" -> warning; "designer" -> purple; "worker" -> primary; else -> success }; return label(roleLabel(role), 10.5f, c, true, Gravity.CENTER).apply { background = rounded(withAlpha(c, 20), 16f); setPadding(dp(9), dp(4), dp(9), dp(4)) } }
    private fun tag(text: String): View = label(text, 11f, textMuted, false, Gravity.CENTER).apply { background = rounded(Color.WHITE, 18f, cardBorder); setPadding(dp(9), dp(4), dp(9), dp(4)) }
    private fun tagColored(text: String, c: Int): View = label(text, 11f, c, true, Gravity.CENTER).apply { background = rounded(withAlpha(c, 20), 18f); setPadding(dp(9), dp(4), dp(9), dp(4)) }
    private fun notice(text: String, c: Int): View = label(text, 12.5f, c, false).apply { background = rounded(withAlpha(c, 18), 12f); setPadding(dp(12), dp(10), dp(12), dp(10)) }
    private fun progressView(ready: Int, total: Int): View { val wrap = vertical(0); val pct = if (total == 0) 0 else ready * 100 / total; val track = FrameLayout(this).apply { background = rounded(Color.parseColor("#E5EDF4"), 99f) }; val fill = View(this).apply { background = rounded(success, 99f) }; track.addView(fill, FrameLayout.LayoutParams(0, dp(9)).apply { width = dp((pct * 2.3).toInt().coerceAtLeast(1)) }); wrap.addView(track, LinearLayout.LayoutParams(dp(230), dp(9))); wrap.addView(space(5)); wrap.addView(label("$ready / $total صورة جاهزة — $pct%", 11.5f, textMuted)); return wrap }
    private fun sectionHeader(title: String, trailing: String): View { val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }; row.addView(label(title, 17f, textMain, true), LinearLayout.LayoutParams(0, -2, 1f)); if (trailing.isNotBlank()) row.addView(label(trailing, 12f, textMuted)); return row }
    private fun emptyState(title: String, msg: String): View { val b = vertical(dp(28)); b.gravity = Gravity.CENTER; b.addView(label("▢", 34f, primary, true, Gravity.CENTER)); b.addView(space(10)); b.addView(label(title, 16f, textMain, true, Gravity.CENTER)); b.addView(space(5)); b.addView(label(msg, 13f, textMuted, false, Gravity.CENTER)); return whiteCard(b) }
    private fun infoLine(key: String, value: String): View { val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(7)) }; row.addView(label(key, 12.5f, textMuted), LinearLayout.LayoutParams(0, -2, 1f)); row.addView(label(value, 13f, textMain, true)); return row }
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false, gravityValue: Int = Gravity.START): TextView = TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = gravityValue; typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL); setLineSpacing(0f, 1.12f) }
    private fun rounded(fill: Int, radius: Float, stroke: Int? = null): GradientDrawable = GradientDrawable().apply { setColor(fill); cornerRadius = dp(radius.toInt()).toFloat(); if (stroke != null) setStroke(dp(1), stroke) }
    private fun circle(fill: Int): GradientDrawable = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(fill) }
    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun spaceHorizontal(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }

    // ───────────────────── مساعدات ─────────────────────

    private fun jsonObjects(a: JSONArray): List<JSONObject> = (0 until a.length()).mapNotNull { a.optJSONObject(it) }
    private fun userInitials(): String { val p = user.optString("name").trim().split(Regex("\\s+")).filter { it.isNotBlank() }; return if (p.size >= 2) "${p[0].first()}${p[1].first()}" else p.firstOrNull()?.take(2) ?: "؟" }
    private fun roleLabel(v: String) = when (v) { "admin" -> "مدير"; "worker" -> "عامل"; "designer" -> "مصمم"; "client" -> "عميل"; else -> v.ifBlank { "عميل" } }
    private fun normalizeStatus(v: String) = when (v) { "in_progress" -> "working"; "missing" -> "review"; else -> v }
    private fun statusGroup(v: String) = when (normalizeStatus(v)) { "new", "assigned" -> "new"; "working", "approval" -> "working"; "review" -> "review"; "ready" -> "ready"; "delivered" -> "delivered"; else -> "new" }
    private fun statusLabel(v: String) = when (normalizeStatus(v)) { "new" -> "طلب جديد"; "review" -> "قيد المراجعة"; "assigned" -> "تم الإسناد"; "working" -> "جاري التنفيذ"; "approval" -> "يحتاج موافقة العميل"; "ready" -> "جاهز"; "delivered" -> "تم التسليم"; else -> v }
    private fun fileStatusLabel(v: String) = when (v) { "working" -> "قيد التنفيذ"; "ready" -> "جاهزة"; "issue" -> "تحتاج تعديل"; else -> "لم يبدأ" }
    private fun formatDate(v: String): String = if (v.length >= 10) v.take(10) else v
    private fun openUrl(url: String) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { toast("تعذر فتح الملف") } }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
