/**
 * Ghazala Orders - Google Apps Script Backend
 * قاعدة بيانات: Google Sheets + Google Drive
 * الإصدار: 1.0
 */

const CONFIG = {
  SPREADSHEET_ID: '1pYDdLp8jjezoO9BznVfpHIyxoHmP8YZFndiIJfSJkwU',
  ATTACHMENTS_FOLDER_ID: '1x1WG6xFWTbol7d3ypMYP3Nuu06pbcVPx',
  BOOTSTRAP_SECRET: 'GHAZALA_FIRST_ADMIN_2026',
  SESSION_DAYS: 30,
  ROLES: ['client', 'admin', 'worker', 'designer'],
  STAFF_ROLES: ['worker', 'designer'],
  STATUSES: ['new', 'review', 'assigned', 'working', 'approval', 'ready', 'delivered', 'in_progress', 'missing'],
  FILE_STATUSES: ['new', 'working', 'ready', 'issue']
};

function doGet(e) {
  try {
    ensureSchema_();
    const action = (e && e.parameter && e.parameter.action) || 'ping';
    if (action === 'ping') {
      return json_({
        ok: true,
        service: 'Ghazala Orders API',
        version: '1.0',
        time: now_()
      });
    }
    return json_({ ok: false, error: 'Use POST for this action.' });
  } catch (err) {
    return json_({ ok: false, error: String(err.message || err) });
  }
}

function doPost(e) {
  try {
    ensureSchema_();
    const body = parseBody_(e);
    const action = String(body.action || '').trim();

    switch (action) {
      case 'ping':
        return json_({ ok: true, service: 'Ghazala Orders API', version: '1.0', time: now_() });

      case 'setupAdmin':
        return json_(setupAdmin_(body));

      case 'registerClient':
        return json_(registerClient_(body));

      case 'login':
        return json_(login_(body));

      case 'logout':
        return json_(logout_(body));

      case 'sync':
        return json_(sync_(body));

      case 'addStaff':
        return json_(addStaff_(body));

      case 'listUsers':
        return json_(listUsers_(body));

      case 'createOrder':
        return json_(createOrder_(body));

      case 'listOrders':
        return json_(listOrders_(body));

      case 'assignOrder':
        return json_(assignOrder_(body));

      case 'updateOrderStatus':
        return json_(updateOrderStatus_(body));

      case 'uploadFile':
        return json_(uploadFile_(body));

      case 'listOrderFiles':
        return json_(listOrderFiles_(body));

      case 'updateFileStatus':
        return json_(updateFileStatus_(body));

      case 'bulkUpdateFileStatus':
        return json_(bulkUpdateFileStatus_(body));

      case 'customerApproval':
        return json_(customerApproval_(body));

      case 'updateStaff':
        return json_(updateStaff_(body));

      case 'deleteStaff':
        return json_(deleteStaff_(body));

      default:
        return json_({ ok: false, error: 'Unknown action: ' + action });
    }
  } catch (err) {
    return json_({
      ok: false,
      error: String(err.message || err),
      stack: err && err.stack ? String(err.stack) : ''
    });
  }
}

/* =========================
   إعداد المدير لأول مرة
   ========================= */

function setupAdmin_(body) {
  const users = getObjects_('users');

  if (users.some(u => u.role === 'admin')) {
    return { ok: false, error: 'Admin already exists. Initial setup is disabled.' };
  }

  if (String(body.bootstrapSecret || '') !== CONFIG.BOOTSTRAP_SECRET) {
    return { ok: false, error: 'Invalid bootstrap secret.' };
  }

  const name = required_(body.name, 'name');
  const phone = normalizePhone_(required_(body.phone, 'phone'));
  const email = String(body.email || '').trim().toLowerCase();
  const company = String(body.company || '').trim();
  const password = required_(body.password, 'password');

  if (password.length < 6) {
    return { ok: false, error: 'Password must be at least 6 characters.' };
  }

  if (findUserByIdentifier_(phone) || (email && findUserByIdentifier_(email))) {
    return { ok: false, error: 'Phone or email is already registered.' };
  }

  const salt = randomToken_().slice(0, 24);
  const user = {
    userId: 'USR-' + Utilities.getUuid(),
    name: name,
    phone: phone,
    email: email,
    company: company,
    passwordHash: hashPassword_(password, salt),
    passwordSalt: salt,
    role: 'admin',
    active: true,
    createdAt: now_(),
    updatedAt: now_()
  };

  appendObject_('users', user);

  return {
    ok: true,
    message: 'Admin created successfully.',
    user: publicUser_(user)
  };
}

/* =========================
   المستخدمون وتسجيل الدخول
   ========================= */

function registerClient_(body) {
  const name = required_(body.name, 'name');
  const phone = normalizePhone_(required_(body.phone, 'phone'));
  const email = String(body.email || '').trim().toLowerCase();
  const company = String(body.company || '').trim();
  const password = required_(body.password, 'password');

  if (password.length < 6) {
    return { ok: false, error: 'Password must be at least 6 characters.' };
  }

  if (findUserByIdentifier_(phone) || (email && findUserByIdentifier_(email))) {
    return { ok: false, error: 'Phone or email is already registered.' };
  }

  const salt = randomToken_().slice(0, 24);
  const user = {
    userId: 'USR-' + Utilities.getUuid(),
    name: name,
    phone: phone,
    email: email,
    company: company,
    passwordHash: hashPassword_(password, salt),
    passwordSalt: salt,
    role: 'client',
    active: true,
    createdAt: now_(),
    updatedAt: now_()
  };

  appendObject_('users', user);

  const session = createSession_(user.userId);

  return {
    ok: true,
    user: publicUser_(user),
    token: session.token,
    expiresAt: session.expiresAt
  };
}

function login_(body) {
  const identifier = required_(body.identifier, 'identifier');
  const password = required_(body.password, 'password');

  const user = findUserByIdentifier_(identifier);
  if (!user || !truthy_(user.active)) {
    return { ok: false, error: 'Invalid login credentials.' };
  }

  if (hashPassword_(password, String(user.passwordSalt || '')) !== String(user.passwordHash || '')) {
    return { ok: false, error: 'Invalid login credentials.' };
  }

  const session = createSession_(user.userId);

  return {
    ok: true,
    user: publicUser_(user),
    token: session.token,
    expiresAt: session.expiresAt
  };
}

function logout_(body) {
  const auth = requireSession_(body.token);
  const sessions = getObjects_('sessions');

  const tokenHash = sha256_(String(body.token || ''));
  for (let i = 0; i < sessions.length; i++) {
    if (String(sessions[i].tokenHash) === tokenHash && truthy_(sessions[i].active)) {
      updateRowFields_('sessions', sessions[i]._row, {
        active: false
      });
    }
  }

  return { ok: true, userId: auth.user.userId };
}

function addStaff_(body) {
  requireSession_(body.token, ['admin']);

  const name = required_(body.name, 'name');
  const phone = normalizePhone_(required_(body.phone, 'phone'));
  const email = String(body.email || '').trim().toLowerCase();
  const company = String(body.company || '').trim();
  const password = required_(body.password, 'password');
  const role = String(body.role || '').trim();

  if (!CONFIG.STAFF_ROLES.includes(role)) {
    return { ok: false, error: 'role must be worker or designer.' };
  }

  if (password.length < 6) {
    return { ok: false, error: 'Password must be at least 6 characters.' };
  }

  if (findUserByIdentifier_(phone) || (email && findUserByIdentifier_(email))) {
    return { ok: false, error: 'Phone or email is already registered.' };
  }

  const salt = randomToken_().slice(0, 24);
  const user = {
    userId: 'USR-' + Utilities.getUuid(),
    name: name,
    phone: phone,
    email: email,
    company: company,
    passwordHash: hashPassword_(password, salt),
    passwordSalt: salt,
    role: role,
    active: true,
    createdAt: now_(),
    updatedAt: now_()
  };

  appendObject_('users', user);

  return { ok: true, user: publicUser_(user) };
}

function listUsers_(body) {
  const auth = requireSession_(body.token, ['admin']);
  const users = getObjects_('users')
    .filter(u => u.userId !== auth.user.userId || u.role === 'admin')
    .map(publicUser_);

  return { ok: true, users: users };
}

/* =========================
   الطلبات
   ========================= */

function createOrder_(body) {
  const auth = requireSession_(body.token, ['client', 'admin']);

  const title = required_(body.title, 'title');
  const description = String(body.description || '').trim();

  const clientId = auth.user.role === 'client'
    ? auth.user.userId
    : required_(body.clientId, 'clientId');

  const client = getUserById_(clientId);
  if (!client || client.role !== 'client') {
    return { ok: false, error: 'Client not found.' };
  }

  const order = {
    orderId: 'ORD-' + Utilities.getUuid(),
    clientId: client.userId,
    clientName: client.name,
    title: title,
    description: description,
    urgent: truthy_(body.urgent),
    status: 'new',
    assignedUserId: '',
    assignedRole: '',
    notes: '',
    createdAt: now_(),
    updatedAt: now_(),
    completedAt: ''
  };

  appendObject_('orders', order);
  addEvent_(order.orderId, auth.user, 'new', 'تم إنشاء الطلب');

  return { ok: true, order: orderWithFiles_(getOrderById_(order.orderId)) };
}

function listOrders_(body) {
  const auth = requireSession_(body.token);
  const orders = visibleOrdersForUser_(auth.user);

  return {
    ok: true,
    orders: orders.map(orderWithFiles_)
  };
}

function assignOrder_(body) {
  requireSession_(body.token, ['admin']);

  const orderId = required_(body.orderId, 'orderId');
  const userId = required_(body.userId, 'userId');

  const order = getOrderById_(orderId);
  if (!order) return { ok: false, error: 'Order not found.' };

  const assignee = getUserById_(userId);
  if (!assignee || !CONFIG.STAFF_ROLES.includes(String(assignee.role)) || !truthy_(assignee.active)) {
    return { ok: false, error: 'Worker/designer not found or inactive.' };
  }

  updateRowFields_('orders', order._row, {
    assignedUserId: assignee.userId,
    assignedRole: assignee.role,
    status: 'assigned',
    updatedAt: now_()
  });

  addEvent_(orderId, requireSession_(body.token).user, 'assigned', 'تم إسناد الطلب إلى: ' + assignee.name + (body.note ? ' — ' + String(body.note) : ''));

  return {
    ok: true,
    order: orderWithFiles_(getOrderById_(orderId))
  };
}

function updateOrderStatus_(body) {
  const auth = requireSession_(body.token);

  const orderId = required_(body.orderId, 'orderId');
  const status = required_(body.status, 'status');
  const notes = String(body.notes || '').trim();

  if (!CONFIG.STATUSES.includes(status)) {
    return { ok: false, error: 'Invalid status.' };
  }

  const order = getOrderById_(orderId);
  if (!order) return { ok: false, error: 'Order not found.' };

  const allowed =
    auth.user.role === 'admin' ||
    (CONFIG.STAFF_ROLES.includes(auth.user.role) && String(order.assignedUserId) === auth.user.userId);

  if (!allowed) {
    return { ok: false, error: 'Not allowed to update this order.' };
  }

  const fields = {
    status: status,
    notes: notes,
    updatedAt: now_()
  };

  fields.completedAt = status === 'ready' ? now_() : '';

  updateRowFields_('orders', order._row, fields);
  addEvent_(orderId, auth.user, status, notes || 'تم تحديث حالة الطلب');

  return {
    ok: true,
    order: orderWithFiles_(getOrderById_(orderId))
  };
}

/* =========================
   الملفات: صور و PDF
   ========================= */

function uploadFile_(body) {
  const auth = requireSession_(body.token);

  const orderId = required_(body.orderId, 'orderId');
  const fileName = sanitizeFileName_(required_(body.fileName, 'fileName'));
  const mimeType = String(body.mimeType || 'application/octet-stream').trim();
  const base64Data = required_(body.base64Data, 'base64Data');

  const order = getOrderById_(orderId);
  if (!order) return { ok: false, error: 'Order not found.' };

  if (!canAccessOrder_(auth.user, order)) {
    return { ok: false, error: 'Not allowed to upload to this order.' };
  }

  const cleanBase64 = String(base64Data).replace(/^data:[^;]+;base64,/, '');
  const bytes = Utilities.base64Decode(cleanBase64);
  const blob = Utilities.newBlob(bytes, mimeType, fileName);

  const folder = getOrCreateOrderFolder_(orderId);
  const file = folder.createFile(blob);

  const rec = {
    fileId: 'FIL-' + Utilities.getUuid(),
    orderId: orderId,
    uploaderId: auth.user.userId,
    fileName: fileName,
    mimeType: mimeType,
    driveFileId: file.getId(),
    driveUrl: file.getUrl(),
    sizeBytes: file.getSize(),
    itemStatus: mimeType.indexOf('image/') === 0 ? 'new' : '',
    itemNote: '',
    itemUpdatedAt: '',
    itemUpdatedBy: '',
    createdAt: now_()
  };

  appendObject_('files', rec);

  return {
    ok: true,
    file: rec
  };
}

function listOrderFiles_(body) {
  const auth = requireSession_(body.token);
  const orderId = required_(body.orderId, 'orderId');

  const order = getOrderById_(orderId);
  if (!order) return { ok: false, error: 'Order not found.' };

  if (!canAccessOrder_(auth.user, order)) {
    return { ok: false, error: 'Not allowed to view these files.' };
  }

  return {
    ok: true,
    files: getObjects_('files').filter(f => String(f.orderId) === orderId)
  };
}

/* =========================
   مزامنة التطبيق
   ========================= */

function sync_(body) {
  const auth = requireSession_(body.token);
  const result = {
    ok: true,
    user: publicUser_(auth.user),
    orders: visibleOrdersForUser_(auth.user).map(orderWithFiles_)
  };

  if (auth.user.role === 'admin') {
    result.users = getObjects_('users').map(publicUser_);
  }

  return result;
}


/* =========================
   ميزات غرزة لاين الإضافية
   ========================= */

function updateFileStatus_(body) {
  const auth = requireSession_(body.token);
  const orderId = required_(body.orderId, 'orderId');
  const fileId = required_(body.fileId, 'fileId');
  const status = required_(body.status, 'status');
  const note = String(body.note || '').trim();
  if (!CONFIG.FILE_STATUSES.includes(status)) return {ok:false,error:'Invalid file status.'};
  const order = getOrderById_(orderId);
  if (!order) return {ok:false,error:'Order not found.'};
  const allowed = auth.user.role === 'admin' || (CONFIG.STAFF_ROLES.includes(auth.user.role) && String(order.assignedUserId) === auth.user.userId);
  if (!allowed) return {ok:false,error:'Not allowed.'};
  const file = getObjects_('files').find(f => String(f.fileId) === fileId && String(f.orderId) === orderId);
  if (!file) return {ok:false,error:'File not found.'};
  updateRowFields_('files', file._row, {itemStatus:status,itemNote:note,itemUpdatedAt:now_(),itemUpdatedBy:auth.user.userId});
  recalcOrderFromFiles_(orderId);
  addEvent_(orderId, auth.user, getOrderById_(orderId).status, 'تحديث ملف: ' + file.fileName + ' — ' + status);
  return {ok:true,order:orderWithFiles_(getOrderById_(orderId))};
}

function bulkUpdateFileStatus_(body) {
  const auth = requireSession_(body.token);
  const orderId = required_(body.orderId, 'orderId');
  const status = required_(body.status, 'status');
  if (!CONFIG.FILE_STATUSES.includes(status)) return {ok:false,error:'Invalid file status.'};
  const order = getOrderById_(orderId);
  if (!order) return {ok:false,error:'Order not found.'};
  const allowed = auth.user.role === 'admin' || (CONFIG.STAFF_ROLES.includes(auth.user.role) && String(order.assignedUserId) === auth.user.userId);
  if (!allowed) return {ok:false,error:'Not allowed.'};
  getObjects_('files').filter(f => String(f.orderId) === orderId && String(f.mimeType||'').indexOf('image/') === 0).forEach(f => {
    updateRowFields_('files', f._row, {itemStatus:status,itemUpdatedAt:now_(),itemUpdatedBy:auth.user.userId});
  });
  recalcOrderFromFiles_(orderId);
  addEvent_(orderId, auth.user, getOrderById_(orderId).status, 'تم تغيير حالة جميع الصور إلى: ' + status);
  return {ok:true,order:orderWithFiles_(getOrderById_(orderId))};
}

function customerApproval_(body) {
  const auth = requireSession_(body.token, ['client']);
  const orderId = required_(body.orderId, 'orderId');
  const approved = truthy_(body.approved);
  const order = getOrderById_(orderId);
  if (!order || String(order.clientId) !== auth.user.userId) return {ok:false,error:'Order not found or not allowed.'};
  const status = approved ? 'working' : 'review';
  const note = approved ? 'وافق العميل على التنفيذ' : 'طلب العميل تعديلاً';
  updateRowFields_('orders', order._row, {status:status,notes:note,updatedAt:now_()});
  addEvent_(orderId, auth.user, status, note);
  return {ok:true,order:orderWithFiles_(getOrderById_(orderId))};
}

function updateStaff_(body) {
  requireSession_(body.token, ['admin']);
  const userId = required_(body.userId, 'userId');
  const u = getUserById_(userId);
  if (!u || !CONFIG.STAFF_ROLES.includes(String(u.role))) return {ok:false,error:'Staff not found.'};
  const fields = {updatedAt:now_()};
  ['name','phone','email','company'].forEach(k => { if (body[k] !== undefined) fields[k] = k === 'phone' ? normalizePhone_(body[k]) : String(body[k]||'').trim(); });
  if (body.password) {
    const password = String(body.password);
    if (password.length < 6) return {ok:false,error:'Password must be at least 6 characters.'};
    const salt = randomToken_().slice(0,24); fields.passwordSalt=salt; fields.passwordHash=hashPassword_(password,salt);
  }
  updateRowFields_('users', u._row, fields);
  return {ok:true,user:publicUser_(getUserById_(userId))};
}

function deleteStaff_(body) {
  requireSession_(body.token, ['admin']);
  const userId = required_(body.userId, 'userId');
  const u = getUserById_(userId);
  if (!u || !CONFIG.STAFF_ROLES.includes(String(u.role))) return {ok:false,error:'Staff not found.'};
  updateRowFields_('users', u._row, {active:false,updatedAt:now_()});
  return {ok:true};
}

function recalcOrderFromFiles_(orderId) {
  const order = getOrderById_(orderId); if (!order) return;
  const images = getObjects_('files').filter(f => String(f.orderId) === orderId && String(f.mimeType||'').indexOf('image/') === 0);
  if (!images.length) return;
  let status = order.assignedUserId ? 'assigned' : 'new';
  if (images.every(f => String(f.itemStatus||'new') === 'ready')) status = 'ready';
  else if (images.some(f => String(f.itemStatus||'new') === 'issue')) status = 'review';
  else if (images.some(f => ['working','ready'].includes(String(f.itemStatus||'new')))) status = 'working';
  updateRowFields_('orders', order._row, {status:status,updatedAt:now_(),completedAt:status==='ready'?now_():''});
}

function addEvent_(orderId, user, status, note) {
  appendObject_('events', {eventId:'EVT-'+Utilities.getUuid(),orderId:orderId,userId:user?user.userId:'',userName:user?user.name:'النظام',status:status,note:String(note||''),createdAt:now_()});
}

function stripRow_(obj) {
  const out={}; Object.keys(obj||{}).forEach(k=>{if(k!=='_row') out[k]=obj[k]}); return out;
}

function ensureSchema_() {
  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  ensureSheetHeaders_(ss,'users',['userId','name','phone','email','company','passwordHash','passwordSalt','role','active','createdAt','updatedAt']);
  ensureSheetHeaders_(ss,'orders',['orderId','clientId','clientName','title','description','urgent','status','assignedUserId','assignedRole','notes','createdAt','updatedAt','completedAt']);
  ensureSheetHeaders_(ss,'files',['fileId','orderId','uploaderId','fileName','mimeType','driveFileId','driveUrl','sizeBytes','itemStatus','itemNote','itemUpdatedAt','itemUpdatedBy','createdAt']);
  ensureSheetHeaders_(ss,'sessions',['sessionId','tokenHash','userId','createdAt','expiresAt','active']);
  ensureSheetHeaders_(ss,'events',['eventId','orderId','userId','userName','status','note','createdAt']);
}

function ensureSheetHeaders_(ss,name,headers) {
  let sh=ss.getSheetByName(name); if(!sh) sh=ss.insertSheet(name);
  if(sh.getLastRow()===0){sh.getRange(1,1,1,headers.length).setValues([headers]);return;}
  const lastCol=Math.max(1,sh.getLastColumn());
  const existing=sh.getRange(1,1,1,lastCol).getValues()[0].map(String);
  const missing=headers.filter(h=>existing.indexOf(h)<0);
  if(missing.length) sh.getRange(1,lastCol+1,1,missing.length).setValues([missing]);
}

/* =========================
   Helpers
   ========================= */

function visibleOrdersForUser_(user) {
  const orders = getObjects_('orders');

  if (user.role === 'admin') return orders;
  if (user.role === 'client') {
    return orders.filter(o => String(o.clientId) === user.userId);
  }
  if (CONFIG.STAFF_ROLES.includes(user.role)) {
    return orders.filter(o => String(o.assignedUserId) === user.userId);
  }
  return [];
}

function canAccessOrder_(user, order) {
  if (user.role === 'admin') return true;
  if (user.role === 'client') return String(order.clientId) === user.userId;
  if (CONFIG.STAFF_ROLES.includes(user.role)) {
    return String(order.assignedUserId) === user.userId;
  }
  return false;
}

function orderWithFiles_(order) {
  const copy = {};
  Object.keys(order).forEach(k => {
    if (k !== '_row') copy[k] = order[k];
  });
  copy.files = getObjects_('files').filter(f => String(f.orderId) === String(order.orderId)).map(stripRow_);
  copy.events = getObjects_('events').filter(e => String(e.orderId) === String(order.orderId)).map(stripRow_);
  const assignee = order.assignedUserId ? getUserById_(String(order.assignedUserId)) : null;
  copy.assignedName = assignee ? assignee.name : '';
  return copy;
}

function getOrCreateOrderFolder_(orderId) {
  const root = DriveApp.getFolderById(CONFIG.ATTACHMENTS_FOLDER_ID);
  const it = root.getFoldersByName(orderId);
  if (it.hasNext()) return it.next();
  return root.createFolder(orderId);
}

function createSession_(userId) {
  const token = randomToken_() + randomToken_();
  const expires = new Date(Date.now() + CONFIG.SESSION_DAYS * 24 * 60 * 60 * 1000);

  appendObject_('sessions', {
    sessionId: 'SES-' + Utilities.getUuid(),
    tokenHash: sha256_(token),
    userId: userId,
    createdAt: now_(),
    expiresAt: expires.toISOString(),
    active: true
  });

  return { token: token, expiresAt: expires.toISOString() };
}

function requireSession_(token, roles) {
  token = required_(token, 'token');

  const sessions = getObjects_('sessions');
  const tokenHash = sha256_(token);

  const session = sessions.find(s =>
    String(s.tokenHash) === tokenHash &&
    truthy_(s.active) &&
    new Date(String(s.expiresAt)).getTime() > Date.now()
  );

  if (!session) throw new Error('Unauthorized session.');

  const user = getUserById_(String(session.userId));
  if (!user || !truthy_(user.active)) throw new Error('User is inactive or missing.');

  if (roles && roles.length && !roles.includes(String(user.role))) {
    throw new Error('Permission denied.');
  }

  return { session: session, user: user };
}

function findUserByIdentifier_(identifier) {
  const raw = String(identifier || '').trim();
  const phone = normalizePhone_(raw);
  const email = raw.toLowerCase();

  return getObjects_('users').find(u =>
    String(u.phone || '') === phone ||
    String(u.email || '').toLowerCase() === email
  ) || null;
}

function getUserById_(userId) {
  return getObjects_('users').find(u => String(u.userId) === String(userId)) || null;
}

function getOrderById_(orderId) {
  return getObjects_('orders').find(o => String(o.orderId) === String(orderId)) || null;
}

function publicUser_(u) {
  return {
    userId: u.userId,
    name: u.name,
    phone: u.phone,
    email: u.email,
    company: u.company || '',
    role: u.role,
    active: truthy_(u.active),
    createdAt: u.createdAt,
    updatedAt: u.updatedAt
  };
}

function getSheet_(name) {
  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  const sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Missing sheet: ' + name);
  return sh;
}

function getObjects_(sheetName) {
  const sh = getSheet_(sheetName);
  const lastRow = sh.getLastRow();
  const lastCol = sh.getLastColumn();

  if (lastRow < 1 || lastCol < 1) return [];

  const values = sh.getRange(1, 1, lastRow, lastCol).getValues();
  const headers = values[0].map(String);

  const out = [];
  for (let r = 1; r < values.length; r++) {
    const row = values[r];
    if (row.every(v => v === '' || v === null)) continue;

    const obj = { _row: r + 1 };
    headers.forEach((h, c) => obj[h] = row[c]);
    out.push(obj);
  }
  return out;
}

function appendObject_(sheetName, obj) {
  const sh = getSheet_(sheetName);
  const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);
  const row = headers.map(h => obj[h] !== undefined ? obj[h] : '');
  sh.appendRow(row);
}

function updateRowFields_(sheetName, rowNumber, fields) {
  const sh = getSheet_(sheetName);
  const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);

  Object.keys(fields).forEach(key => {
    const col = headers.indexOf(key);
    if (col >= 0) sh.getRange(rowNumber, col + 1).setValue(fields[key]);
  });
}

function hashPassword_(password, salt) {
  return sha256_(String(salt) + '|' + String(password));
}

function sha256_(value) {
  const digest = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    String(value),
    Utilities.Charset.UTF_8
  );
  return Utilities.base64EncodeWebSafe(digest);
}

function randomToken_() {
  return Utilities.getUuid().replace(/-/g, '') +
         Utilities.getUuid().replace(/-/g, '');
}

function normalizePhone_(phone) {
  return String(phone || '').replace(/[^\d+]/g, '').trim();
}

function sanitizeFileName_(name) {
  return String(name || 'file')
    .replace(/[\\\/:*?"<>|]/g, '_')
    .slice(0, 180);
}

function truthy_(v) {
  return v === true || String(v).toLowerCase() === 'true' || String(v) === '1';
}

function required_(v, name) {
  const s = String(v === undefined || v === null ? '' : v).trim();
  if (!s) throw new Error('Missing required field: ' + name);
  return s;
}

function parseBody_(e) {
  if (!e || !e.postData || !e.postData.contents) return {};
  const text = e.postData.contents;
  try {
    return JSON.parse(text);
  } catch (_) {
    return e.parameter || {};
  }
}

function now_() {
  return new Date().toISOString();
}

function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
