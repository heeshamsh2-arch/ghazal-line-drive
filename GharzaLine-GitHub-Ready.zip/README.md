# غرزة لاين

تطبيق Android متصل بـ Google Apps Script وGoogle Drive.

ينشئ GitHub Actions ملف APK قابلاً للتثبيت؛ يوجد الملف في Artifacts باسم `GharzaLine-APK`.

ملفات الخادم وإعداداتها الخاصة تُدار في Google Apps Script.
